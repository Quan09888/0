const mongoose = require("mongoose");
const { User, Post, Category } = require("../models");
require("dotenv").config();

const connectDB = async () => {
  try {
    await mongoose.connect(
      process.env.MONGODB_URI || "mongodb://localhost:27017/bat_dong_san"
    );
    console.log("✅ MongoDB connected for seeding");
  } catch (error) {
    console.error("❌ MongoDB connection error:", error);
    process.exit(1);
  }
};

const categoriesData = [
  {
    name: "chung cư",
    description: "Căn hộ chung cư, apartment",
    icon: "fas fa-building",
    color: "#007bff",
    sortOrder: 1,
    metaTitle: "Chung cư - Bất động sản",
    metaDescription: "Tìm kiếm và đăng tin mua bán, cho thuê chung cư, căn hộ",
  },
  {
    name: "nhà riêng",
    description: "Nhà riêng, nhà phố",
    icon: "fas fa-home",
    color: "#28a745",
    sortOrder: 2,
    metaTitle: "Nhà riêng - Bất động sản",
    metaDescription:
      "Tìm kiếm và đăng tin mua bán, cho thuê nhà riêng, nhà phố",
  },
  {
    name: "đất nền",
    description: "Đất nền, đất thổ cư",
    icon: "fas fa-map",
    color: "#ffc107",
    sortOrder: 3,
    metaTitle: "Đất nền - Bất động sản",
    metaDescription: "Tìm kiếm và đăng tin mua bán đất nền, đất thổ cư",
  },
  {
    name: "nhà mặt phố",
    description: "Nhà mặt phố, mặt tiền",
    icon: "fas fa-store",
    color: "#dc3545",
    sortOrder: 4,
    metaTitle: "Nhà mặt phố - Bất động sản",
    metaDescription: "Tìm kiếm và đăng tin mua bán, cho thuê nhà mặt phố",
  },
  {
    name: "biệt thự",
    description: "Biệt thự, villa",
    icon: "fas fa-crown",
    color: "#6f42c1",
    sortOrder: 5,
    metaTitle: "Biệt thự - Bất động sản",
    metaDescription: "Tìm kiếm và đăng tin mua bán, cho thuê biệt thự, villa",
  },
  {
    name: "shophouse",
    description: "Shophouse, nhà phố thương mại",
    icon: "fas fa-shopping-bag",
    color: "#fd7e14",
    sortOrder: 6,
    metaTitle: "Shophouse - Bất động sản",
    metaDescription: "Tìm kiếm và đăng tin mua bán, cho thuê shophouse",
  },
  {
    name: "kho xưởng",
    description: "Kho xưởng, nhà máy",
    icon: "fas fa-warehouse",
    color: "#6c757d",
    sortOrder: 7,
    metaTitle: "Kho xưởng - Bất động sản",
    metaDescription: "Tìm kiếm và đăng tin cho thuê kho xưởng, nhà máy",
  },
  {
    name: "văn phòng",
    description: "Văn phòng, tòa nhà",
    icon: "fas fa-briefcase",
    color: "#20c997",
    sortOrder: 8,
    metaTitle: "Văn phòng - Bất động sản",
    metaDescription: "Tìm kiếm và đăng tin cho thuê văn phòng, tòa nhà",
  },
];

const adminData = {
  name: "Admin",
  email: "admin@gmail.com",
  password: "admin123",
  role: "admin",
  phone: "0123456789",
  emailVerified: true,
};

const usersData = [
  {
    name: "Nguyễn Văn An",
    email: "vudovn@gmail.com",
    password: "Vudo354@",
    phone: "0987654321",
    emailVerified: true,
  },
  {
    name: "Trần Thị Bình",
    email: "tranthib@gmail.com",
    password: "123456",
    phone: "0987654322",
    emailVerified: true,
  },
  {
    name: "Lê Văn Cường",
    email: "levanc@gmail.com",
    password: "123456",
    phone: "0987654323",
    emailVerified: true,
  },
  {
    name: "Phạm Minh Đức",
    email: "phamminhduc@gmail.com",
    password: "123456",
    phone: "0987654324",
    emailVerified: true,
  },
  {
    name: "Hoàng Thị Hương",
    email: "hoanghuong@gmail.com",
    password: "123456",
    phone: "0987654325",
    emailVerified: true,
  },
];

const getPostsData = (users) => [
  // Chung cư - Bán
  {
    title: "Bán căn hộ chung cư 2PN tại Vinhomes Central Park",
    description:
      "Căn hộ cao cấp 2 phòng ngủ, 2 toilet, đầy đủ nội thất nhập khẩu, view sông Sài Gòn tuyệt đẹp. Tòa Landmark 81, tầng 35. Tiện ích 5 sao: hồ bơi, gym, công viên. Giá tốt cho nhà đầu tư hoặc ở ngay. Pháp lý sổ hồng đầy đủ.",
    price: 4500000000,
    area: 85,
    address: "208 Nguyễn Hữu Cảnh, Phường 22, Quận Bình Thạnh, TP.HCM",
    phone: "0987654321",
    type: "bán",
    category: "chung cư",
    images: ["/images/apartment.jpg"],
    userId: users[0]._id,
    isApproved: true,
    views: 156,
  },
  {
    title: "Bán căn hộ 3PN Masteri Thảo Điền quận 2",
    description:
      "Căn hộ 3 phòng ngủ, 2 WC, diện tích 98m2, tầng cao view sông. Nội thất đầy đủ cao cấp, có ban công rộng. Khu vực sầm uất, gần Metro, trường quốc tế. Chủ nhà cần bán gấp nên giá tốt hơn thị trường.",
    price: 5200000000,
    area: 98,
    address: "159 Xa Lộ Hà Nội, Phường Thảo Điền, Quận 2, TP.HCM",
    phone: "0987654322",
    type: "bán",
    category: "chung cư",
    images: ["/images/apartment.jpg"],
    userId: users[1]._id,
    isApproved: true,
    views: 89,
  },
  // Chung cư - Cho thuê
  {
    title: "Cho thuê căn hộ studio Vinhomes Grand Park quận 9",
    description:
      "Căn hộ studio full nội thất cao cấp, máy lạnh, tủ lạnh, máy giặt, bếp từ. An ninh 24/7, hồ bơi miễn phí, gym, công viên 36ha. Phù hợp cho 1-2 người đi làm hoặc sinh viên. Giá thuê đã bao gồm phí quản lý.",
    price: 6500000,
    area: 32,
    address: "Long Thạnh Mỹ, Quận 9, TP.HCM",
    phone: "0987654323",
    type: "cho thuê",
    category: "chung cư",
    images: ["/images/apartment.jpg"],
    userId: users[2]._id,
    isApproved: true,
    views: 234,
  },
  {
    title: "Cho thuê căn hộ 2PN The Sun Avenue quận 2",
    description:
      "Căn hộ 2 phòng ngủ, 2 toilet, nội thất đẹp, ban công view sông. Gần Metro An Phú, trường học quốc tế, siêu thị Big C. Tiện ích: hồ bơi, gym, BBQ. Phù hợp gia đình trẻ hoặc chuyên gia nước ngoài.",
    price: 12000000,
    area: 76,
    address: "28 Mai Chí Thọ, Phường An Phú, Quận 2, TP.HCM",
    phone: "0987654324",
    type: "cho thuê",
    category: "chung cư",
    images: ["/images/apartment.jpg"],
    userId: users[3]._id,
    isApproved: true,
    views: 178,
  },
  // Nhà riêng - Bán
  {
    title: "Bán nhà riêng 3 tầng HXH Nguyễn Văn Đậu Bình Thạnh",
    description:
      "Nhà 3 tầng BTCT, 4 phòng ngủ, 3 WC, phòng khách rộng, bếp riêng. Hẻm xe hơi 6m thông thoáng, khu dân cư an ninh. Gần chợ Bà Chiểu, trường THPT Gia Định. Sổ hồng riêng, công chứng ngay. Thích hợp ở hoặc đầu tư.",
    price: 6800000000,
    area: 65,
    address: "Hẻm 158 Nguyễn Văn Đậu, Phường 7, Quận Bình Thạnh, TP.HCM",
    phone: "0987654321",
    type: "bán",
    category: "nhà riêng",
    images: ["/images/sample-house.jpg"],
    userId: users[0]._id,
    isApproved: true,
    views: 312,
  },
  {
    title: "Bán nhà 2 mặt tiền hẻm Lê Văn Sỹ quận 3",
    description:
      "Nhà 2 mặt tiền hẻm xe hơi, 1 trệt 2 lầu, 3PN 2WC. Thiết kế hiện đại, sáng sủa, thông thoáng. Vị trí đắc địa ngay trung tâm quận 3, gần chợ, trường học, bệnh viện. Pháp lý rõ ràng, sang tên công chứng ngay.",
    price: 8500000000,
    area: 48,
    address: "Hẻm 567 Lê Văn Sỹ, Phường 12, Quận 3, TP.HCM",
    phone: "0987654325",
    type: "bán",
    category: "nhà riêng",
    images: ["/images/sample-house.jpg"],
    userId: users[4]._id,
    isApproved: true,
    views: 445,
  },
  // Nhà riêng - Cho thuê
  {
    title: "Cho thuê nhà nguyên căn 3 tầng Thảo Điền quận 2",
    description:
      "Nhà nguyên căn 3 tầng, 4PN 3WC, có sân để 2 xe hơi. Nội thất cơ bản, máy lạnh các phòng. Khu compound an ninh, gần trường quốc tế BIS, ISHCMC. Phù hợp gia đình người nước ngoài hoặc Việt kiều.",
    price: 35000000,
    area: 150,
    address: "Đường 65, Phường Thảo Điền, Quận 2, TP.HCM",
    phone: "0987654322",
    type: "cho thuê",
    category: "nhà riêng",
    images: ["/images/sample-house.jpg"],
    userId: users[1]._id,
    isApproved: true,
    views: 167,
  },
  // Đất nền - Bán
  {
    title: "Bán đất nền dự án Mega City 2 Long Thành Đồng Nai",
    description:
      "Đất nền dự án quy hoạch đồng bộ, hạ tầng hoàn thiện, điện âm nước máy. Gần sân bay Long Thành, cao tốc Bến Lức - Long Thành. Pháp lý sổ đỏ riêng từng nền. Thích hợp đầu tư sinh lời hoặc xây nhà ở.",
    price: 1850000000,
    area: 100,
    address: "Xã Phước Thái, Huyện Long Thành, Tỉnh Đồng Nai",
    phone: "0987654323",
    type: "bán",
    category: "đất nền",
    images: ["/images/land.jpg"],
    userId: users[2]._id,
    isApproved: true,
    views: 567,
  },
  {
    title: "Bán đất thổ cư mặt tiền đường nhựa Củ Chi",
    description:
      "Đất thổ cư 100%, mặt tiền đường nhựa 8m, SHR. Gần UBND xã, trường học, chợ. Điện 3 pha, nước máy. Xây dựng ngay, không qua trung gian. Giá rẻ nhất khu vực, thương lượng cho khách thiện chí.",
    price: 980000000,
    area: 120,
    address: "Xã Phú Hòa Đông, Huyện Củ Chi, TP.HCM",
    phone: "0987654324",
    type: "bán",
    category: "đất nền",
    images: ["/images/land.jpg"],
    userId: users[3]._id,
    isApproved: true,
    views: 389,
  },
  // Biệt thự - Bán
  {
    title: "Bán biệt thự nghỉ dưỡng view biển Nha Trang",
    description:
      "Biệt thự view biển tuyệt đẹp, 5 phòng ngủ VIP, hồ bơi riêng, sân vườn 200m2. Nội thất cao cấp nhập khẩu, thang máy riêng. Khu resort 5 sao, an ninh 24/7. Có thể khai thác cho thuê, cam kết lợi nhuận 8%/năm.",
    price: 15000000000,
    area: 450,
    address: "Bãi Dài, Cam Lâm, Khánh Hòa",
    phone: "0987654321",
    type: "bán",
    category: "biệt thự",
    images: ["/images/villa.jpg"],
    userId: users[0]._id,
    isApproved: true,
    views: 723,
  },
  {
    title: "Bán biệt thự Vinhomes Grand Park quận 9",
    description:
      "Biệt thự đơn lập The Manhattan, 4 tầng, 5PN 6WC, có thang máy. Diện tích đất 200m2, XD 350m2. View công viên 36ha, không khí trong lành. Full nội thất cao cấp, sân vườn, hồ cá. Giá bán đã bao gồm nội thất.",
    price: 32000000000,
    area: 200,
    address: "The Manhattan, Vinhomes Grand Park, Long Bình, Quận 9, TP.HCM",
    phone: "0987654325",
    type: "bán",
    category: "biệt thự",
    images: ["/images/villa.jpg"],
    userId: users[4]._id,
    isApproved: true,
    views: 456,
  },
  // Văn phòng - Cho thuê
  {
    title: "Cho thuê văn phòng hạng A Bitexco quận 1",
    description:
      "Văn phòng hạng A tòa Bitexco Financial Tower, tầng 28, view toàn thành phố. Diện tích linh hoạt từ 50-500m2. Có sẵn điều hòa trung tâm, hệ thống PCCC, an ninh 24/7, hầm xe rộng rãi. Phù hợp công ty tài chính, công nghệ.",
    price: 850000,
    area: 100,
    address: "2 Hải Triều, Phường Bến Nghé, Quận 1, TP.HCM",
    phone: "0987654322",
    type: "cho thuê",
    category: "văn phòng",
    images: ["/images/apartment.jpg"],
    userId: users[1]._id,
    isApproved: true,
    views: 234,
  },
  {
    title: "Cho thuê văn phòng view hồ Tây Hà Nội",
    description:
      "Văn phòng mới 100%, view hồ Tây tuyệt đẹp, có ban công riêng. Diện tích 80-200m2, giá 12-15 USD/m2/tháng. Free phí quản lý 3 tháng đầu, có chỗ đỗ xe ô tô. Phù hợp startup, công ty nhỏ và vừa.",
    price: 25000000,
    area: 120,
    address: "16 Quảng An, Phường Quảng An, Quận Tây Hồ, Hà Nội",
    phone: "0987654323",
    type: "cho thuê",
    category: "văn phòng",
    images: ["/images/apartment.jpg"],
    userId: users[2]._id,
    isApproved: true,
    views: 189,
  },
  // Shophouse - Bán
  {
    title: "Bán shophouse Vinhomes Ocean Park Gia Lâm",
    description:
      "Shophouse mặt đường 30m, 5 tầng, có thang máy. Vị trí kinh doanh đắc địa, dân cư đông đúc. Có thể vừa ở vừa kinh doanh hoặc cho thuê. Pháp lý sổ đỏ 50 năm, gia hạn theo quy định.",
    price: 18500000000,
    area: 90,
    address: "Đại lộ Kinh Đô, Vinhomes Ocean Park, Gia Lâm, Hà Nội",
    phone: "0987654324",
    type: "bán",
    category: "shophouse",
    images: ["/images/sample-house.jpg"],
    userId: users[3]._id,
    isApproved: true,
    views: 345,
  },
  // Kho xưởng - Cho thuê
  {
    title: "Cho thuê kho xưởng 1500m2 KCN Tân Bình",
    description:
      "Kho xưởng mới xây, nền BTCT chịu lực 5 tấn/m2, trần cao 9m. Có văn phòng điều hành, nhà vệ sinh, bãi xe container. Điện 3 pha 250KVA, PCCC đầy đủ. Phù hợp sản xuất, gia công, kho hàng.",
    price: 180000000,
    area: 1500,
    address: "Lô C2-5, KCN Tân Bình, Quận Tân Phú, TP.HCM",
    phone: "0987654325",
    type: "cho thuê",
    category: "kho xưởng",
    images: ["/images/apartment.jpg"],
    userId: users[4]._id,
    isApproved: true,
    views: 123,
  },
  // Nhà mặt phố - Bán
  {
    title: "Bán nhà mặt tiền Nguyễn Trãi quận 5",
    description:
      "Nhà mặt tiền đường lớn, 1 trệt 4 lầu, 5PN 5WC. Ngang 5.5m dài 18m, DTSD 350m2. Đang cho thuê 80 triệu/tháng. Pháp lý sổ hồng, vị trí kinh doanh sầm uất nhất quận 5. Phù hợp mở showroom, ngân hàng, nhà thuốc.",
    price: 42000000000,
    area: 99,
    address: "568 Nguyễn Trãi, Phường 8, Quận 5, TP.HCM",
    phone: "0987654321",
    type: "bán",
    category: "nhà mặt phố",
    images: ["/images/sample-house.jpg"],
    userId: users[0]._id,
    isApproved: true,
    views: 567,
  },
  // Thêm một số tin chờ duyệt
  {
    title: "Bán căn hộ 1PN Saigon Royal quận 4",
    description:
      "Căn hộ 1 phòng ngủ, view Bitexco, nội thất cao cấp, hồ bơi tràn bờ. Khu vực sầm uất, gần cầu Nguyễn Văn Cừ, Metro. Giá tốt nhất dự án, chủ nhà định cư nước ngoài cần bán gấp.",
    price: 3200000000,
    area: 52,
    address: "34-35 Bến Vân Đồn, Phường 12, Quận 4, TP.HCM",
    phone: "0987654322",
    type: "bán",
    category: "chung cư",
    images: ["/images/apartment.jpg"],
    userId: users[1]._id,
    isApproved: null,
    views: 0,
  },
  {
    title: "Cho thuê nhà nguyên căn Gò Vấp giá rẻ",
    description:
      "Nhà 2 tầng, 3PN 2WC, có sân để xe máy. Gần chợ Hạnh Thông Tây, trường học các cấp. Thích hợp gia đình đông người hoặc kinh doanh nhỏ. Giá thuê thương lượng cho khách ở lâu dài.",
    price: 9000000,
    area: 80,
    address: "Hẻm 90 Quang Trung, Phường 10, Quận Gò Vấp, TP.HCM",
    phone: "0987654323",
    type: "cho thuê",
    category: "nhà riêng",
    images: ["/images/sample-house.jpg"],
    userId: users[2]._id,
    isApproved: null,
    views: 0,
  },
];

const seedDatabase = async () => {
  try {
    console.log("🌱 Starting database seeding...");

    // Clear existing data
    await User.deleteMany({});
    await Post.deleteMany({});
    await Category.deleteMany({});
    console.log("🗑️  Cleared existing data");

    // Create categories
    const categories = await Category.insertMany(categoriesData);
    console.log(`✅ Created ${categories.length} categories`);

    // Create admin user
    const admin = await User.create(adminData);
    console.log("✅ Created admin user");

    // Create regular users
    const users = await User.insertMany(usersData);
    console.log(`✅ Created ${users.length} regular users`);

    // Create posts
    const postsData = getPostsData(users);
    const posts = await Post.insertMany(postsData);
    console.log(`✅ Created ${posts.length} posts`);

    // Update categories posts count
    for (const category of categories) {
      await category.updatePostsCount();
    }
    console.log("✅ Updated categories posts count");

    console.log("🎉 Database seeding completed successfully!");
    console.log("\n📋 Seeded data summary:");
    console.log(`   - Admin: ${adminData.email} / ${adminData.password}`);
    console.log(`   - Users: ${users.length} users created`);
    console.log(`   - Categories: ${categories.length} categories created`);
    console.log(`   - Posts: ${posts.length} posts created`);
  } catch (error) {
    console.error("❌ Error seeding database:", error);
  } finally {
    mongoose.connection.close();
    console.log("🔌 Database connection closed");
  }
};

if (require.main === module) {
  connectDB().then(() => {
    seedDatabase();
  });
}

module.exports = { seedDatabase, connectDB };
