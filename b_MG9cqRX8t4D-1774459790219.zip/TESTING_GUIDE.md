# Hướng dẫn kiểm tra và sử dụng hệ thống

## 🔧 Lỗi đã sửa

### 1. **Missing Helper: 'not'** ✅
- **Lỗi**: Handlebars không tìm thấy helper `not` khi render trang admin
- **Nguyên nhân**: Helper `not` chưa được định nghĩa trong `config/handlebars-helpers.js`
- **Cách sửa**: Thêm helper `not` vào file helpers
- **Ảnh hưởng**: Trang dashboard admin, trang quản lý tin đăng

### 2. **Session isActive Field Missing** ✅
- **Lỗi**: Người dùng mới đăng ký bị khóa sau khi đăng nhập
- **Nguyên nhân**: `isActive` không được lưu vào session khi đăng nhập
- **Cách sửa**: 
  - Thêm `isActive: user.isActive` vào `req.session.user`
  - Cải thiện middleware `requireActiveAccount` để kiểm tra DB mỗi request
- **Ảnh hưởng**: Tất cả người dùng (admin & user)

### 3. **Admin Safety Guards** ✅
- **Lỗi**: Có thể vô hiệu hóa/xóa admin cuối cùng hoặc tài khoản hiện tại
- **Nguyên nhân**: Không có kiểm tra an toàn trong các hàm admin
- **Cách sửa**:
  - Kiểm tra không cho admin tự deactivate/delete chính mình
  - Kiểm tra không cho remove admin cuối cùng
  - Kiểm tra không cho xóa admin cuối cùng
- **Ảnh hưởng**: Quản trị viên

## 📝 Dữ liệu Seed

### Tài khoản Admin (từ seeder)
```
Email: admin@gmail.com
Password: admin123
Role: admin
Status: Hoạt động
```

### Tài khoản User Mẫu
1. Nguyễn Văn An
   - Email: vudovn@gmail.com
   - Password: Vudo354@

2. Trần Thị Bình
   - Email: tranthib@gmail.com
   - Password: 123456

3. Lê Văn Cường
   - Email: levanc@gmail.com
   - Password: 123456

## 🧪 Các tác vụ kiểm tra

### 1. Đăng nhập Admin
- [ ] Truy cập `/login`
- [ ] Nhập email: `admin@gmail.com`
- [ ] Nhập mật khẩu: `admin123`
- [ ] Nhấp "Đăng nhập"
- [ ] **Kỳ vọng**: Chuyển hướng đến trang chủ, navbar hiển thị tên admin
- [ ] **Kiểm tra**: Link "Quản trị viên" có trong dropdown user

### 2. Truy cập Trang Admin
- [ ] Nhấp vào "Quản trị viên" trong dropdown
- [ ] **Kỳ vọng**: Trang dashboard hiển thị thành công (không lỗi Handlebars)
- [ ] **Kiểm tra**: 
  - Thống kê tổng tin, tin chờ duyệt, người dùng, danh mục có hiển thị
  - Danh sách tin chờ duyệt hiển thị đúng ({{#if (not isApproved)}})

### 3. Quản lý Tin Đăng
- [ ] Tại `/admin` → Nhấp "Quản lý tin đăng"
- [ ] **Kỳ vọng**: Danh sách tin đăng hiển thị
- [ ] **Kiểm tra**:
  - Có thể phê duyệt tin (nút "Duyệt")
  - Có thể từ chối tin (nút "Từ chối")
  - Có thể xóa tin (nút "Xóa")
  - Các nút có icon và phản hồi hợp lý

### 4. Quản lý Thành Viên
- [ ] Tại `/admin` → Nhấp "Quản lý thành viên"
- [ ] **Kỳ vọng**: Danh sách người dùng hiển thị
- [ ] **Kiểm tra**:
  - Có thể tìm kiếm thành viên
  - Có thể lọc theo vai trò (user/admin)
  - Có thể lọc theo trạng thái (hoạt động/bị khóa)
  - Không thể vô hiệu hóa tài khoản admin hiện tại (admin@gmail.com)
  - **An toàn**: Nếu thử vô hiệu hóa admin, hiển thị lỗi "Không thể vô hiệu hóa tài khoản admin cuối cùng"

### 5. Vô Hiệu Hóa Người Dùng
- [ ] Chọn một người dùng (không phải admin)
- [ ] Nhấp nút "Vô hiệu hóa"
- [ ] **Kỳ vọng**: Người dùng bị khóa, trạng thái thay đổi
- [ ] **Kiểm tra**: Người dùng bị khóa không thể đăng nhập
  - Truy cập `/login` bằng tài khoản bị khóa
  - Nhập email & mật khẩu đúng
  - **Kỳ vọng lỗi**: "Tài khoản của bạn đã bị khóa"

### 6. Kích Hoạt Người Dùng
- [ ] Chọn người dùng bị khóa
- [ ] Nhấp nút "Kích hoạt"
- [ ] **Kỳ vọng**: Người dùng được mở khóa
- [ ] **Kiểm tra**: Người dùng có thể đăng nhập bình thường

### 7. Phê Duyệt Tin Đăng
- [ ] Tại `/admin/posts` → Chọn tin chờ duyệt
- [ ] Nhấp "Duyệt" hoặc "Từ chối"
- [ ] **Kỳ vọng**: Trạng thái tin thay đổi
- [ ] **Kiểm tra**: 
  - Người dùng nhìn thấy tin của mình được duyệt
  - Tin xuất hiện trong danh sách công khai

### 8. Quản lý Danh Mục
- [ ] Tại `/admin` → Nhấp "Quản lý danh mục"
- [ ] **Kỳ vọng**: Danh sách danh mục hiển thị
- [ ] **Kiểm tra**:
  - Có thể tạo danh mục mới
  - Có thể cập nhật danh mục
  - Có thể kích hoạt/vô hiệu hóa danh mục
  - Có thể xóa danh mục

### 9. Đăng Xuất Admin
- [ ] Nhấp vào dropdown user → "Đăng xuất"
- [ ] **Kỳ vọng**: Chuyển hướng đến trang chủ, navbar không hiển thị user menu

### 10. Đăng Nhập Người Dùng Bình Thường
- [ ] Truy cập `/login`
- [ ] Nhập email: `vudovn@gmail.com`
- [ ] Nhập mật khẩu: `Vudo354@`
- [ ] **Kỳ vọng**: Đăng nhập thành công
- [ ] **Kiểm tra**:
  - Navbar hiển thị tên người dùng
  - Không có link "Quản trị viên" trong dropdown
  - Có thể truy cập `/my-posts` để xem tin của mình

## ⚠️ Các tình huống đặc biệt

### Không thể vô hiệu hóa admin duy nhất
- Chỉ còn 1 admin (admin@gmail.com)
- Truy cập `/admin/users` → Tìm admin
- **Kỳ vọng**: Nút "Vô hiệu hóa" bị vô hiệu hóa hoặc hiển thị lỗi

### Không thể xóa tài khoản của chính mình
- Admin đang đăng nhập (admin@gmail.com)
- Tại `/admin/users` → Tìm admin@gmail.com
- **Kỳ vọng**: Nút "Xóa" không hoạt động hoặc hiển thị lỗi

### Session timeout
- Đăng nhập thành công
- Ghi nhớ đăng nhập → 30 ngày
- Không ghi nhớ → 24 giờ
- Sau khi timeout, chuyển hướng đến login

## 🐛 Troubleshooting

### Lỗi "Missing helper: 'not'"
- ✅ Đã sửa: Kiểm tra `config/handlebars-helpers.js` có helper `not`
- Nếu vẫn lỗi: Restart server

### Lỗi "Account has been banned"
- ✅ Đã sửa: `isActive` giờ được lưu vào session
- Kiểm tra: Người dùng vừa mới đăng ký có `isActive: true` trong DB

### Không thể truy cập `/admin`
- Kiểm tra: Đã đăng nhập?
- Kiểm tra: Vai trò là admin?
- Kiểm tra: `requireAuth` và `requireAdmin` middleware trong routes

### Lỗi CSRF
- Tất cả form phải có `<input type="hidden" name="_csrf" value="{{csrfToken}}">`
- ✅ Đã sửa trong tất cả form

## 📊 Kiểm tra API (tuỳ chọn)

```bash
# Đăng nhập
curl -X POST http://localhost:3000/login \
  -d "email=admin@gmail.com&password=admin123"

# Lấy thông tin admin
curl http://localhost:3000/admin \
  -H "Cookie: connect.sid=<session_id>"
```

---
**Ngày cập nhật**: 3/25/2026
**Trạng thái**: ✅ Tất cả lỗi đã sửa
