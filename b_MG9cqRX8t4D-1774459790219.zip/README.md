# Real Estate Rental Platform

A modern, full-stack web application for listing and managing real estate properties for sale or rent. Built with Node.js, Express, MongoDB, and Bootstrap.

## Features

### User Features
- **User Authentication**: Secure registration and login system with bcrypt password hashing
- **User Profiles**: Manage personal information and view posted listings
- **Property Listings**: Create, edit, and delete property advertisements
- **Image Uploads**: Support for multiple images per property with automatic optimization
- **Search & Filter**: Advanced search with category, type, price, and area filters
- **Notifications**: Real-time notifications for listing updates
- **Favorites**: Save favorite properties (future enhancement)

### Admin Features
- **Dashboard**: Overview of site statistics and metrics
- **Post Moderation**: Approve, reject, or feature property listings
- **User Management**: View, activate, or deactivate user accounts
- **Category Management**: Create and manage property categories
- **Report Management**: Handle user reports and complaints

### Technical Features
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile
- **Security**: CSRF protection, input sanitization, secure sessions
- **Performance**: Image optimization, caching strategies, database indexing
- **Scalability**: Designed for MongoDB, supports horizontal scaling
- **Monitoring**: Built-in performance metrics and error logging

## Project Structure

```
├── app.js                  # Application entry point
├── config/                 # Configuration files
│   ├── database.js        # MongoDB connection
│   ├── handlebars-helpers.js  # Handlebars helpers
│   └── multer.js          # File upload configuration
├── controllers/           # Business logic
│   ├── authController.js
│   ├── postsController.js
│   ├── adminController.js
│   └── notificationsController.js
├── models/               # Database schemas
│   ├── User.js
│   ├── Post.js
│   ├── Category.js
│   ├── Notification.js
│   └── History.js
├── routes/              # API routes
│   ├── auth.js
│   ├── posts.js
│   ├── admin.js
│   └── notifications.js
├── middleware/          # Express middleware
│   ├── auth.js         # Authentication checks
│   ├── csrf.js         # CSRF protection
│   ├── validation.js   # Input validation
│   ├── errorHandler.js # Error handling
│   └── flash.js        # Flash messages
├── views/              # Handlebars templates
│   ├── layouts/        # Layout templates
│   ├── posts/          # Post-related views
│   ├── admin/          # Admin views
│   └── ...
├── public/             # Static files
│   ├── css/
│   ├── js/
│   ├── images/
│   └── uploads/        # User-uploaded files
├── utils/              # Utility functions
│   ├── validators.js   # Validation utilities
│   ├── cache.js        # Caching utilities
│   ├── api.js          # API helper functions
│   └── imageProcessor.js  # Image optimization
├── scripts/            # Helper scripts
│   └── seeder.js       # Database seeding
└── package.json        # Dependencies
```

## Getting Started

### Prerequisites
- Node.js 16+ 
- MongoDB 4.4+
- npm or yarn

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/real-estate-platform.git
cd real-estate-platform
```

2. **Install dependencies**
```bash
npm install
```

3. **Configure environment**
```bash
cp .env.example .env
```

Edit `.env` with your configuration:
```
NODE_ENV=development
PORT=3000
MONGODB_URI=mongodb://localhost:27017/bat_dong_san
SESSION_SECRET=your-secret-key-here
```

4. **Initialize database**
```bash
# Run database seeder for test data
npm run seed
```

5. **Start the application**
```bash
# Development with auto-reload
npm run dev

# Production
npm start
```

The application will be available at `http://localhost:3000`

### Test Credentials
- **Admin Email**: admin@example.com
- **Admin Password**: Admin123
- **Test User Email**: user@example.com
- **Test User Password**: User1234

## Development Guide

### Creating New Routes
```javascript
// routes/myroute.js
const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.json({ message: 'Hello' });
});

module.exports = router;

// In app.js
app.use('/myroute', require('./routes/myroute'));
```

### Creating New Controllers
```javascript
// controllers/myController.js
const MyModel = require('../models/MyModel');

module.exports = {
  getAll: async (req, res, next) => {
    try {
      const items = await MyModel.find();
      res.json(items);
    } catch (error) {
      next(error);
    }
  }
};
```

### Creating New Models
```javascript
// models/MyModel.js
const mongoose = require('mongoose');

const schema = new mongoose.Schema({
  name: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('MyModel', schema);
```

### Adding Validation
```javascript
// In controller
const { validatePostData } = require('../utils/validators');

const { isValid, errors } = validatePostData(data);
if (!isValid) {
  return res.status(400).json({ success: false, errors });
}
```

## API Endpoints

### Authentication
- `GET /` - Home page
- `GET /login` - Login page
- `POST /login` - Login
- `GET /register` - Registration page
- `POST /register` - Register
- `POST /logout` - Logout
- `GET /profile` - User profile
- `PUT /profile` - Update profile

### Posts
- `GET /posts` - List all posts
- `GET /posts/create` - Create post form
- `POST /posts` - Create post
- `GET /posts/:id` - View post details
- `GET /posts/:id/edit` - Edit post form
- `PUT /posts/:id` - Update post
- `DELETE /posts/:id` - Delete post
- `GET /my-posts` - User's posts

### Admin
- `GET /admin` - Admin dashboard
- `GET /admin/posts` - Manage posts
- `POST /admin/posts/:id/approve` - Approve post
- `POST /admin/posts/:id/reject` - Reject post
- `GET /admin/users` - Manage users
- `GET /admin/categories` - Manage categories

## Configuration

### Environment Variables
See `.env.example` for all available options:
- Database connection
- Session configuration
- File upload settings
- Rate limiting
- Feature flags

### Security Settings
- Helmet for security headers
- CSRF protection with tokens
- Bcrypt for password hashing
- Input sanitization
- Rate limiting on login

### Performance Optimization
- Image optimization with Sharp
- Database indexing
- Query caching
- Compression middleware
- Lazy loading on frontend

## Testing

```bash
# Run all tests
npm test

# Run specific test file
npm test -- auth.test.js

# Run with coverage
npm test -- --coverage
```

See [TESTING.md](./TESTING.md) for detailed testing guide.

## Deployment

See [DEPLOYMENT.md](./DEPLOYMENT.md) for comprehensive deployment instructions for:
- Vercel
- Heroku
- Self-hosted VPS
- Docker deployment
- Nginx configuration

## Error Handling

See [ERROR_HANDLING.md](./ERROR_HANDLING.md) for:
- Error types and responses
- Validation errors
- Custom error classes
- Error recovery strategies
- Troubleshooting guide

## Performance Monitoring

The application includes built-in performance monitoring:
```javascript
const { PerformanceMonitor } = require('./utils/performance');
const monitor = new PerformanceMonitor();

// Monitor metrics
console.log(monitor.getMetrics());
```

## Security Best Practices

1. **Always validate input** on both client and server
2. **Use HTTPS** in production (enforced via helmet)
3. **Store sensitive data** in environment variables
4. **Hash passwords** with bcrypt (handled by User model)
5. **Use secure cookies** (httpOnly, sameSite)
6. **Implement rate limiting** to prevent abuse
7. **Keep dependencies updated** - run `npm audit`
8. **Monitor error logs** for suspicious activity

## Known Issues

- Image processing may take time on slow connections
- Real-time notifications use polling (consider WebSockets for high traffic)
- Payment integration not yet implemented
- Email notifications require SMTP configuration

## Future Enhancements

- [ ] Payment gateway integration (Stripe/PayPal)
- [ ] Email notifications
- [ ] SMS notifications
- [ ] Two-factor authentication
- [ ] WebSocket real-time notifications
- [ ] Elasticsearch for advanced search
- [ ] Redis caching layer
- [ ] Property comparison tool
- [ ] Favorites and saved searches
- [ ] Virtual tours support

## Troubleshooting

### Application won't start
- Check if MongoDB is running
- Verify `.env` file exists and is properly configured
- Check for port conflicts (default: 3000)
- Review console for error messages

### Database connection issues
- Verify MongoDB connection string
- Check MongoDB service is running
- Verify network access in MongoDB Atlas (if cloud)
- Check firewall rules

### Image upload fails
- Verify `public/uploads` directory exists and is writable
- Check file size is under 5MB
- Verify image format is supported

### Session/Login issues
- Clear browser cookies
- Check `SESSION_SECRET` is set
- Verify browser accepts cookies

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the ISC License - see LICENSE file for details.

## Support

For issues and questions:
1. Check existing issues on GitHub
2. Review documentation in root directory
3. Create new issue with detailed information
4. Contact: support@batdongsan.com

## Changelog

### v1.0.0 (Current)
- Initial release
- User authentication system
- Post management with image uploads
- Admin dashboard
- Search and filtering
- Responsive design
- Security hardening
- Performance optimization

---

Made with ❤️ by the Real Estate Platform Team
