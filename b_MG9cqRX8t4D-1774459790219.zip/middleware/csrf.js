const crypto = require('crypto');

const generateCSRFToken = () => {
  return crypto.randomBytes(32).toString('hex');
};

const csrfProtection = (req, res, next) => {
  // Generate CSRF token if not exists
  if (!req.session.csrfToken) {
    req.session.csrfToken = generateCSRFToken();
  }

  // Expose token to all views
  res.locals.csrfToken = req.session.csrfToken;

  // For GET requests, just set the token and continue
  if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS') {
    return next();
  }

  // For POST/PUT/DELETE requests, validate token
  const token = req.body._csrf || req.headers['x-csrf-token'];

  if (!token || token !== req.session.csrfToken) {
    console.error('[CSRF] Token mismatch - possible attack attempt');
    req.flash('error', 'Token bảo mật không hợp lệ. Vui lòng thử lại.');
    const referer = req.get('Referer') || '/';
    return res.redirect(referer);
  }

  next();
};

module.exports = { csrfProtection, generateCSRFToken };
