const { User } = require("../models");

// In-memory rate limiting store
const attempts = new Map();

const requireAuth = (req, res, next) => {
  if (req.session && req.session.user) {
    return next();
  }

  if (req.xhr || req.headers.accept?.includes("application/json")) {
    return res.status(401).json({
      success: false,
      message: "Vui lòng đăng nhập để tiếp tục",
    });
  }

  req.flash("error", "Vui lòng đăng nhập để tiếp tục");
  res.redirect("/login");
};

const requireGuest = (req, res, next) => {
  if (req.session && req.session.user) {
    return res.redirect("/");
  }
  next();
};

const requireAdmin = (req, res, next) => {
  if (!req.session || !req.session.user) {
    if (req.xhr || req.headers.accept?.includes("application/json")) {
      return res.status(401).json({
        success: false,
        message: "Vui lòng đăng nhập để tiếp tục",
      });
    }
    req.flash("error", "Vui lòng đăng nhập để tiếp tục");
    return res.redirect("/login");
  }

  if (req.session.user.role !== "admin") {
    if (req.xhr || req.headers.accept?.includes("application/json")) {
      return res.status(403).json({
        success: false,
        message: "Bạn không có quyền truy cập",
      });
    }
    req.flash("error", "Bạn không có quyền truy cập");
    return res.redirect("/");
  }

  next();
};

const rateLimitAuth = (maxAttempts, timeWindow) => {
  return (req, res, next) => {
    const ip = req.ip || req.connection.remoteAddress;
    const now = Date.now();
    const userAttempts = attempts.get(ip) || [];
    const recentAttempts = userAttempts.filter(time => now - time < timeWindow);

    if (recentAttempts.length >= maxAttempts) {
      if (req.xhr || req.headers.accept?.includes("application/json")) {
        return res.status(429).json({
          success: false,
          message: "Quá nhiều lần đăng nhập không thành công. Vui lòng thử lại sau",
        });
      }
      req.flash("error", "Quá nhiều lần đăng nhập không thành công. Vui lòng thử lại sau");
      return res.status(429).redirect("/login");
    }

    next();

    req.recordAuthAttempt = () => {
      recentAttempts.push(now);
      attempts.set(ip, recentAttempts);
    };
  };
};

const loadUser = (req, res, next) => {
  if (req.session && req.session.user) {
    // Set both req.user and res.locals.user for consistency
    req.user = req.session.user;
    res.locals.user = req.session.user;
    res.locals.isAuth = true;
  } else {
    req.user = null;
    res.locals.isAuth = false;
  }
  next();
};

const secureSession = (req, res, next) => {
  if (req.session && req.session.user) {
    req.session.touch();
  }
  next();
};

const requireActiveAccount = async (req, res, next) => {
  // If no user is logged in, proceed (other middlewares will handle auth)
  if (!req.session || !req.session.user) {
    return next();
  }

  try {
    // Check database to ensure account is still active (in case it was deactivated)
    const user = await User.findById(req.session.user._id);
    
    if (!user || !user.isActive) {
      delete req.session.user;
      req.flash("error", "Tài khoản của bạn đã bị khóa");
      return res.redirect("/login");
    }

    // Update session with latest isActive status in case it was changed
    req.session.user.isActive = user.isActive;
    next();
  } catch (error) {
    console.error("Error checking active account:", error);
    next();
  }
};

module.exports = {
  requireAuth,
  requireGuest,
  requireAdmin,
  rateLimitAuth,
  loadUser,
  secureSession,
  requireActiveAccount,
};
