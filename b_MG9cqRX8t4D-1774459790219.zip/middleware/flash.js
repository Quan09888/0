
const flash = (req, res, next) => {
    // Initialize flash storage in session
    if (!req.session.flash) {
        req.session.flash = {};
    }

    // Method to add flash messages
    req.flash = (type, message) => {
        if (!req.session.flash[type]) {
            req.session.flash[type] = [];
        }
        req.session.flash[type].push(message);
    };

    // Get flash messages and clear them (for display)
    const flashMessages = req.session.flash || {};
    
    // Set flash messages for templates
    res.locals.success = flashMessages.success ? flashMessages.success[0] : null;
    res.locals.error = flashMessages.error ? flashMessages.error[0] : null;
    res.locals.warning = flashMessages.warning ? flashMessages.warning[0] : null;
    res.locals.info = flashMessages.info ? flashMessages.info[0] : null;
    
    // Clear flash messages after reading
    req.session.flash = {};
    
    next();
};

module.exports = flash;
