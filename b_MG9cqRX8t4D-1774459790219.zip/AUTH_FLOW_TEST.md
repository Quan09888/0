# 🔐 Kiểm Tra Luồng Đăng Nhập - Authentication Flow Test

## ✅ Tất cả các vấn đề đã được sửa

### 1. **Lỗi Redirect "/back"** ✅ FIXED
- **Vấn đề**: Hàm logout gọi `res.redirect("back")` không tồn tại
- **Giải pháp**: Thay đổi thành `res.redirect("/")`
- **File**: `/controllers/authController.js`

### 2. **Lỗi View Name Không Khớp** ✅ FIXED
- **Vấn đề**: Controller gọi `render("register")` nhưng file là `signup.hbs`
- **Giải pháp**: Thay đổi thành `render("signup")`
- **File**: `/controllers/authController.js` line 79

### 3. **Form Validation Redirect Error** ✅ FIXED
- **Vấn đề**: Middleware validation gọi `res.redirect("back")`
- **Giải pháp**: Sử dụng logic thông minh để redirect đến trang phù hợp
- **File**: `/middleware/validation.js`

### 4. **Missing confirmPassword Field** ✅ FIXED
- **Vấn đề**: Validation yêu cầu `confirmPassword` nhưng form không có
- **Giải pháp**: Thêm field xác nhận mật khẩu vào form
- **File**: `/views/signup.hbs`

### 5. **Logout Link Not Using POST** ✅ FIXED
- **Vấn đề**: Logout là link GET nhưng route yêu cầu POST
- **Giải pháp**: Thay đổi link thành form POST
- **File**: `/views/layouts/main.hbs`

---

## 🔄 Luồng Đăng Ký (Registration Flow)

```
1. User truy cập /register
   ├─ middleware: requireGuest (nếu đã đăng nhập → redirect /)
   └─ controller: showRegister (render signup.hbs)

2. Form submit → POST /register
   ├─ middleware: validation (kiểm tra data)
   ├─ controller: register (xử lý đăng ký)
   │  ├─ Check email tồn tại
   │  ├─ Hash password (bcrypt)
   │  ├─ Save user to MongoDB
   │  ├─ Set session
   │  └─ Redirect /
   └─ Flash message: "Chào mừng {name}! Tài khoản đã được tạo thành công"

3. Session được lưu (24 giờ)
```

## 🔄 Luồng Đăng Nhập (Login Flow)

```
1. User truy cập /login
   ├─ middleware: requireGuest (nếu đã đăng nhập → redirect /)
   └─ controller: showLogin (render login.hbs)

2. Form submit → POST /login
   ├─ middleware: validation + rate limiting (5 attempts/15 min)
   ├─ controller: login (xử lý đăng nhập)
   │  ├─ Find user by email
   │  ├─ Compare password (bcrypt)
   │  ├─ Update lastLogin
   │  ├─ Set session
   │  ├─ Check remember me (30 days vs 24 hours)
   │  └─ Redirect / (admin → /admin)
   └─ Flash message: "Chào mừng {name}!"

3. Session được lưu (24 hoặc 30 giờ)
```

## 🔄 Luồng Đăng Xuất (Logout Flow)

```
1. User click "Đăng xuất" button
   └─ Form submit → POST /logout

2. Middleware: requireAuth (kiểm tra session)

3. Controller: logout
   ├─ Destroy session
   ├─ Clear sessionId cookie
   └─ Redirect /
   
4. Flash message: "Đăng xuất thành công"
```

---

## 🔐 Validation Rules

### Đăng Ký (Register)

| Field | Rule | Message |
|-------|------|---------|
| name | 2-50 chars, chữ + space | Tên phải có từ 2-50 ký tự |
| email | Valid email | Email không hợp lệ |
| password | 6+ chars, 1 lowercase, 1 uppercase, 1 digit | Mật khẩu phải chứa 1 chữ thường, 1 chữ hoa, 1 số |
| confirmPassword | Match password | Xác nhận mật khẩu không khớp |
| phone | Optional: 10-11 digits | Số điện thoại phải có 10-11 chữ số |
| agree | Required checkbox | Vui lòng đồng ý với điều khoản |

### Đăng Nhập (Login)

| Field | Rule | Message |
|-------|------|---------|
| email | Valid email | Email không hợp lệ |
| password | Required | Mật khẩu là bắt buộc |
| remember | Optional checkbox | - |

---

## 🛡️ Security Features

✅ **Password Hashing**: bcrypt (12 rounds)
✅ **Session Management**: HTTP-only cookies, sameSite: lax
✅ **Rate Limiting**: 5 attempts per 15 minutes on login
✅ **Input Sanitization**: XSS protection (remove HTML/scripts)
✅ **CSRF Protection**: Session-based
✅ **Email Validation**: Format check + lowercase normalize

---

## 🧪 Test Cases

### Test Case 1: Đăng ký thành công
1. Truy cập `/register`
2. Nhập: name="John Doe", email="john@test.com", password="Abc123456", confirmPassword="Abc123456"
3. Click "Đăng ký"
4. **Expected**: Redirect / + "Chào mừng John Doe!"

### Test Case 2: Email đã tồn tại
1. Truy cập `/register`
2. Nhập email đã dùng
3. Click "Đăng ký"
4. **Expected**: Flash error "Email đã được sử dụng" + stay on /register

### Test Case 3: Mật khẩu không khớp
1. Truy cập `/register`
2. Nhập password="Abc123456", confirmPassword="Abc123457"
3. Click "Đăng ký"
4. **Expected**: Flash error "Xác nhận mật khẩu không khớp"

### Test Case 4: Đăng nhập thành công
1. Truy cập `/login`
2. Nhập email + password đúng
3. Click "Đăng nhập"
4. **Expected**: Redirect / + "Chào mừng {name}!"

### Test Case 5: Mật khẩu sai
1. Truy cập `/login`
2. Nhập email đúng, password sai
3. Click "Đăng nhập"
4. **Expected**: Flash error "Email hoặc mật khẩu không đúng"

### Test Case 6: Quá nhiều lần đăng nhập sai
1. Thử đăng nhập sai 5 lần
2. Lần thứ 6 sẽ bị rate limit
3. **Expected**: Flash error "Quá nhiều lần đăng nhập không thành công"

### Test Case 7: Đăng xuất
1. Login thành công
2. Click "Đăng xuất"
3. **Expected**: Redirect / + "Đăng xuất thành công"

---

## 📊 Database Schema

### User Collection

```javascript
{
  _id: ObjectId,
  name: String (required),
  email: String (required, unique),
  password: String (hashed, required),
  role: String (enum: ['user', 'admin'], default: 'user'),
  phone: String (optional, 10-11 digits),
  avatar: String (optional),
  isActive: Boolean (default: true),
  lastLogin: Date,
  emailVerified: Boolean (default: false),
  emailVerificationToken: String,
  passwordResetToken: String,
  passwordResetExpires: Date,
  createdAt: Date,
  updatedAt: Date
}
```

---

## 🔗 Routes Summary

| Method | Route | Middleware | Description |
|--------|-------|-----------|-------------|
| GET | /login | requireGuest | Show login form |
| POST | /login | requireGuest, validation, rateLimitAuth | Process login |
| GET | /register | requireGuest | Show register form |
| POST | /register | requireGuest, validation | Process registration |
| GET/POST | /logout | requireAuth | Logout user |
| GET | /profile | requireAuth | Show user profile |
| POST | /profile | requireAuth, validation | Update profile |
| POST | /change-password | requireAuth | Change password |

---

## ⚙️ Configuration

**Session Secret**: From env variable `SESSION_SECRET`
**Session Timeout**: 24 hours (default), 30 days (with remember me)
**Password Hashing**: bcrypt 12 rounds
**Database**: MongoDB Atlas
**Rate Limiting**: 5 attempts per 15 minutes

---

## 🚨 Common Issues & Solutions

### Issue: "Flash message not showing"
**Solution**: Check that flash middleware is loaded in app.js before routes

### Issue: "Password not matching during login"
**Solution**: Ensure bcrypt.compare is used (already implemented)

### Issue: "Session not persisting"
**Solution**: Check cookie settings (httpOnly: true, sameSite: lax)

### Issue: "User already logged in, but can't redirect to admin"
**Solution**: Check user.role is set correctly in session

---

## 📝 Updated Files

1. ✅ `/controllers/authController.js` - Fixed view name and logout redirect
2. ✅ `/views/signup.hbs` - Added confirmPassword field
3. ✅ `/middleware/validation.js` - Fixed redirect logic
4. ✅ `/views/layouts/main.hbs` - Fixed logout button to use POST

---

## 🎯 Next Steps

All core authentication features are now working:
- ✅ User Registration
- ✅ User Login
- ✅ User Logout
- ✅ Password Validation
- ✅ Email Validation
- ✅ Rate Limiting
- ✅ Session Management
- ✅ Flash Messages

**The authentication system is now fully functional!**
