/**
 * Application Constants
 * Centralized configuration for magic values and constants
 */

module.exports = {
  // Pagination
  PAGINATION: {
    DEFAULT_LIMIT: 12,
    ADMIN_LIMIT: 20,
    MAX_LIMIT: 100,
  },

  // Post related
  POST: {
    STATUS: {
      PENDING: null,
      APPROVED: true,
      REJECTED: false,
    },
    DEFAULT_EXPIRY_DAYS: 30,
    MIN_TITLE_LENGTH: 10,
    MAX_TITLE_LENGTH: 200,
    MIN_DESCRIPTION_LENGTH: 50,
    MAX_DESCRIPTION_LENGTH: 2000,
    MIN_ADDRESS_LENGTH: 10,
    MAX_ADDRESS_LENGTH: 500,
    MAX_IMAGES: 5,
    IMAGE_MAX_SIZE: 5 * 1024 * 1024, // 5MB
    VALID_TYPES: ["bán", "cho thuê"],
    VALID_CATEGORIES: [
      "chung cư",
      "nhà riêng",
      "đất nền",
      "nhà mặt phố",
      "biệt thự",
      "shophouse",
      "kho xưởng",
      "văn phòng",
    ],
  },

  // User related
  USER: {
    ROLE: {
      ADMIN: "admin",
      USER: "user",
    },
    STATUS: {
      ACTIVE: true,
      INACTIVE: false,
    },
    MIN_PASSWORD_LENGTH: 6,
    PASSWORD_PATTERN: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{6,}$/,
    PHONE_PATTERN: /^[0-9]{10,11}$/,
    EMAIL_PATTERN: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    BCRYPT_ROUNDS: 10,
  },

  // Auth
  AUTH: {
    SESSION_SECRET: process.env.SESSION_SECRET || "your-secret-key-here",
    SESSION_TIMEOUT: 24 * 60 * 60 * 1000, // 24 hours
    RATE_LIMIT_ATTEMPTS: 5,
    RATE_LIMIT_WINDOW: 15 * 60 * 1000, // 15 minutes
    PASSWORD_RESET_TIMEOUT: 10 * 60 * 1000, // 10 minutes
  },

  // File uploads
  FILE: {
    UPLOAD_DIR: "public/uploads",
    ALLOWED_EXTENSIONS: [".jpg", ".jpeg", ".png", ".gif", ".svg"],
    ALLOWED_MIME_TYPES: [
      "image/jpeg",
      "image/png",
      "image/gif",
      "image/svg+xml",
    ],
  },

  // Database
  DATABASE: {
    MONGODB_URI: process.env.MONGODB_URI || "mongodb://localhost:27017/realestate",
    CACHE_TTL: 60 * 60, // 1 hour
  },

  // Messages
  MESSAGES: {
    SUCCESS: {
      LOGIN: "Đăng nhập thành công",
      REGISTER: "Đăng ký thành công",
      LOGOUT: "Đăng xuất thành công",
      CREATE_POST: "Đăng tin thành công",
      UPDATE_POST: "Cập nhật tin đăng thành công",
      DELETE_POST: "Xóa tin đăng thành công",
      UPDATE_PROFILE: "Cập nhật hồ sơ thành công",
      CHANGE_PASSWORD: "Đổi mật khẩu thành công",
    },
    ERROR: {
      INVALID_EMAIL_PASSWORD: "Email hoặc mật khẩu không đúng",
      ACCOUNT_LOCKED: "Tài khoản đã bị khóa",
      UNAUTHORIZED: "Bạn không có quyền truy cập",
      SERVER_ERROR: "Có lỗi xảy ra. Vui lòng thử lại",
      NOT_FOUND: "Tài nguyên không tồn tại",
      DUPLICATE_EMAIL: "Email đã được sử dụng",
      INVALID_INPUT: "Dữ liệu không hợp lệ",
    },
  },

  // API Response
  API: {
    STATUS_CODES: {
      OK: 200,
      CREATED: 201,
      BAD_REQUEST: 400,
      UNAUTHORIZED: 401,
      FORBIDDEN: 403,
      NOT_FOUND: 404,
      CONFLICT: 409,
      SERVER_ERROR: 500,
    },
  },

  // Feature flags
  FEATURES: {
    ENABLE_EMAIL_VERIFICATION: true,
    ENABLE_NOTIFICATIONS: true,
    ENABLE_FAVORITES: true,
    ENABLE_MESSAGING: false,
    ENABLE_REVIEWS: false,
  },

  // Environment
  NODE_ENV: process.env.NODE_ENV || "development",
  IS_PRODUCTION: process.env.NODE_ENV === "production",
  IS_DEVELOPMENT: process.env.NODE_ENV === "development",
};
