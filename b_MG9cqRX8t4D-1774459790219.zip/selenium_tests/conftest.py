import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium_tests.config import BASE_URL, HEADLESS, IMPLICIT_WAIT, PAGE_LOAD_TIMEOUT


@pytest.fixture(scope="function")
def driver():
    """Initialize Chrome WebDriver for each test function."""
    options = webdriver.ChromeOptions()

    if HEADLESS:
        options.add_argument("--headless=new")

    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--start-maximized")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)

    _driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=options,
    )
    _driver.implicitly_wait(IMPLICIT_WAIT)
    _driver.set_page_load_timeout(PAGE_LOAD_TIMEOUT)
    # Store base_url on the driver instance for easy access inside page objects
    _driver.base_url = BASE_URL

    yield _driver

    _driver.quit()


@pytest.fixture(scope="session")
def base_url():
    """Return the application base URL (session-scoped)."""
    return BASE_URL
