import os
from dotenv import load_dotenv

load_dotenv()

# ------------------------------------------------------------------ Server
BASE_URL = os.getenv("BASE_URL", "http://localhost:3000")

# ------------------------------------------------------------------ WebDriver
HEADLESS = os.getenv("HEADLESS", "False").lower() == "true"
IMPLICIT_WAIT = int(os.getenv("IMPLICIT_WAIT", "10"))
PAGE_LOAD_TIMEOUT = int(os.getenv("PAGE_LOAD_TIMEOUT", "15"))
EXPLICIT_WAIT = int(os.getenv("EXPLICIT_WAIT", "15"))

# ------------------------------------------------------------------ Test Accounts
TEST_USER_EMAIL = os.getenv("TEST_USER_EMAIL", "user@test.com")
TEST_USER_PASSWORD = os.getenv("TEST_USER_PASSWORD", "123456")
TEST_ADMIN_EMAIL = os.getenv("TEST_ADMIN_EMAIL", "admin@test.com")
TEST_ADMIN_PASSWORD = os.getenv("TEST_ADMIN_PASSWORD", "admin123")
TEST_INVALID_EMAIL = "notexist@test.com"
TEST_DEACTIVATED_EMAIL = os.getenv("TEST_DEACTIVATED_EMAIL", "deactivated@test.com")

# ------------------------------------------------------------------ URLs
LOGIN_URL = "/login"
REGISTER_URL = "/register"
HOME_URL = "/"
ADMIN_URL = "/admin"
PROFILE_URL = "/profile"
CREATE_POST_URL = "/posts/create"
MY_POSTS_URL = "/my-posts"
LISTING_URL = "/bat-dong-san"
FORGOT_PASSWORD_URL = "/forgot-password"

# ------------------------------------------------------------------ Test Data – Posts
VALID_POST = {
    "title": "Bán căn hộ Vinhome 2PN view sông",
    "description": "Căn hộ đẹp, nội thất đầy đủ, thoáng mát.",
    "price": "3000000000",
    "area": "75",
    "address": "123 Nguyễn Văn Linh, Quận 7, TP.HCM",
    "phone": "0901234567",
}

# ------------------------------------------------------------------ Test Data – Admin
ADMIN_TEST_POST_TITLE = "Bán đất nền dự án mới tại Đà Nẵng"
ADMIN_TEST_USER_EMAIL = "tranthib@gmail.com"
ADMIN_TEST_USER_NAME = "Nguyễn Văn A"
ADMIN_TEST_CATEGORY = "Chung cư"
