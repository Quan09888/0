"""
Test Suite: Cập Nhật Tin Đăng (Update Post)
Test Cases: TC_PostUpDate_001 – TC_PostUpDate_011

Status summary:
  Pass  : TC_PostUpDate_001–004, 006–010
  Fail  : TC_PostUpDate_005  → xfail  (SĐT không hợp lệ được chấp nhận – bug)
  Fail  : TC_PostUpDate_011  → xfail  (Hủy không hỏi xác nhận, chuyển về chờ duyệt – bug)
"""
import time
import os
import pytest
from selenium_tests.pages.update_post_page import UpdatePostPage
from selenium_tests.config import (
    BASE_URL,
    TEST_USER_EMAIL,
    TEST_USER_PASSWORD,
)

# ---------------------------------------------------------------------------
# Dummy image helper
# ---------------------------------------------------------------------------
def _dummy_image_paths(count=1, size_mb=0.1):
    """Create minimal JPEG dummy files in /tmp for upload tests."""
    paths = []
    for i in range(count):
        path = f"/tmp/update_test_img_{i}_{size_mb}mb.jpg"
        if not os.path.exists(path):
            jpeg_magic = bytes([
                0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46,
                0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
                0x00, 0x01, 0x00, 0x00, 0xFF, 0xD9
            ])
            target_bytes = int(size_mb * 1024 * 1024)
            padding = b"\x00" * max(0, target_bytes - len(jpeg_magic))
            with open(path, "wb") as f:
                f.write(jpeg_magic + padding)
        paths.append(path)
    return paths


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------
@pytest.fixture
def page(driver):
    return UpdatePostPage(driver, BASE_URL)


@pytest.fixture
def logged_in_page(page):
    """Login as user and navigate to my-posts."""
    page.login(TEST_USER_EMAIL, TEST_USER_PASSWORD)
    page.navigate_to_my_posts()
    time.sleep(1)
    return page


@pytest.fixture
def edit_page(logged_in_page):
    """
    Login, navigate to my-posts, and click first Edit button to open edit form.
    Skips the test if no editable post is found.
    """
    page = logged_in_page
    opened = page.click_first_edit_button()
    if not opened:
        pytest.skip(
            "Không tìm thấy tin đăng có thể chỉnh sửa. "
            "Cần seed ít nhất 1 tin đăng có thể sửa cho tài khoản test."
        )
    time.sleep(1)
    return page


# ---------------------------------------------------------------------------
# TC_PostUpDate_001: Cập nhật Tiêu đề và Mô tả thành công
# ---------------------------------------------------------------------------
class TestTC_PostUpDate_001:
    def test_update_title_and_description_success(self, edit_page):
        """
        TC_PostUpDate_001 – Cập nhật Tiêu đề và Mô tả thành công
        Steps: Thay đổi Tiêu đề và Mô tả, nhấn Cập nhật tin đăng.
        Expected: Thông báo thành công, trạng thái chuyển "Chờ duyệt".
        Status: Pass | Priority: High
        """
        page = edit_page
        new_title = "Bán gấp căn hộ 2PN, view sông"
        new_desc = "Đã cập nhật Mô tả chi tiết"

        page.update_title(new_title)
        page.update_description(new_desc)
        page.click_submit()
        time.sleep(2)

        success_msg = page.get_success_message()
        any_alert = page.get_any_alert_message()
        current_url = page.get_current_url()

        assert (
            success_msg is not None
            or (any_alert and "thành công" in any_alert.lower())
            or "my-posts" in current_url
        ), f"Phải hiển thị thông báo thành công sau khi cập nhật. Alert: {any_alert}"

        # Verify status changed to pending review
        status = page.get_post_status_after_update()
        if status:
            assert (
                "chờ" in status.lower()
                or "duyệt" in status.lower()
                or "pending" in status.lower()
            ), f"Trạng thái sau cập nhật phải là 'Chờ duyệt', hiện tại: '{status}'"


# ---------------------------------------------------------------------------
# TC_PostUpDate_002: Cập nhật Giá và Diện tích với giá trị hợp lệ
# ---------------------------------------------------------------------------
class TestTC_PostUpDate_002:
    def test_update_price_and_area_valid(self, edit_page):
        """
        TC_PostUpDate_002 – Cập nhật Giá và Diện tích với giá trị hợp lệ
        Steps: Thay đổi Giá = 2800000000, Diện tích = 80, nhấn Cập nhật.
        Expected: Thông báo thành công, trạng thái "Chờ duyệt".
        Status: Pass | Priority: High
        """
        page = edit_page
        page.update_price("2800000000")
        page.update_area("80")
        page.click_submit()
        time.sleep(2)

        success_msg = page.get_success_message()
        any_alert = page.get_any_alert_message()
        current_url = page.get_current_url()

        assert (
            success_msg is not None
            or (any_alert and "thành công" in any_alert.lower())
            or "my-posts" in current_url
        ), f"Phải hiển thị thông báo thành công. Alert: {any_alert}"

        status = page.get_post_status_after_update()
        if status:
            assert (
                "chờ" in status.lower()
                or "duyệt" in status.lower()
                or "pending" in status.lower()
            ), f"Trạng thái phải là 'Chờ duyệt', hiện tại: '{status}'"


# ---------------------------------------------------------------------------
# TC_PostUpDate_003: Kiểm tra tính toàn vẹn Loại hình → Loại BĐS
# ---------------------------------------------------------------------------
class TestTC_PostUpDate_003:
    def test_listing_type_change_updates_property_type_dropdown(self, edit_page):
        """
        TC_PostUpDate_003 – Kiểm tra tính toàn vẹn của dữ liệu Loại hình/Loại BĐS
        Steps: Thay đổi Loại hình từ Bán sang Cho thuê, kiểm tra dropdown Loại BĐS, cập nhật.
        Expected: Dropdown Loại BĐS cập nhật đúng, tin đăng được lưu.
        Status: Pass | Priority: Medium
        """
        page = edit_page

        page.select_listing_type("Bán")
        time.sleep(0.5)
        options_ban = page.get_property_type_options()

        page.select_listing_type("Cho thuê")
        time.sleep(0.5)
        options_cho_thue = page.get_property_type_options()

        assert len(options_ban) > 0 or len(options_cho_thue) > 0, (
            "Dropdown Loại BĐS phải có ít nhất 1 option"
        )

        page.click_submit()
        time.sleep(2)

        success_msg = page.get_success_message()
        any_alert = page.get_any_alert_message()
        current_url = page.get_current_url()

        assert (
            success_msg is not None
            or (any_alert and "thành công" in any_alert.lower())
            or "my-posts" in current_url
        ), "Phải cập nhật thành công sau khi thay đổi Loại hình"


# ---------------------------------------------------------------------------
# TC_PostUpDate_004: Cố gắng xóa Tiêu đề (để trống trường bắt buộc)
# ---------------------------------------------------------------------------
class TestTC_PostUpDate_004:
    def test_clear_title_shows_validation_error(self, edit_page):
        """
        TC_PostUpDate_004 – Cố gắng xóa Tiêu đề (để trống trường bắt buộc)
        Steps: Xóa nội dung trường Tiêu đề, nhấn Cập nhật.
        Expected: Hệ thống thông báo 'tin không hợp lệ', yêu cầu nhập đầy đủ.
        Status: Pass | Priority: High
        """
        page = edit_page
        page.clear_title()
        page.click_submit()
        time.sleep(1)

        title_error = page.get_title_error()
        html5_msg = page.get_html5_validation_message(UpdatePostPage.TITLE_INPUT)
        any_error = page.get_error_message() or page.get_any_alert_message()

        assert (
            title_error is not None
            or len(html5_msg) > 0
            or any_error is not None
        ), "Phải hiển thị lỗi khi Tiêu đề bị để trống"


# ---------------------------------------------------------------------------
# TC_PostUpDate_005: Cập nhật SĐT không hợp lệ
# BUG: Hệ thống cho phép lưu SĐT không hợp lệ → actual = thành công (sai)
# ---------------------------------------------------------------------------
class TestTC_PostUpDate_005:
    @pytest.mark.xfail(
        reason="BUG: Hệ thống không validate SĐT không hợp lệ khi cập nhật "
               "– cho phép lưu thay vì báo lỗi (TC_PostUpDate_005 Status: Fail)"
    )
    def test_invalid_phone_update_rejected(self, edit_page):
        """
        TC_PostUpDate_005 – Cập nhật Số điện thoại với định dạng không hợp lệ
        Steps: Cập nhật SĐT = "3618361836.", nhấn Cập nhật.
        Expected: Lỗi "Số điện thoại không hợp lệ (hoặc quá ngắn)".
        Actual: Hệ thống lưu thành công – BUG.
        Status: Fail | Priority: High
        """
        page = edit_page
        page.update_phone("3618361836.")
        page.click_submit()
        time.sleep(1)

        phone_error = page.get_phone_error()
        any_error = page.get_error_message() or page.get_any_alert_message()

        assert (
            phone_error is not None
            or (any_error and ("điện thoại" in any_error.lower() or "sđt" in any_error.lower()))
        ), "Phải hiển thị lỗi SĐT không hợp lệ (BUG: hệ thống cho phép lưu)"


# ---------------------------------------------------------------------------
# TC_PostUpDate_006: Cập nhật Giá thành số âm
# ---------------------------------------------------------------------------
class TestTC_PostUpDate_006:
    def test_negative_price_rejected(self, edit_page):
        """
        TC_PostUpDate_006 – Cập nhật Giá thành số âm
        Steps: Nhập Giá = -100000000, nhấn Cập nhật.
        Expected: Lỗi "Giá trị không hợp lệ".
        Status: Pass | Priority: Medium
        """
        page = edit_page
        page.update_price("-100000000")
        page.click_submit()
        time.sleep(1)

        price_error = page.get_price_error()
        html5_msg = page.get_html5_validation_message(UpdatePostPage.PRICE_INPUT)
        any_error = page.get_error_message() or page.get_any_alert_message()

        assert (
            price_error is not None
            or len(html5_msg) > 0
            or any_error is not None
        ), "Phải hiển thị lỗi khi Giá là số âm"


# ---------------------------------------------------------------------------
# TC_PostUpDate_007: Thêm ảnh mới khi đã có ảnh cũ (tổng <= 5)
# ---------------------------------------------------------------------------
class TestTC_PostUpDate_007:
    def test_add_new_images_within_limit(self, edit_page):
        """
        TC_PostUpDate_007 – Thêm ảnh mới khi đã có ảnh cũ (tổng <= 5)
        Pre-condition: Tin đăng hiện tại có 2 ảnh cũ.
        Steps: Tải lên 3 ảnh mới, nhấn Cập nhật.
        Expected: Tổng 5 ảnh (2+3) lưu thành công, thông báo thành công.
        Status: Pass | Priority: High
        """
        page = edit_page
        initial_count = page.get_image_count()
        if initial_count < 2:
            pytest.skip(
                f"Test yêu cầu tin đăng có ít nhất 2 ảnh cũ, hiện có {initial_count} ảnh."
            )

        new_images = _dummy_image_paths(count=3, size_mb=0.1)
        page.upload_new_images(new_images)
        time.sleep(1)

        image_limit_error = page.get_image_limit_error()
        assert image_limit_error is None, (
            f"Không được báo lỗi giới hạn khi tổng ảnh <= 5. Lỗi: {image_limit_error}"
        )

        page.click_submit()
        time.sleep(2)

        success_msg = page.get_success_message()
        any_alert = page.get_any_alert_message()
        current_url = page.get_current_url()

        assert (
            success_msg is not None
            or (any_alert and "thành công" in any_alert.lower())
            or "my-posts" in current_url
        ), "Phải lưu thành công khi tổng ảnh = 5"


# ---------------------------------------------------------------------------
# TC_PostUpDate_008: Thêm ảnh mới khiến tổng vượt quá 5
# ---------------------------------------------------------------------------
class TestTC_PostUpDate_008:
    def test_add_images_exceeding_limit_shows_warning(self, edit_page):
        """
        TC_PostUpDate_008 – Thêm ảnh mới khiến tổng vượt quá 5
        Pre-condition: Tin đăng hiện tại có 4 ảnh cũ.
        Steps: Tải lên 3 ảnh mới (tổng 7 > 5).
        Expected: Cảnh báo "Đã đạt giới hạn tối đa 5 ảnh".
        Status: Pass | Priority: High
        """
        page = edit_page
        initial_count = page.get_image_count()
        if initial_count < 4:
            pytest.skip(
                f"Test yêu cầu tin đăng có ít nhất 4 ảnh cũ, hiện có {initial_count} ảnh."
            )

        new_images = _dummy_image_paths(count=3, size_mb=0.1)
        page.upload_new_images(new_images)
        time.sleep(1)

        image_limit_error = page.get_image_limit_error()
        any_alert = page.get_any_alert_message()
        final_count = page.get_image_count()

        assert (
            image_limit_error is not None
            or (any_alert and ("5" in any_alert or "tối đa" in any_alert.lower() or "giới hạn" in any_alert.lower()))
            or final_count <= 5
        ), "Phải cảnh báo hoặc giới hạn tổng ảnh không vượt 5"


# ---------------------------------------------------------------------------
# TC_PostUpDate_009: Xóa ảnh cũ và Cập nhật
# ---------------------------------------------------------------------------
class TestTC_PostUpDate_009:
    def test_delete_old_images_and_update(self, edit_page):
        """
        TC_PostUpDate_009 – Xóa ảnh cũ và Cập nhật
        Pre-condition: Tin đăng hiện tại có 4 ảnh cũ.
        Steps: Xóa 2 ảnh cũ, nhấn Cập nhật.
        Expected: Thông báo thành công.
        Status: Pass | Priority: High
        """
        page = edit_page
        initial_count = page.get_image_count()
        if initial_count < 2:
            pytest.skip(
                f"Test yêu cầu tin đăng có ít nhất 2 ảnh cũ, hiện có {initial_count} ảnh."
            )

        page.delete_images(count=2)
        time.sleep(0.5)

        after_delete_count = page.get_image_count()
        assert after_delete_count == initial_count - 2 or after_delete_count < initial_count, (
            f"Số ảnh phải giảm sau khi xóa. Trước: {initial_count}, Sau: {after_delete_count}"
        )

        page.click_submit()
        time.sleep(2)

        success_msg = page.get_success_message()
        any_alert = page.get_any_alert_message()
        current_url = page.get_current_url()

        assert (
            success_msg is not None
            or (any_alert and "thành công" in any_alert.lower())
            or "my-posts" in current_url
        ), "Phải hiển thị thông báo thành công sau khi xóa ảnh và cập nhật"


# ---------------------------------------------------------------------------
# TC_PostUpDate_010: Trạng thái tin đăng sau khi Cập nhật thành công
# ---------------------------------------------------------------------------
class TestTC_PostUpDate_010:
    def test_post_status_becomes_pending_after_update(self, edit_page):
        """
        TC_PostUpDate_010 – Kiểm tra trạng thái tin đăng sau khi Cập nhật thành công
        Pre-condition: Tin đăng đang ở trạng thái Đã duyệt.
        Steps: Chỉnh sửa một trường bất kỳ, nhấn Cập nhật.
        Expected: Tin đăng chuyển về trạng thái "Chờ duyệt".
        Status: Pass | Priority: Critical
        """
        page = edit_page

        # Thay đổi tiêu đề nhỏ để trigger status change
        current_title = page.get_title_value() or "Tiêu đề cũ"
        page.update_title(current_title + " (đã chỉnh sửa)")
        page.click_submit()
        time.sleep(2)

        status = page.get_post_status_after_update()

        assert status is not None, (
            "Phải đọc được trạng thái của tin đăng sau khi cập nhật"
        )
        assert (
            "chờ" in status.lower()
            or "duyệt" in status.lower()
            or "pending" in status.lower()
        ), (
            f"Tin đăng phải chuyển về 'Chờ duyệt' sau khi chỉnh sửa. "
            f"Trạng thái hiện tại: '{status}'"
        )


# ---------------------------------------------------------------------------
# TC_PostUpDate_011: Nhấn nút Hủy trên trang chỉnh sửa
# BUG: Hệ thống chuyển trạng thái tin đăng thành "chờ duyệt" thay vì hỏi xác nhận
# ---------------------------------------------------------------------------
class TestTC_PostUpDate_011:
    @pytest.mark.xfail(
        reason="BUG: Nhấn Hủy không hiển thị dialog xác nhận mà chuyển tin về "
               "'chờ duyệt' – dữ liệu không giữ nguyên (TC_PostUpDate_011 Status: Fail)"
    )
    def test_cancel_button_shows_confirmation_and_preserves_data(self, edit_page):
        """
        TC_PostUpDate_011 – Nhấn nút Hủy trên trang chỉnh sửa
        Steps: Thay đổi Tiêu đề và Mô tả, nhấn Hủy.
        Expected:
          1. Hệ thống hỏi xác nhận "Các thay đổi sẽ không được lưu. Bạn có muốn hủy?"
          2. Sau khi xác nhận Hủy → điều hướng đi, dữ liệu tin đăng không thay đổi.
        Actual: Không hiện dialog, hệ thống chuyển tin về "chờ duyệt" – BUG.
        Status: Fail | Priority: High
        """
        page = edit_page
        original_title = page.get_title_value()

        page.update_title("Tiêu đề tạm thời sẽ bị hủy")
        page.update_description("Mô tả tạm thời sẽ bị hủy")
        page.click_cancel()
        time.sleep(1)

        # Expected: a confirmation modal or dialog appears
        is_modal = page.is_confirm_modal_visible()
        try:
            from selenium.webdriver.support.ui import WebDriverWait
            from selenium.webdriver.support import expected_conditions as EC
            alert_present = WebDriverWait(page.driver, 2).until(EC.alert_is_present())
        except Exception:
            alert_present = False

        assert is_modal or alert_present, (
            "BUG: Phải hiển thị dialog xác nhận trước khi Hủy. "
            "Thực tế không hiện dialog."
        )

        page.confirm_cancel_prompt()
        time.sleep(1)

        # After cancel confirmed, navigate back and verify data unchanged
        page.navigate_to_my_posts()
        page.click_first_edit_button()
        time.sleep(1)

        current_title = page.get_title_value()
        assert current_title == original_title, (
            f"BUG: Dữ liệu phải giữ nguyên sau khi Hủy. "
            f"Tiêu đề gốc: '{original_title}', Tiêu đề hiện tại: '{current_title}'"
        )
