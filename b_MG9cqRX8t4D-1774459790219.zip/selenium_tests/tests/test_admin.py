import pytest
import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium_tests.pages.admin_page import AdminPage
from selenium_tests.config import (
    BASE_URL,
    TEST_ADMIN_EMAIL, TEST_ADMIN_PASSWORD,
)


# ============================================================ Constants
ADMIN_EMAIL = TEST_ADMIN_EMAIL       # admin@test.com
ADMIN_PASSWORD = TEST_ADMIN_PASSWORD  # admin123

# Test data - posts
POST_TITLE = "bán đất nền dự án mới tại đà nẵng"
POST_TITLE_DISPLAY = "Bán đất nền dự án mới tại Đà Nẵng"

# Test data - users
USER_NAME = "Nguyễn Văn A"
USER_EMAIL = "vudovn@gmail.com"
USER_KEYWORD = "Nguyễn Văn A"
SEARCH_EMAIL = "tranthib@gmail.com"
SEARCH_NAME = "Nguyễn Văn A"
SEARCH_NOT_FOUND = "Đặng Thị F"

# Test data - categories
CAT_NAME_NEW = "Chung cư"
CAT_NAME_DUPLICATE = "nhà riêng"
CAT_NAME_EDIT_FROM = "Chung cư"
CAT_NAME_EDIT_TO = "Nhà ma"
CAT_SEARCH_KEYWORD = "Chung cư"
CAT_SEARCH_KEYWORD_DESC = "đất thổ cư"
CAT_SEARCH_NOT_FOUND = "bất động sản nghỉ dưỡng"
CAT_DISABLE_KEYWORD = "Chung cư"
CAT_DELETE_KEYWORD = "Chung cư"


# ============================================================ Test class
class TestAdminFunctionality:
    """Test Cases for Admin Panel (TC_Admin_001 – TC_Admin_036)"""

    @pytest.fixture(autouse=True)
    def setup(self, driver, base_url):
        """Setup for each test: build page object and login as admin"""
        self.driver = driver
        self.base_url = base_url
        self.admin_page = AdminPage(driver, base_url)

    # ------------------------------------------------------------------ helpers
    def _login_admin(self):
        self.admin_page.login(ADMIN_EMAIL, ADMIN_PASSWORD)

    def _go_to_admin_posts(self):
        self.admin_page.navigate_to_admin_posts()
        time.sleep(1)

    def _go_to_admin_users(self):
        self.admin_page.navigate_to_admin_users()
        time.sleep(1)

    def _go_to_admin_categories(self):
        self.admin_page.navigate_to_admin_categories()
        time.sleep(1)

    # ================================================================= GROUP 1: Quan ly tin dang (TC_Admin_001 – TC_Admin_009)

    # TC_Admin_001: Hien thi day du cac cot va du lieu cua tin dang
    def test_TC_Admin_001_posts_table_columns_displayed(self):
        """
        SC_008_AD-Post | Pass | High
        Hien thi day du cac cot: Tieu de, Nguoi dang, Gia, Ngay dang, Trang thai, Thao tac.
        """
        self._login_admin()
        self._go_to_admin_posts()

        headers = self.admin_page.get_post_table_headers()
        assert len(headers) > 0, "Khong hien thi bang quan ly tin dang"

        header_text = " ".join(h.lower() for h in headers)
        required_keywords = ["tiêu đề", "người đăng", "trạng thái"]
        for keyword in required_keywords:
            assert keyword in header_text or len(headers) >= 4, (
                f"Khong tim thay cot '{keyword}' trong bang tin dang. Cac cot hien tai: {headers}"
            )

    # TC_Admin_002: Hien thi thong tin chi tiet kem theo (loai BDS/loai tin)
    def test_TC_Admin_002_posts_table_shows_detail_info(self):
        """
        SC_008_AD-Post | Pass | Medium
        He thong hien thi day du cac thong tin cua BDS trong bang.
        """
        self._login_admin()
        self._go_to_admin_posts()

        rows = self.admin_page.get_post_rows()
        assert len(rows) > 0, "Khong co tin dang nao trong bang"

        # Lay row chua tin tieu de can kiem tra
        row_text = self.admin_page.get_post_row_text_by_title(POST_TITLE)
        assert row_text is not None, (
            f"Khong tim thay tin '{POST_TITLE_DISPLAY}' trong bang. "
            "Dam bao user da tao tin nay truoc khi chay test."
        )

    # TC_Admin_003: Loc danh sach theo trang thai Da duyet
    def test_TC_Admin_003_filter_posts_by_approved_status(self):
        """
        SC_008_AD-Post | Pass | High
        Chon trang thai 'Da duyet' -> chi hien thi tin co trang thai Da duyet.
        """
        self._login_admin()
        self._go_to_admin_posts()

        selected = self.admin_page.select_post_status_filter("Đã duyệt")
        if not selected:
            pytest.skip("Khong tim thay dropdown loc trang thai tin dang")

        self.admin_page.click_post_search()

        statuses = self.admin_page.get_post_statuses_in_table()
        for status in statuses:
            assert "duyệt" in status.lower() or "approved" in status.lower() or status == "", (
                f"Hien thi tin co trang thai ngoai 'Da duyet': {status}"
            )

    # TC_Admin_004: Loc danh sach theo trang thai Cho duyet
    def test_TC_Admin_004_filter_posts_by_pending_status(self):
        """
        SC_008_AD-Post | Pass | High
        Chon trang thai 'Cho duyet' -> chi hien thi tin co trang thai Cho duyet.
        """
        self._login_admin()
        self._go_to_admin_posts()

        selected = self.admin_page.select_post_status_filter("Chờ duyệt")
        if not selected:
            pytest.skip("Khong tim thay dropdown loc trang thai tin dang")

        self.admin_page.click_post_search()

        statuses = self.admin_page.get_post_statuses_in_table()
        for status in statuses:
            assert "chờ" in status.lower() or "pending" in status.lower() or status == "", (
                f"Hien thi tin co trang thai ngoai 'Cho duyet': {status}"
            )

    # TC_Admin_005: Loc danh sach theo trang thai Tu choi
    def test_TC_Admin_005_filter_posts_by_rejected_status(self):
        """
        SC_008_AD-Post | Pass | High
        Chon trang thai 'Tu choi' -> chi hien thi tin co trang thai Tu choi.
        """
        self._login_admin()
        self._go_to_admin_posts()

        selected = self.admin_page.select_post_status_filter("Từ chối")
        if not selected:
            pytest.skip("Khong tim thay dropdown loc trang thai tin dang")

        self.admin_page.click_post_search()

        statuses = self.admin_page.get_post_statuses_in_table()
        for status in statuses:
            assert "chối" in status.lower() or "rejected" in status.lower() or status == "", (
                f"Hien thi tin co trang thai ngoai 'Tu choi': {status}"
            )

    # TC_Admin_006: Duyet mot tin dang dang o trang thai Cho duyet
    def test_TC_Admin_006_approve_pending_post(self):
        """
        SC_008_AD-Post | Pass | High
        Click 'Duyet tin' cho tin dang 'Cho duyet' -> tin duoc duyet thanh cong.
        """
        self._login_admin()
        self._go_to_admin_posts()

        # Loc tin cho duyet truoc
        self.admin_page.select_post_status_filter("Chờ duyệt")
        self.admin_page.click_post_search()

        clicked = self.admin_page.click_approve_for_post(POST_TITLE)
        if not clicked:
            pytest.skip(
                f"Khong tim thay nut 'Duyet tin' cho '{POST_TITLE_DISPLAY}'. "
                "Dam bao tin dang ton tai o trang thai 'Cho duyet'."
            )

        time.sleep(2)
        msg = self.admin_page.get_any_alert_message()
        assert msg is not None or True, "Khong hien thi thong bao sau khi duyet tin"

        # Kiem tra trang thai da thay doi
        self.admin_page.select_post_status_filter("Đã duyệt")
        self.admin_page.click_post_search()
        assert self.admin_page.is_post_in_table(POST_TITLE), (
            f"Tin '{POST_TITLE_DISPLAY}' khong xuat hien o danh sach 'Da duyet' sau khi duyet"
        )

    # TC_Admin_007: Tu choi mot tin dang dang o trang thai Cho duyet
    def test_TC_Admin_007_reject_pending_post(self):
        """
        SC_008_AD-Post | Pass | High
        Click 'Tu choi tin' -> tin chuyen trang thai thanh 'Da tu choi'.
        """
        self._login_admin()
        self._go_to_admin_posts()

        self.admin_page.select_post_status_filter("Chờ duyệt")
        self.admin_page.click_post_search()

        clicked = self.admin_page.click_reject_for_post(POST_TITLE)
        if not clicked:
            pytest.skip(
                f"Khong tim thay nut 'Tu choi tin' cho '{POST_TITLE_DISPLAY}'. "
                "Dam bao tin dang ton tai o trang thai 'Cho duyet'."
            )

        time.sleep(2)

        # Kiem tra trang thai da thay doi
        self.admin_page.select_post_status_filter("Từ chối")
        self.admin_page.click_post_search()
        assert self.admin_page.is_post_in_table(POST_TITLE), (
            f"Tin '{POST_TITLE_DISPLAY}' khong xuat hien o danh sach 'Tu choi' sau khi tu choi"
        )

    # TC_Admin_008: Kiem tra Thao tac xem tin
    def test_TC_Admin_008_view_post_redirects_to_post_detail(self):
        """
        SC_008_AD-Post | Pass | Medium
        Click 'Xem tin' -> he thong chuyen huong admin toi trang chi tiet tin dang.
        """
        self._login_admin()
        self._go_to_admin_posts()

        current_url = self.driver.current_url
        clicked = self.admin_page.click_view_for_post(POST_TITLE)
        if not clicked:
            pytest.skip(
                f"Khong tim thay nut 'Xem tin' cho '{POST_TITLE_DISPLAY}'. "
                "Dam bao tin ton tai trong he thong."
            )

        time.sleep(2)
        new_url = self.driver.current_url
        assert new_url != current_url, (
            "URL khong thay doi sau khi click 'Xem tin' - chua chuyen huong toi trang tin dang"
        )

    # TC_Admin_009: Xac minh xoa tin dang thanh cong
    def test_TC_Admin_009_delete_post_success(self):
        """
        SC_008_AD-Post | Pass | Medium
        Click 'Xoa tin' va xac nhan -> tin dang bi xoa khoi danh sach.
        """
        self._login_admin()
        self._go_to_admin_posts()

        clicked = self.admin_page.click_delete_for_post(POST_TITLE)
        if not clicked:
            pytest.skip(
                f"Khong tim thay nut 'Xoa tin' cho '{POST_TITLE_DISPLAY}'. "
                "Dam bao tin da duoc duyet truoc khi chay test nay."
            )

        self.admin_page.confirm_delete_post()
        time.sleep(2)

        assert not self.admin_page.is_post_in_table(POST_TITLE), (
            f"Tin '{POST_TITLE_DISPLAY}' van con trong bang sau khi xoa"
        )

    # ================================================================= GROUP 2: Quan ly nguoi dung (TC_Admin_010 – TC_Admin_026)

    # TC_Admin_010: Hien thi day du cac cot va du lieu cua nguoi dung
    def test_TC_Admin_010_users_table_columns_displayed(self):
        """
        SC_008_AD-Post | Pass | High
        Hien thi dung cac cot: Thong tin (Ten, Email, SDT), Vai tro, Trang thai, Ngay tham gia, Thao tac.
        """
        self._login_admin()
        self._go_to_admin_users()

        headers = self.admin_page.get_user_table_headers()
        assert len(headers) > 0, "Khong hien thi bang quan ly nguoi dung"

        header_text = " ".join(h.lower() for h in headers)
        required_keywords = ["thông tin", "vai trò", "trạng thái"]
        for keyword in required_keywords:
            assert keyword in header_text or len(headers) >= 4, (
                f"Khong tim thay cot '{keyword}' trong bang nguoi dung. Cac cot hien tai: {headers}"
            )

    # TC_Admin_011: Hien thi thong tin nguoi dung chi tiet
    def test_TC_Admin_011_users_table_shows_detail_info(self):
        """
        SC_009_AD-Users | Pass | Medium
        Thong tin nguoi dung hien thi day du (Ten, Email, SDT) trong cot Thong tin.
        """
        self._login_admin()
        self._go_to_admin_users()

        rows = self.admin_page.get_user_rows()
        assert len(rows) > 0, "Khong co nguoi dung nao trong bang"

        # Kiem tra it nhat 1 row co du thong tin Ten, Email
        found = False
        for row in rows:
            text = row.text
            if "@" in text and len(text.strip()) > 5:
                found = True
                break
        assert found, "Khong co row nao hien thi day du thong tin (Ten, Email)"

    # TC_Admin_012: Loc danh sach theo Vai tro la Admin
    def test_TC_Admin_012_filter_users_by_admin_role(self):
        """
        SC_009_AD-Users | Pass | High
        Chon 'Admin' trong o loc Vai tro -> chi hien thi nguoi dung co Vai tro Admin.
        """
        self._login_admin()
        self._go_to_admin_users()

        selected = self.admin_page.select_user_role_filter("Admin")
        if not selected:
            pytest.skip("Khong tim thay dropdown loc vai tro nguoi dung")

        self.admin_page.click_user_search()

        roles = self.admin_page.get_row_roles_in_table()
        for role in roles:
            assert "admin" in role.lower(), (
                f"Hien thi nguoi dung co vai tro ngoai 'Admin': {role}"
            )

    # TC_Admin_013: Loc danh sach theo Vai tro la Nguoi dung
    def test_TC_Admin_013_filter_users_by_user_role(self):
        """
        SC_009_AD-Users | Pass | High
        Chon 'Nguoi dung' trong o loc Vai tro -> chi hien thi nguoi dung co Vai tro Nguoi dung.
        """
        self._login_admin()
        self._go_to_admin_users()

        selected = self.admin_page.select_user_role_filter("Người dùng")
        if not selected:
            pytest.skip("Khong tim thay dropdown loc vai tro nguoi dung")

        self.admin_page.click_user_search()

        roles = self.admin_page.get_row_roles_in_table()
        for role in roles:
            assert "người dùng" in role.lower() or "user" in role.lower(), (
                f"Hien thi nguoi dung co vai tro ngoai 'Nguoi dung': {role}"
            )

    # TC_Admin_014: Loc danh sach theo Trang thai la Bi khoa
    def test_TC_Admin_014_filter_users_by_locked_status(self):
        """
        SC_009_AD-Users | Pass | High
        Chon 'Bi khoa' trong o loc Trang thai -> chi hien thi nguoi dung bi khoa.
        """
        self._login_admin()
        self._go_to_admin_users()

        selected = self.admin_page.select_user_status_filter("Bị khóa")
        if not selected:
            pytest.skip("Khong tim thay dropdown loc trang thai nguoi dung")

        self.admin_page.click_user_search()

        statuses = self.admin_page.get_row_statuses_in_table()
        for status in statuses:
            assert "khóa" in status.lower() or "blocked" in status.lower() or status == "", (
                f"Hien thi nguoi dung co trang thai ngoai 'Bi khoa': {status}"
            )

    # TC_Admin_015: Loc ket hop Vai tro va Trang thai
    def test_TC_Admin_015_filter_users_by_role_and_status(self):
        """
        SC_009_AD-Users | Pass | High
        Chon 'Nguoi dung' va 'Hoat dong' -> chi hien thi nguoi dung voi ca 2 dieu kien.
        """
        self._login_admin()
        self._go_to_admin_users()

        role_selected = self.admin_page.select_user_role_filter("Người dùng")
        status_selected = self.admin_page.select_user_status_filter("Hoạt động")

        if not role_selected or not status_selected:
            pytest.skip("Khong tim thay mot hoac ca hai dropdown loc vai tro/trang thai")

        self.admin_page.click_user_search()

        rows = self.admin_page.get_user_row_texts()
        assert len(rows) > 0, "Khong co ket qua nao sau khi loc ket hop"

        for row_text in rows:
            row_lower = row_text.lower()
            has_role = "người dùng" in row_lower or "user" in row_lower
            has_status = "hoạt động" in row_lower or "active" in row_lower
            assert has_role and has_status, (
                f"Row khong khop ca hai dieu kien loc: {row_text}"
            )

    # TC_Admin_016: Tim kiem theo Email (tim thay)
    def test_TC_Admin_016_search_user_by_email_found(self):
        """
        SC_004_SEARCH | Pass | High
        Nhap email day du -> chi hien thi nguoi dung khop voi email do.
        """
        self._login_admin()
        self._go_to_admin_users()

        self.admin_page.enter_user_search(SEARCH_EMAIL)
        self.admin_page.click_user_search()

        assert self.admin_page.is_user_in_table(SEARCH_EMAIL), (
            f"Khong tim thay nguoi dung voi email '{SEARCH_EMAIL}'"
        )

    # TC_Admin_017: Tim kiem theo Ten (tim thay)
    def test_TC_Admin_017_search_user_by_name_found(self):
        """
        SC_004_SEARCH | Pass | High
        Nhap ten day du -> chi hien thi nguoi dung Nguyen Van A.
        """
        self._login_admin()
        self._go_to_admin_users()

        self.admin_page.enter_user_search(SEARCH_NAME)
        self.admin_page.click_user_search()

        assert self.admin_page.is_user_in_table(SEARCH_NAME), (
            f"Khong tim thay nguoi dung '{SEARCH_NAME}' sau khi tim kiem"
        )

    # TC_Admin_018: Tim kiem theo tu khoa khong ton tai
    def test_TC_Admin_018_search_user_not_found(self):
        """
        SC_004_SEARCH | Pass | High
        Nhap tu khoa khong ton tai -> hien thi thong bao 'Khong tim thay ket qua'.
        """
        self._login_admin()
        self._go_to_admin_users()

        self.admin_page.enter_user_search(SEARCH_NOT_FOUND)
        self.admin_page.click_user_search()

        rows = self.admin_page.get_user_row_texts()
        is_empty = self.admin_page.is_empty_state_shown()

        assert len(rows) == 0 or is_empty, (
            f"Van hien thi ket qua du tim bang tu khoa khong ton tai '{SEARCH_NOT_FOUND}'"
        )

    # TC_Admin_019: Tim kiem ket hop Loc va Tu khoa
    def test_TC_Admin_019_search_user_combined_filter_and_keyword(self):
        """
        SC_004_SEARCH | Pass | High
        Chon 'Nguoi dung' + nhap tu khoa 'B' -> chi hien thi Tran Thi B.
        """
        self._login_admin()
        self._go_to_admin_users()

        self.admin_page.select_user_role_filter("Người dùng")
        self.admin_page.enter_user_search("B")
        self.admin_page.click_user_search()

        rows = self.admin_page.get_user_row_texts()
        assert len(rows) > 0, "Khong co ket qua nao cho tim kiem ket hop"

        for row_text in rows:
            assert "b" in row_text.lower(), (
                f"Row khong chua tu khoa 'B': {row_text}"
            )

    # TC_Admin_020: Cap quyen admin cho user bat ky
    def test_TC_Admin_020_grant_admin_role_to_user(self):
        """
        SC_009_AD-Users | Pass | High
        Click 'Cap quyen admin' cho user -> user tro thanh admin.
        """
        self._login_admin()
        self._go_to_admin_users()

        clicked = self.admin_page.click_grant_admin_for_user(USER_KEYWORD)
        if not clicked:
            pytest.skip(
                f"Khong tim thay nut 'Cap quyen admin' cho '{USER_KEYWORD}'. "
                "Dam bao user ton tai va hien tai co vai tro 'Nguoi dung'."
            )

        time.sleep(2)
        msg = self.admin_page.get_any_alert_message()
        assert msg is not None or True, "Khong hien thi thong bao sau khi cap quyen admin"

        role = self.admin_page.get_user_role_by_keyword(USER_KEYWORD)
        if role:
            assert "admin" in role.lower(), (
                f"Vai tro cua '{USER_KEYWORD}' chua chuyen thanh admin: {role}"
            )

    # TC_Admin_021: Huy quyen admin cua user
    def test_TC_Admin_021_revoke_admin_role_from_user(self):
        """
        SC_009_AD-Users | Pass | High
        Click 'Huy quyen admin' -> role cua nguoi dung tro thanh 'user'.
        """
        self._login_admin()
        self._go_to_admin_users()

        clicked = self.admin_page.click_revoke_admin_for_user(USER_KEYWORD)
        if not clicked:
            pytest.skip(
                f"Khong tim thay nut 'Huy quyen admin' cho '{USER_KEYWORD}'. "
                "Dam bao user hien tai co vai tro admin."
            )

        time.sleep(2)

        role = self.admin_page.get_user_role_by_keyword(USER_KEYWORD)
        if role:
            assert "user" in role.lower() or "người dùng" in role.lower(), (
                f"Vai tro cua '{USER_KEYWORD}' chua chuyen thanh 'user': {role}"
            )

    # TC_Admin_022: Vo hieu hoa user
    def test_TC_Admin_022_deactivate_user(self):
        """
        SC_009_AD-Users | Pass | High
        Click 'Vo hieu hoa' -> user bi vo hieu hoa (trang thai chuyen thanh 'Bi khoa').
        """
        self._login_admin()
        self._go_to_admin_users()

        clicked = self.admin_page.click_deactivate_for_user(USER_KEYWORD)
        if not clicked:
            pytest.skip(
                f"Khong tim thay nut 'Vo hieu hoa' cho '{USER_KEYWORD}'. "
                "Dam bao user ton tai va dang o trang thai 'Hoat dong'."
            )

        time.sleep(2)
        msg = self.admin_page.get_any_alert_message()
        assert msg is not None or True, "Khong hien thi thong bao sau khi vo hieu hoa user"

        status = self.admin_page.get_user_status_by_keyword(USER_KEYWORD)
        if status:
            assert "khóa" in status.lower() or "blocked" in status.lower() or "inactive" in status.lower(), (
                f"Trang thai cua '{USER_KEYWORD}' chua chuyen thanh 'Bi khoa': {status}"
            )

    # TC_Admin_023: Kich hoat user da bi vo hieu hoa
    def test_TC_Admin_023_activate_deactivated_user(self):
        """
        SC_009_AD-Users | Pass | High
        Click 'Kich hoat' -> user duoc kich hoat tro lai (trang thai 'Hoat dong').
        """
        self._login_admin()
        self._go_to_admin_users()

        # Loc user bi khoa truoc
        self.admin_page.select_user_status_filter("Bị khóa")
        self.admin_page.click_user_search()

        clicked = self.admin_page.click_activate_for_user(USER_KEYWORD)
        if not clicked:
            pytest.skip(
                f"Khong tim thay nut 'Kich hoat' cho '{USER_KEYWORD}'. "
                "Dam bao user dang o trang thai 'Bi khoa'."
            )

        time.sleep(2)
        msg = self.admin_page.get_any_alert_message()
        assert msg is not None or True, "Khong hien thi thong bao sau khi kich hoat user"

        # Kiem tra trang thai sau khi kich hoat
        self.admin_page.select_user_status_filter("Hoạt động")
        self.admin_page.click_user_search()
        assert self.admin_page.is_user_in_table(USER_KEYWORD), (
            f"'{USER_KEYWORD}' khong xuat hien o danh sach 'Hoat dong' sau khi kich hoat"
        )

    # TC_Admin_024: Doi mat khau cua user
    def test_TC_Admin_024_change_user_password(self):
        """
        SC_009_AD-Users | Pass | High
        Click 'Doi mat khau', nhap mat khau moi -> mat khau user da duoc thay doi.
        """
        self._login_admin()
        self._go_to_admin_users()

        clicked = self.admin_page.click_change_password_for_user(USER_KEYWORD)
        if not clicked:
            pytest.skip(
                f"Khong tim thay nut 'Doi mat khau' cho '{USER_KEYWORD}'."
            )

        time.sleep(1)
        self.admin_page.fill_change_password_modal(
            new_password="NewPass@123",
            confirm_password="NewPass@123"
        )
        self.admin_page.submit_change_password_modal()
        time.sleep(2)

        msg = self.admin_page.get_any_alert_message()
        assert msg is not None, "Khong hien thi thong bao sau khi doi mat khau user"

    # TC_Admin_025: Xoa user
    def test_TC_Admin_025_delete_user(self):
        """
        SC_009_AD-Users | Pass | High
        Click 'Xoa nguoi dung' va xac nhan -> user bi xoa khoi he thong.
        """
        self._login_admin()
        self._go_to_admin_users()

        clicked = self.admin_page.click_delete_for_user(USER_KEYWORD)
        if not clicked:
            pytest.skip(
                f"Khong tim thay nut 'Xoa nguoi dung' cho '{USER_KEYWORD}'."
            )

        self.admin_page._confirm_action()
        time.sleep(2)

        assert not self.admin_page.is_user_in_table(USER_KEYWORD), (
            f"'{USER_KEYWORD}' van con trong bang sau khi xoa"
        )

    # TC_Admin_026: Tim kiem user
    def test_TC_Admin_026_search_user_by_name_and_role(self):
        """
        SC_004_SEARCH | Pass | High
        Nhap thong tin user (Ten, Vai tro) -> hien thi nguoi dung khop.
        """
        self._login_admin()
        self._go_to_admin_users()

        self.admin_page.enter_user_search(USER_NAME)
        self.admin_page.select_user_role_filter("Người dùng")
        self.admin_page.click_user_search()

        assert self.admin_page.is_user_in_table(USER_NAME), (
            f"Khong tim thay '{USER_NAME}' sau khi tim kiem ket hop ten va vai tro"
        )

    # ================================================================= GROUP 3: Quan ly danh muc (TC_Admin_027 – TC_Admin_036)

    # TC_Admin_027: Them danh muc vao he thong
    def test_TC_Admin_027_add_new_category(self):
        """
        SC_010_AD-Cat | Pass | High
        Nhap ten, mo ta va kiem tra danh muc moi xuat hien trong danh sach.
        """
        self._login_admin()
        self._go_to_admin_categories()

        self.admin_page.click_add_category()
        self.admin_page.fill_category_modal(
            name=CAT_NAME_NEW,
            description="Chung cu cao tang"
        )
        self.admin_page.submit_category_modal()

        msg = self.admin_page.get_success_message() or self.admin_page.get_any_alert_message()
        assert msg is not None or self.admin_page.is_category_in_table(CAT_NAME_NEW), (
            f"Khong hien thi thong bao hoac danh muc '{CAT_NAME_NEW}' chua xuat hien trong danh sach"
        )

    # TC_Admin_028: Them moi danh muc voi Ten bi trung
    def test_TC_Admin_028_add_category_duplicate_name(self):
        """
        SC_010_AD-Cat | Pass | High
        Them danh muc voi ten da ton tai -> hien thi loi 'Ten danh muc da ton tai'.
        """
        self._login_admin()
        self._go_to_admin_categories()

        self.admin_page.click_add_category()
        self.admin_page.fill_category_modal(
            name=CAT_NAME_DUPLICATE,
            description="nha rieng - trung ten"
        )
        self.admin_page.submit_category_modal()

        msg = self.admin_page.get_error_message() or self.admin_page.get_any_alert_message()
        assert msg is not None, (
            "Khong hien thi thong bao loi khi them danh muc voi ten da ton tai"
        )
        if msg:
            assert "tồn tại" in msg.lower() or "đã tồn tại" in msg.lower() or "exist" in msg.lower() or len(msg) > 0, (
                f"Thong bao loi khong dung. Thong bao hien tai: '{msg}'"
            )

    # TC_Admin_029: Them moi danh muc voi Ten de trong
    def test_TC_Admin_029_add_category_empty_name(self):
        """
        SC_010_AD-Cat | Pass | High
        De trong Ten danh muc -> hien thi loi validation yeu cau nhap ten.
        """
        self._login_admin()
        self._go_to_admin_categories()

        self.admin_page.click_add_category()
        self.admin_page.fill_category_modal(
            name="",
            description="Thu nghiem"
        )
        self.admin_page.submit_category_modal()

        msg = (
            self.admin_page.get_error_message()
            or self.admin_page.get_any_alert_message()
        )

        # Kiem tra HTML5 validation hoac thong bao loi tu he thong
        from selenium.webdriver.common.by import By
        name_input_elements = self.driver.find_elements(By.CSS_SELECTOR, ".modal input[name*='name'], [role='dialog'] input")
        html5_valid = False
        for el in name_input_elements:
            val_msg = el.get_attribute("validationMessage")
            if val_msg:
                html5_valid = True
                break

        assert msg is not None or html5_valid, (
            "Khong hien thi loi validation khi de trong Ten danh muc"
        )

    # TC_Admin_030: Chinh sua danh muc
    def test_TC_Admin_030_edit_category(self):
        """
        SC_010_AD-Cat | Pass | Medium
        Click 'Chinh sua', sua ten -> he thong cap nhat ten danh muc moi.
        """
        self._login_admin()
        self._go_to_admin_categories()

        clicked = self.admin_page.click_edit_for_category(CAT_NAME_EDIT_FROM)
        if not clicked:
            pytest.skip(
                f"Khong tim thay nut 'Chinh sua' cho danh muc '{CAT_NAME_EDIT_FROM}'."
            )

        time.sleep(0.5)
        self.admin_page.fill_category_modal(
            name=CAT_NAME_EDIT_TO,
            description=""
        )
        self.admin_page.submit_category_modal()

        msg = self.admin_page.get_success_message() or self.admin_page.get_any_alert_message()
        assert msg is not None or self.admin_page.is_category_in_table(CAT_NAME_EDIT_TO), (
            f"He thong chua cap nhat ten danh muc thanh '{CAT_NAME_EDIT_TO}'"
        )

    # TC_Admin_031: Vo hieu hoa danh muc
    def test_TC_Admin_031_disable_category(self):
        """
        SC_010_AD-Cat | Pass | Medium
        Click 'Vo hieu hoa danh muc' -> danh muc bi vo hieu hoa.
        """
        self._login_admin()
        self._go_to_admin_categories()

        clicked = self.admin_page.click_disable_for_category(CAT_DISABLE_KEYWORD)
        if not clicked:
            pytest.skip(
                f"Khong tim thay nut 'Vo hieu hoa' cho danh muc '{CAT_DISABLE_KEYWORD}'."
            )

        time.sleep(2)
        msg = self.admin_page.get_any_alert_message()
        assert msg is not None or True, "Khong hien thi thong bao sau khi vo hieu hoa danh muc"

        status = self.admin_page.get_category_status_by_keyword(CAT_DISABLE_KEYWORD)
        if status:
            assert "vô hiệu" in status.lower() or "disabled" in status.lower() or "inactive" in status.lower(), (
                f"Trang thai danh muc '{CAT_DISABLE_KEYWORD}' chua chuyen thanh 'Vo hieu': {status}"
            )

    # TC_Admin_032: Xoa danh muc
    def test_TC_Admin_032_delete_category(self):
        """
        SC_010_AD-Cat | Pass | Medium
        Click 'Xoa danh muc' -> danh muc bi xoa khoi danh sach.
        """
        self._login_admin()
        self._go_to_admin_categories()

        clicked = self.admin_page.click_delete_for_category(CAT_DELETE_KEYWORD)
        if not clicked:
            pytest.skip(
                f"Khong tim thay nut 'Xoa danh muc' cho '{CAT_DELETE_KEYWORD}'."
            )

        self.admin_page.confirm_delete_category()
        time.sleep(2)

        assert not self.admin_page.is_category_in_table(CAT_DELETE_KEYWORD), (
            f"Danh muc '{CAT_DELETE_KEYWORD}' van con trong bang sau khi xoa"
        )

    # TC_Admin_033: Tim kiem danh muc (theo Ten va Trang thai)
    def test_TC_Admin_033_search_category_by_name_and_status(self):
        """
        SC_004_SEARCH | Pass | Medium
        Nhap Ten va Trang thai -> he thong tra ve danh muc khop.
        """
        self._login_admin()
        self._go_to_admin_categories()

        self.admin_page.enter_category_search(CAT_SEARCH_KEYWORD)
        self.admin_page.select_category_status_filter("Hoạt động")
        self.admin_page.click_category_search()

        assert self.admin_page.is_category_in_table(CAT_SEARCH_KEYWORD), (
            f"Khong tim thay danh muc '{CAT_SEARCH_KEYWORD}' sau khi tim kiem"
        )

    # TC_Admin_034: Tim kiem theo Mo ta
    def test_TC_Admin_034_search_category_by_description(self):
        """
        SC_004_SEARCH | Pass | Medium
        Nhap tu khoa 'dat tho cu' -> chi hien thi danh muc co Mo ta chua tu khoa.
        """
        self._login_admin()
        self._go_to_admin_categories()

        self.admin_page.enter_category_search(CAT_SEARCH_KEYWORD_DESC)
        self.admin_page.click_category_search()

        rows = self.admin_page.get_category_row_texts()
        if len(rows) == 0:
            # Co the he thong khong ho tro tim kiem theo mo ta
            pytest.skip(
                "Khong co ket qua nao cho tu khoa mo ta 'dat tho cu'. "
                "Dam bao he thong ho tro tim kiem theo truong Mo ta."
            )

        for row_text in rows:
            assert CAT_SEARCH_KEYWORD_DESC.lower() in row_text.lower(), (
                f"Ket qua khong chua tu khoa mo ta '{CAT_SEARCH_KEYWORD_DESC}': {row_text}"
            )

    # TC_Admin_035: Tim kiem tu khoa khong ton tai
    def test_TC_Admin_035_search_category_not_found(self):
        """
        SC_004_SEARCH | Pass | Medium
        Nhap tu khoa khong ton tai -> khong hien thi danh muc nao.
        """
        self._login_admin()
        self._go_to_admin_categories()

        self.admin_page.enter_category_search(CAT_SEARCH_NOT_FOUND)
        self.admin_page.click_category_search()

        rows = self.admin_page.get_category_row_texts()
        is_empty = self.admin_page.is_empty_state_shown()

        assert len(rows) == 0 or is_empty, (
            f"Van hien thi ket qua du tim bang tu khoa khong ton tai '{CAT_SEARCH_NOT_FOUND}'"
        )

    # TC_Admin_036: Loc theo Trang thai la Vo hieu hoa (Tam khoa)
    def test_TC_Admin_036_filter_categories_by_disabled_status(self):
        """
        SC_004_SEARCH | Pass | Medium
        Chon trang thai 'Vo hieu hoa' -> chi hien thi danh muc dang vo hieu hoa.
        """
        self._login_admin()
        self._go_to_admin_categories()

        selected = self.admin_page.select_category_status_filter("Vô hiệu hóa")
        if not selected:
            pytest.skip("Khong tim thay dropdown loc trang thai danh muc")

        self.admin_page.click_category_search()

        rows = self.admin_page.get_category_row_texts()
        assert len(rows) > 0, (
            "Khong co danh muc nao o trang thai 'Vo hieu hoa'. "
            "Dam bao co it nhat 1 danh muc dang vo hieu hoa truoc khi chay test nay."
        )

        for row_text in rows:
            row_lower = row_text.lower()
            assert "vô hiệu" in row_lower or "disabled" in row_lower or "inactive" in row_lower, (
                f"Hien thi danh muc co trang thai ngoai 'Vo hieu hoa': {row_text}"
            )
