"""
Test cases: Đăng nhập (TC_LOG_001 – TC_LOG_030)
Scenario IDs: SC_LOG_01 – SC_LOG_17
"""
import pytest
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from selenium_tests.pages.login_page import LoginPage
from selenium_tests.config import (
    BASE_URL,
    TEST_USER_EMAIL, TEST_USER_PASSWORD,
    TEST_ADMIN_EMAIL, TEST_ADMIN_PASSWORD,
    TEST_INVALID_EMAIL,
    LOGIN_URL, ADMIN_URL, HOME_URL,
)


class TestLogin:
    """Đăng nhập – 30 test cases"""

    @pytest.fixture(autouse=True)
    def setup(self, driver, base_url):
        self.driver = driver
        self.base_url = base_url
        self.page = LoginPage(driver, base_url)
        self.page.navigate_to_login()
        time.sleep(1)

    # ------------------------------------------------------------------
    # TC_LOG_001  Đăng nhập thành công với tài khoản User
    def test_TC_LOG_001_successful_user_login(self):
        self.page.login(TEST_USER_EMAIL, TEST_USER_PASSWORD)
        WebDriverWait(self.driver, 10).until(EC.url_contains(HOME_URL))
        assert HOME_URL in self.driver.current_url
        assert self.page.get_flash_message() is not None

    # TC_LOG_002  Đăng nhập thành công với tài khoản Admin
    def test_TC_LOG_002_successful_admin_login(self):
        self.page.login(TEST_ADMIN_EMAIL, TEST_ADMIN_PASSWORD)
        WebDriverWait(self.driver, 10).until(EC.url_contains(ADMIN_URL))
        assert ADMIN_URL in self.driver.current_url

    # TC_LOG_003  Đăng nhập với Email chứa chữ in hoa
    def test_TC_LOG_003_login_uppercase_email(self):
        self.page.login(TEST_USER_EMAIL.upper(), TEST_USER_PASSWORD)
        WebDriverWait(self.driver, 10).until(EC.url_contains(HOME_URL))
        assert HOME_URL in self.driver.current_url

    # TC_LOG_004  Đăng nhập với Email có khoảng trắng thừa
    def test_TC_LOG_004_login_whitespace_email(self):
        self.page.login(f"  {TEST_USER_EMAIL}  ", TEST_USER_PASSWORD)
        WebDriverWait(self.driver, 10).until(EC.url_contains(HOME_URL))
        assert HOME_URL in self.driver.current_url

    # TC_LOG_005  Ghi nhớ đăng nhập – checked (30 ngày)
    def test_TC_LOG_005_remember_me_checked(self):
        self.page.login(TEST_USER_EMAIL, TEST_USER_PASSWORD, remember=True)
        WebDriverWait(self.driver, 10).until(EC.url_contains(HOME_URL))
        cookies = self.driver.get_cookies()
        session = next((c for c in cookies if "connect" in c["name"] or "session" in c["name"]), None)
        assert session is not None

    # TC_LOG_006  Ghi nhớ đăng nhập – unchecked (24 giờ)
    def test_TC_LOG_006_remember_me_unchecked(self):
        self.page.login(TEST_USER_EMAIL, TEST_USER_PASSWORD, remember=False)
        WebDriverWait(self.driver, 10).until(EC.url_contains(HOME_URL))
        cookies = self.driver.get_cookies()
        session = next((c for c in cookies if "connect" in c["name"] or "session" in c["name"]), None)
        assert session is not None

    # TC_LOG_007  Bỏ trống tất cả – HTML5 chặn submit
    def test_TC_LOG_007_empty_form(self):
        self.page.click_login_button()
        time.sleep(1)
        assert LOGIN_URL in self.driver.current_url

    # TC_LOG_008  Chỉ nhập Email, bỏ trống Password
    def test_TC_LOG_008_only_email(self):
        self.page.enter_email(TEST_USER_EMAIL)
        self.page.click_login_button()
        time.sleep(1)
        assert LOGIN_URL in self.driver.current_url

    # TC_LOG_009  Chỉ nhập Password, bỏ trống Email
    def test_TC_LOG_009_only_password(self):
        self.page.enter_password(TEST_USER_PASSWORD)
        self.page.click_login_button()
        time.sleep(1)
        assert LOGIN_URL in self.driver.current_url

    # TC_LOG_010  Email thiếu @
    def test_TC_LOG_010_email_missing_at(self):
        self.page.enter_email("testtest.com")
        self.page.enter_password(TEST_USER_PASSWORD)
        self.page.click_login_button()
        time.sleep(1)
        assert LOGIN_URL in self.driver.current_url

    # TC_LOG_011  Email thiếu domain
    def test_TC_LOG_011_email_missing_domain(self):
        self.page.enter_email("test@")
        self.page.enter_password(TEST_USER_PASSWORD)
        self.page.click_login_button()
        time.sleep(1)
        assert LOGIN_URL in self.driver.current_url

    # TC_LOG_012  Tài khoản không tồn tại
    def test_TC_LOG_012_nonexistent_account(self):
        self.page.login(TEST_INVALID_EMAIL, TEST_USER_PASSWORD)
        err = self.page.get_error_message()
        assert err is not None
        assert "không đúng" in err.lower() or "sai" in err.lower()

    # TC_LOG_013  Sai mật khẩu
    def test_TC_LOG_013_wrong_password(self):
        self.page.login(TEST_USER_EMAIL, "wrongpassword123")
        err = self.page.get_error_message()
        assert err is not None
        assert "không đúng" in err.lower() or "sai" in err.lower()

    # TC_LOG_014  Tài khoản bị khóa (isActive: false)
    def test_TC_LOG_014_deactivated_account(self):
        self.page.login("deactivated@test.com", "password123")
        err = self.page.get_error_message()
        assert err is not None  # "Tài khoản đã bị khóa" hoặc credentials error

    # TC_LOG_015  Toggle hiện mật khẩu
    def test_TC_LOG_015_toggle_show_password(self):
        self.page.enter_password("testpass123")
        assert self.page.get_password_input_type() == "password"
        self.page.toggle_password_visibility()
        time.sleep(0.3)
        assert self.page.get_password_input_type() == "text"

    # TC_LOG_016  Toggle ẩn mật khẩu
    def test_TC_LOG_016_toggle_hide_password(self):
        self.page.enter_password("testpass123")
        self.page.toggle_password_visibility()
        time.sleep(0.3)
        assert self.page.get_password_input_type() == "text"
        self.page.toggle_password_visibility()
        time.sleep(0.3)
        assert self.page.get_password_input_type() == "password"

    # TC_LOG_017  Submit bằng phím Enter
    def test_TC_LOG_017_submit_with_enter(self):
        self.page.enter_email(TEST_USER_EMAIL)
        self.page.enter_password(TEST_USER_PASSWORD)
        self.page.submit_form_with_enter()
        WebDriverWait(self.driver, 10).until(EC.url_contains(HOME_URL))
        assert HOME_URL in self.driver.current_url

    # TC_LOG_018  Link "Quên mật khẩu?"
    def test_TC_LOG_018_forgot_password_link(self):
        self.page.click_forgot_password_link()
        time.sleep(1)
        assert "forgot-password" in self.driver.current_url

    # TC_LOG_019  Link "Đăng ký ngay"
    def test_TC_LOG_019_signup_link(self):
        self.page.click_signup_link()
        time.sleep(1)
        assert "register" in self.driver.current_url

    # TC_LOG_020  Responsive Mobile (iPhone 12, 390x844)
    def test_TC_LOG_020_mobile_layout(self):
        self.driver.set_window_size(390, 844)
        time.sleep(0.5)
        assert self.page.is_element_present(LoginPage.EMAIL_INPUT)
        assert self.page.is_element_present(LoginPage.PASSWORD_INPUT)
        assert self.page.is_element_present(LoginPage.LOGIN_BUTTON)

    # TC_LOG_021  Responsive Tablet (iPad, 768x1024) – khoảng cách hơi sát (Fail)
    @pytest.mark.xfail(reason="Bug: margin giữa Submit và Checkbox bị dính sát trên tablet Portrait")
    def test_TC_LOG_021_tablet_layout(self):
        self.driver.set_window_size(768, 1024)
        time.sleep(0.5)
        assert self.page.is_element_present(LoginPage.EMAIL_INPUT)
        # Bug: nút submit và checkbox "Ghi nhớ" bị quá gần nhau
        submit = self.driver.find_element(*LoginPage.LOGIN_BUTTON)
        remember = self.driver.find_element(*LoginPage.REMEMBER_CHECKBOX)
        gap = abs(submit.location["y"] - remember.location["y"] - remember.size["height"])
        assert gap >= 8, f"Gap quá nhỏ: {gap}px"

    # TC_LOG_022  Tab order
    def test_TC_LOG_022_tab_order(self):
        from selenium.webdriver.common.keys import Keys
        email_field = self.driver.find_element(*LoginPage.EMAIL_INPUT)
        email_field.send_keys("test@test.com")
        email_field.send_keys(Keys.TAB)
        focused = self.driver.switch_to.active_element
        assert focused.get_attribute("id") == "password"

    # TC_LOG_023  Page title
    def test_TC_LOG_023_page_title(self):
        title = self.driver.title.lower()
        assert "đăng nhập" in title or "login" in title

    # TC_LOG_024  Autocomplete
    def test_TC_LOG_024_autocomplete(self):
        email_field = self.driver.find_element(*LoginPage.EMAIL_INPUT)
        autocomplete = email_field.get_attribute("autocomplete")
        assert autocomplete in ["email", "username", "on", None, ""]

    # TC_LOG_025  SQL Injection
    def test_TC_LOG_025_sql_injection(self):
        self.page.login("' OR '1'='1", "password")
        err = self.page.get_error_message()
        assert err is not None

    # TC_LOG_026  XSS
    def test_TC_LOG_026_xss_protection(self):
        self.page.login("<script>alert(1)</script>", "pass")
        err = self.page.get_error_message()
        assert err is not None
        assert "<script>" not in self.driver.page_source

    # TC_LOG_027  Brute Force protection – Fail (chưa có rate-limit / captcha)
    @pytest.mark.xfail(reason="Bug: Hệ thống chưa có cơ chế khóa IP hoặc hiện Captcha sau nhiều lần sai")
    def test_TC_LOG_027_brute_force_protection(self):
        for _ in range(6):
            self.page.navigate_to_login()
            self.page.login(TEST_USER_EMAIL, "wrongpass123")
            time.sleep(0.3)
        # Kỳ vọng: rate-limit error hoặc captcha
        page_text = self.driver.page_source.lower()
        assert "captcha" in page_text or "tạm thời" in page_text or "thử lại" in page_text

    # TC_LOG_028  Truy cập /login khi đã đăng nhập (User)
    def test_TC_LOG_028_redirect_when_logged_in_user(self):
        self.page.login(TEST_USER_EMAIL, TEST_USER_PASSWORD)
        WebDriverWait(self.driver, 10).until(EC.url_contains(HOME_URL))
        self.page.navigate_to_login()
        time.sleep(1)
        assert LOGIN_URL not in self.driver.current_url or HOME_URL in self.driver.current_url

    # TC_LOG_029  Truy cập /login khi đã đăng nhập (Admin)
    def test_TC_LOG_029_redirect_when_logged_in_admin(self):
        self.page.login(TEST_ADMIN_EMAIL, TEST_ADMIN_PASSWORD)
        WebDriverWait(self.driver, 10).until(EC.url_contains(ADMIN_URL))
        self.page.navigate_to_login()
        time.sleep(1)
        assert ADMIN_URL in self.driver.current_url or HOME_URL in self.driver.current_url

    # TC_LOG_030  Đăng nhập bằng mật khẩu cũ sau khi đổi
    def test_TC_LOG_030_login_with_old_password_after_change(self):
        self.page.login(TEST_USER_EMAIL, "oldpassword_that_was_changed")
        err = self.page.get_error_message()
        assert err is not None
