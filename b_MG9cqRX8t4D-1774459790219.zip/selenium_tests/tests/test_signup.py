"""
Test cases: Đăng ký (TC_REG_001 – TC_REG_030)
Scenario IDs: SC_REG_01 – SC_REG_18
"""
import pytest
import time

from selenium_tests.pages.signup_page import SignupPage
from selenium_tests.config import BASE_URL


class TestSignup:
    """Đăng ký – 30 test cases"""

    @pytest.fixture(autouse=True)
    def setup(self, driver, base_url):
        self.driver = driver
        self.base_url = base_url
        self.page = SignupPage(driver, base_url)
        self.page.open()

    # TC_REG_001  Đăng ký thành công – đầy đủ thông tin
    def test_TC_REG_001_success_full_info(self):
        self.page.fill_form(
            name="Nguyễn Văn A", email="nva_001@test.com",
            phone="0901234567", password="Abc@123", confirm_pw="Abc@123", agree=True,
        )
        self.page.submit_form()
        msg = self.page.get_success_message()
        assert msg and "thành công" in msg.lower()

    # TC_REG_002  Đăng ký thành công – không nhập SĐT
    def test_TC_REG_002_success_no_phone(self):
        self.page.fill_form(
            name="Trần B", email="tranb_002@test.com",
            password="123456", confirm_pw="123456", agree=True,
        )
        self.page.submit_form()
        msg = self.page.get_success_message()
        assert msg and "thành công" in msg.lower()

    # TC_REG_003  Bỏ trống toàn bộ form
    def test_TC_REG_003_all_fields_empty(self):
        self.page.submit_form()
        assert self.page.is_name_field_focused() or \
               self.page.get_field_validation_message("name") != ""

    # TC_REG_004  Bỏ trống Họ và tên
    def test_TC_REG_004_empty_name(self):
        self.page.fill_form(email="test@test.com", password="123456", confirm_pw="123456", agree=True)
        self.page.submit_form()
        assert self.page.get_field_validation_message("name") != ""

    # TC_REG_005  Họ và tên < 2 ký tự
    def test_TC_REG_005_name_too_short(self):
        self.page.fill_form(name="A", email="test@test.com", password="123456", confirm_pw="123456", agree=True)
        self.page.submit_form()
        assert self.page.get_field_validation_message("name") != ""

    # TC_REG_006  Họ và tên > 50 ký tự – input bị chặn bởi maxlength
    def test_TC_REG_006_name_too_long(self):
        self.page.enter_name("A" * 51)
        assert len(self.page.get_field_value("name")) <= 50

    # TC_REG_007  Họ và tên chứa số
    def test_TC_REG_007_name_contains_numbers(self):
        self.page.fill_form(name="Văn A 123", email="test@test.com", password="123456", confirm_pw="123456", agree=True)
        self.page.submit_form()
        assert self.page.get_field_validation_message("name") != ""

    # TC_REG_008  Họ và tên chứa ký tự đặc biệt
    def test_TC_REG_008_name_contains_special_chars(self):
        self.page.fill_form(name="Nguyễn @Văn", email="test@test.com", password="123456", confirm_pw="123456", agree=True)
        self.page.submit_form()
        assert self.page.get_field_validation_message("name") != ""

    # TC_REG_009  Email đã tồn tại
    def test_TC_REG_009_email_already_exists(self):
        self.page.fill_form(name="New User", email="admin@test.com", password="123456", confirm_pw="123456", agree=True)
        self.page.submit_form()
        time.sleep(2)
        err = self.page.get_error_message()
        assert err and "đã" in err.lower()

    # TC_REG_010  Email sai định dạng (thiếu @)
    def test_TC_REG_010_email_invalid_no_at(self):
        self.page.fill_form(name="Test User", email="test.com", password="123456", confirm_pw="123456", agree=True)
        self.page.submit_form()
        assert self.page.get_field_validation_message("email") != ""

    # TC_REG_011  Email in hoa – DB lưu in thường (Fail: hiện tại DB lưu nguyên in hoa)
    @pytest.mark.xfail(reason="Bug: DB lưu email nguyên định dạng in hoa thay vì toLowerCase()")
    def test_TC_REG_011_email_uppercase_normalized(self):
        self.page.fill_form(name="Test User", email="TeSt_011@TeSt.CoM", password="123456", confirm_pw="123456", agree=True)
        self.page.submit_form()
        msg = self.page.get_success_message()
        assert msg and "thành công" in msg.lower()
        # Kỳ vọng DB lưu lowercase

    # TC_REG_012  Bỏ trống mật khẩu
    def test_TC_REG_012_empty_password(self):
        self.page.fill_form(name="Test User", email="test@test.com", phone="0901234567", agree=True)
        self.page.submit_form()
        assert self.page.get_field_validation_message("password") != ""

    # TC_REG_013  Mật khẩu < 6 ký tự
    def test_TC_REG_013_password_too_short(self):
        self.page.fill_form(name="Test User", email="test@test.com", password="12345", confirm_pw="12345", agree=True)
        self.page.submit_form()
        assert self.page.get_field_validation_message("password") != ""

    # TC_REG_014  Mật khẩu không khớp
    def test_TC_REG_014_password_mismatch(self):
        self.page.fill_form(name="Test User", email="test@test.com", password="123456", confirm_pw="abcdef", agree=True)
        self.page.submit_form()
        msg = self.page.get_password_match_message()
        assert msg and "không khớp" in msg.lower()

    # TC_REG_015  SĐT chứa chữ cái
    def test_TC_REG_015_phone_with_letters(self):
        self.page.fill_form(name="Test User", email="test@test.com", phone="0901abc456", password="123456", confirm_pw="123456", agree=True)
        self.page.submit_form()
        assert self.page.get_field_validation_message("phone") != ""

    # TC_REG_016  SĐT < 10 số
    def test_TC_REG_016_phone_too_short(self):
        self.page.fill_form(name="Test User", email="test@test.com", phone="090123456", password="123456", confirm_pw="123456", agree=True)
        self.page.submit_form()
        assert self.page.get_field_validation_message("phone") != ""

    # TC_REG_017  SĐT > 11 số
    def test_TC_REG_017_phone_too_long(self):
        self.page.fill_form(name="Test User", email="test@test.com", phone="090123456789", password="123456", confirm_pw="123456", agree=True)
        self.page.submit_form()
        assert self.page.get_field_validation_message("phone") != ""

    # TC_REG_018  Không tick điều khoản
    def test_TC_REG_018_terms_not_checked(self):
        self.page.fill_form(name="Test User", email="test@test.com", phone="0901234567", password="123456", confirm_pw="123456", agree=False)
        self.page.submit_form()
        assert self.page.get_field_validation_message("agree") != ""

    # TC_REG_019  Toggle hiện/ẩn mật khẩu
    def test_TC_REG_019_toggle_password_visibility(self):
        self.page.enter_password("Abc@123")
        assert self.page.get_password_field_type("password") == "password"
        self.page.toggle_password_visibility("password")
        assert self.page.get_password_field_type("password") == "text"
        self.page.toggle_password_visibility("password")
        assert self.page.get_password_field_type("password") == "password"

    # TC_REG_020  Toggle hiện/ẩn xác nhận mật khẩu
    def test_TC_REG_020_toggle_confirm_password_visibility(self):
        self.page.enter_confirm_password("Abc@123")
        assert self.page.get_password_field_type("confirm") == "password"
        self.page.toggle_password_visibility("confirm")
        assert self.page.get_password_field_type("confirm") == "text"
        self.page.toggle_password_visibility("confirm")
        assert self.page.get_password_field_type("confirm") == "password"

    # TC_REG_021  Trim khoảng trắng tự động
    def test_TC_REG_021_trim_whitespace(self):
        self.page.fill_form(name="  Nguyễn A  ", email="  trim021@test.com  ", phone="  0901234567  ", password="123456", confirm_pw="123456", agree=True)
        self.page.submit_form()
        msg = self.page.get_success_message()
        assert msg and "thành công" in msg.lower()

    # TC_REG_022  Link "Điều khoản sử dụng"
    def test_TC_REG_022_terms_link(self):
        self.page.click_terms_link()
        time.sleep(1)
        assert len(self.driver.window_handles) >= 1

    # TC_REG_023  Link "Chính sách bảo mật"
    def test_TC_REG_023_privacy_link(self):
        self.page.click_privacy_link()
        time.sleep(1)
        assert len(self.driver.window_handles) >= 1

    # TC_REG_024  Link chuyển sang Đăng nhập
    def test_TC_REG_024_redirect_to_login(self):
        self.page.scroll_to_bottom()
        self.page.click_login_link()
        time.sleep(1)
        assert "/login" in self.driver.current_url

    # TC_REG_025  Submit bằng phím Enter
    def test_TC_REG_025_submit_with_enter(self):
        self.page.fill_form(name="Enter025", email="enter025@test.com", phone="0901234567", password="123456", confirm_pw="123456", agree=True)
        self.page.submit_with_enter()
        msg = self.page.get_success_message()
        assert msg and "thành công" in msg.lower()

    # TC_REG_026  Mật khẩu được hash trong DB
    def test_TC_REG_026_password_hashed_in_db(self):
        self.page.fill_form(name="Hash026", email="hash026@test.com", password="TestPass123", confirm_pw="TestPass123", agree=True)
        self.page.submit_form()
        msg = self.page.get_success_message()
        assert msg and "thành công" in msg.lower()

    # TC_REG_027  Giá trị mặc định DB (role=user, isActive=true)
    def test_TC_REG_027_default_db_values(self):
        self.page.fill_form(name="Default027", email="default027@test.com", password="123456", confirm_pw="123456", agree=True)
        self.page.submit_form()
        msg = self.page.get_success_message()
        assert msg and "thành công" in msg.lower()

    # TC_REG_028  XSS qua trường Họ tên
    def test_TC_REG_028_xss_prevention(self):
        self.page.fill_form(name="<script>alert(1)</script>", email="xss028@test.com", password="123456", confirm_pw="123456", agree=True)
        self.page.submit_form()
        time.sleep(2)
        assert "<script>" not in self.driver.page_source

    # TC_REG_029  Responsive Mobile (375x812) – layout bị lệch 10px (Fail)
    @pytest.mark.xfail(reason="Bug: Form bị lệch trái ~10px trên mobile")
    def test_TC_REG_029_responsive_mobile(self):
        self.driver.set_window_size(375, 812)
        time.sleep(0.5)
        name_input = self.driver.find_element(*SignupPage.NAME_INPUT)
        assert name_input.is_displayed()
        assert name_input.location["x"] >= 0
        # Bug: lệch 10px sang trái trên thiết bị di động
        assert name_input.location["x"] > 5, "Form bị lệch trái"

    # TC_REG_030  Sync error – lỗi mật khẩu không khớp biến mất khi sửa đúng
    def test_TC_REG_030_sync_password_error(self):
        self.page.enter_password("123456")
        self.page.enter_confirm_password("abcdef")
        time.sleep(0.5)
        msg = self.page.get_password_match_message()
        assert msg and "không khớp" in msg.lower()

        self.page.enter_confirm_password("123456")
        time.sleep(0.5)
        msg2 = self.page.get_password_match_message()
        assert msg2 == "" or ("không" not in msg2.lower())
