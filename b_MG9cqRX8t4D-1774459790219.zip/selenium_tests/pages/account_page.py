from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from selenium.webdriver.common.action_chains import ActionChains
import time


class AccountPage:
    """Page Object Model for Account / Profile Page"""

    # ------------------------------------------------------------------ URLs
    PROFILE_URL = "/profile"
    FORGOT_PASSWORD_URL = "/forgot-password"
    REGISTER_URL = "/register"
    CREATE_POST_URL = "/posts/create"
    MY_POSTS_URL = "/my-posts"
    ADMIN_URL = "/admin"
    HOME_URL = "/"

    # ------------------------------------------------------------ Locators - Login
    LOGIN_EMAIL_INPUT = (By.ID, "email")
    LOGIN_PASSWORD_INPUT = (By.ID, "password")
    LOGIN_BUTTON = (By.CSS_SELECTOR, "button[type='submit']")

    # ------------------------------------------------- Locators - Profile card
    PROFILE_AVATAR = (By.CSS_SELECTOR, ".profile-avatar, .avatar, [class*='avatar']")
    PROFILE_NAME = (By.CSS_SELECTOR, ".profile-name, .user-name, [class*='profile'] h2, [class*='profile'] h3")
    PROFILE_EMAIL = (By.CSS_SELECTOR, ".profile-email, [class*='email']")
    PROFILE_ROLE_BADGE = (By.CSS_SELECTOR, ".badge, [class*='badge']")
    PROFILE_POSTS_COUNT = (By.CSS_SELECTOR, "[class*='posts-count'], [class*='post'] span")
    PROFILE_JOINED_DATE = (By.CSS_SELECTOR, "[class*='joined'], [class*='created']")

    # ----------------------------------------------- Locators - Update profile form
    NAME_INPUT = (By.ID, "name")
    PHONE_INPUT = (By.ID, "phone")
    DOB_INPUT = (By.ID, "dob")
    ADDRESS_INPUT = (By.ID, "address")
    EMAIL_FIELD_DISABLED = (By.ID, "email")
    ROLE_FIELD_DISABLED = (By.ID, "role")
    UPDATE_PROFILE_BUTTON = (By.CSS_SELECTOR, "button[type='submit'], button.btn-primary, [class*='update']")

    # ----------------------------------------------- Locators - Change password form
    CURRENT_PASSWORD_INPUT = (By.ID, "currentPassword")
    NEW_PASSWORD_INPUT = (By.ID, "newPassword")
    CONFIRM_PASSWORD_INPUT = (By.ID, "confirmPassword")
    CURRENT_PW_TOGGLE = (By.CSS_SELECTOR, "#currentPassword ~ button, .toggle-pw[data-target='currentPassword']")
    NEW_PW_TOGGLE = (By.CSS_SELECTOR, "#newPassword ~ button, .toggle-pw[data-target='newPassword']")
    CONFIRM_PW_TOGGLE = (By.CSS_SELECTOR, "#confirmPassword ~ button, .toggle-pw[data-target='confirmPassword']")
    CHANGE_PASSWORD_BUTTON = (By.CSS_SELECTOR, "button.btn-warning, button[class*='change-pw'], button[class*='password']")

    # ----------------------------------------------- Locators - OTP modal
    OTP_INPUT = (By.ID, "otp")
    OTP_CONFIRM_BUTTON = (By.CSS_SELECTOR, ".btn-confirm-otp, button[class*='otp'], #confirmOtpBtn")

    # ----------------------------------------------- Locators - 2FA section
    TWO_FA_TOGGLE = (By.CSS_SELECTOR, "#toggle2fa, input[type='checkbox'][id*='2fa'], [class*='toggle-2fa']")
    TWO_FA_SECTION = (By.CSS_SELECTOR, "[class*='2fa'], [id*='2fa']")

    # ----------------------------------------------- Locators - Devices / sessions
    DEVICE_LIST = (By.CSS_SELECTOR, "[class*='device-list'], [class*='session-list']")
    DEVICE_ITEMS = (By.CSS_SELECTOR, "[class*='device-item'], [class*='session-item']")
    REMOVE_SESSION_BUTTONS = (By.CSS_SELECTOR, "[class*='remove-session'], [class*='delete-session']")

    # ----------------------------------------------- Locators - Quick actions
    CREATE_POST_BTN = (By.CSS_SELECTOR, "a[href='/posts/create'], a[href*='create']")
    MY_POSTS_BTN = (By.CSS_SELECTOR, "a[href='/my-posts'], a[href*='my-posts']")
    ADMIN_BTN = (By.CSS_SELECTOR, "a[href='/admin'], a[href*='admin']")
    LOGOUT_BTN = (By.CSS_SELECTOR, "button[class*='logout'], a[class*='logout'], #logoutBtn")

    # ----------------------------------------------- Locators - Breadcrumb
    BREADCRUMB = (By.CSS_SELECTOR, ".breadcrumb, [class*='breadcrumb']")
    BREADCRUMB_HOME_LINK = (By.CSS_SELECTOR, ".breadcrumb a, [class*='breadcrumb'] a")

    # ----------------------------------------------- Locators - Alerts
    ALERT_SUCCESS = (By.CSS_SELECTOR, ".alert-success, [class*='alert-success'], [class*='success']")
    ALERT_ERROR = (By.CSS_SELECTOR, ".alert-danger, [class*='alert-danger'], [class*='error']")
    ALERT_ANY = (By.CSS_SELECTOR, ".alert, [class*='alert'], [role='alert']")
    SPINNER = (By.CSS_SELECTOR, ".spinner, .loading, [class*='spinner'], [class*='loading']")

    # ----------------------------------------------- Locators - Validation messages
    NAME_ERROR = (By.CSS_SELECTOR, "#nameError, [class*='name-error'], #name ~ .invalid-feedback")
    PHONE_ERROR = (By.CSS_SELECTOR, "#phoneError, [class*='phone-error'], #phone ~ .invalid-feedback")
    ADDRESS_ERROR = (By.CSS_SELECTOR, "#addressError, [class*='address-error'], #address ~ .invalid-feedback")
    CURRENT_PW_ERROR = (By.CSS_SELECTOR, "#currentPasswordError, #currentPassword ~ .invalid-feedback")
    NEW_PW_ERROR = (By.CSS_SELECTOR, "#newPasswordError, #newPassword ~ .invalid-feedback")
    CONFIRM_PW_ERROR = (By.CSS_SELECTOR, "#confirmPasswordError, #confirmPassword ~ .invalid-feedback")

    def __init__(self, driver, base_url):
        self.driver = driver
        self.base_url = base_url
        self.wait = WebDriverWait(driver, 10)

    # ================================================================= Navigation
    def navigate_to_profile(self):
        """Navigate to profile page"""
        self.driver.get(f"{self.base_url}{self.PROFILE_URL}")

    def navigate_to_login(self):
        """Navigate to login page"""
        self.driver.get(f"{self.base_url}/login")

    def navigate_to_register(self):
        """Navigate to register page"""
        self.driver.get(f"{self.base_url}{self.REGISTER_URL}")

    def navigate_to_forgot_password(self):
        """Navigate to forgot password page"""
        self.driver.get(f"{self.base_url}{self.FORGOT_PASSWORD_URL}")

    def get_current_url(self):
        return self.driver.current_url

    # ================================================================= Login helpers
    def login(self, email, password):
        """Perform login and wait for redirect"""
        self.navigate_to_login()
        self.wait.until(EC.presence_of_element_located(self.LOGIN_EMAIL_INPUT)).clear()
        self.driver.find_element(*self.LOGIN_EMAIL_INPUT).send_keys(email)
        self.driver.find_element(*self.LOGIN_PASSWORD_INPUT).clear()
        self.driver.find_element(*self.LOGIN_PASSWORD_INPUT).send_keys(password)
        self.driver.find_element(*self.LOGIN_BUTTON).click()
        time.sleep(2)

    # ================================================================= Profile card helpers
    def get_profile_name(self):
        """Get displayed profile name"""
        try:
            return self.wait.until(EC.presence_of_element_located(self.PROFILE_NAME)).text
        except TimeoutException:
            return None

    def get_profile_email(self):
        """Get displayed profile email"""
        try:
            return self.driver.find_element(*self.PROFILE_EMAIL).text
        except NoSuchElementException:
            return None

    def get_role_badge_text(self):
        """Get role badge text"""
        try:
            return self.driver.find_element(*self.PROFILE_ROLE_BADGE).text
        except NoSuchElementException:
            return None

    def get_joined_date_text(self):
        """Get joined date text"""
        try:
            return self.driver.find_element(*self.PROFILE_JOINED_DATE).text
        except NoSuchElementException:
            return None

    def is_avatar_displayed(self):
        """Check if avatar element is visible"""
        try:
            elem = self.driver.find_element(*self.PROFILE_AVATAR)
            return elem.is_displayed()
        except NoSuchElementException:
            return False

    # ================================================================= Update profile helpers
    def clear_and_enter_name(self, name):
        """Clear name field and enter new name"""
        field = self.wait.until(EC.presence_of_element_located(self.NAME_INPUT))
        field.clear()
        field.send_keys(name)

    def clear_and_enter_phone(self, phone):
        """Clear phone field and enter new phone"""
        field = self.wait.until(EC.presence_of_element_located(self.PHONE_INPUT))
        field.clear()
        field.send_keys(phone)

    def clear_and_enter_dob(self, dob):
        """Clear dob field and enter new date of birth"""
        field = self.wait.until(EC.presence_of_element_located(self.DOB_INPUT))
        field.clear()
        field.send_keys(dob)

    def clear_and_enter_address(self, address):
        """Clear address field and enter new address"""
        field = self.wait.until(EC.presence_of_element_located(self.ADDRESS_INPUT))
        field.clear()
        field.send_keys(address)

    def click_update_profile(self):
        """Click the update profile button"""
        btn = self.wait.until(EC.element_to_be_clickable(self.UPDATE_PROFILE_BUTTON))
        btn.click()

    def is_email_field_disabled(self):
        """Check if email field is disabled"""
        try:
            field = self.driver.find_element(*self.EMAIL_FIELD_DISABLED)
            return field.get_attribute("disabled") is not None or field.get_attribute("readonly") is not None
        except NoSuchElementException:
            return False

    def is_role_field_disabled(self):
        """Check if role field is disabled"""
        try:
            field = self.driver.find_element(*self.ROLE_FIELD_DISABLED)
            return field.get_attribute("disabled") is not None or field.get_attribute("readonly") is not None
        except NoSuchElementException:
            return False

    def get_name_field_value(self):
        """Get current value of name field"""
        try:
            return self.driver.find_element(*self.NAME_INPUT).get_attribute("value")
        except NoSuchElementException:
            return None

    def get_phone_field_value(self):
        """Get current value of phone field"""
        try:
            return self.driver.find_element(*self.PHONE_INPUT).get_attribute("value")
        except NoSuchElementException:
            return None

    # ================================================================= Change password helpers
    def enter_current_password(self, password):
        """Enter current password"""
        field = self.wait.until(EC.presence_of_element_located(self.CURRENT_PASSWORD_INPUT))
        field.clear()
        field.send_keys(password)

    def enter_new_password(self, password):
        """Enter new password"""
        field = self.wait.until(EC.presence_of_element_located(self.NEW_PASSWORD_INPUT))
        field.clear()
        field.send_keys(password)

    def enter_confirm_password(self, password):
        """Enter confirm new password"""
        field = self.wait.until(EC.presence_of_element_located(self.CONFIRM_PASSWORD_INPUT))
        field.clear()
        field.send_keys(password)

    def click_change_password(self):
        """Click the change password button"""
        btn = self.wait.until(EC.element_to_be_clickable(self.CHANGE_PASSWORD_BUTTON))
        btn.click()

    def get_field_input_type(self, locator):
        """Get the type attribute of an input field"""
        try:
            return self.driver.find_element(*locator).get_attribute("type")
        except NoSuchElementException:
            return None

    def click_toggle_by_css(self, css_selector):
        """Click a toggle button by CSS selector"""
        try:
            btn = self.driver.find_element(By.CSS_SELECTOR, css_selector)
            btn.click()
            return True
        except NoSuchElementException:
            return False

    def toggle_current_password_visibility(self):
        """Toggle visibility of current password field"""
        try:
            btn = self.driver.find_element(*self.CURRENT_PW_TOGGLE)
            btn.click()
            return True
        except NoSuchElementException:
            # Fallback: find any toggle button near current password
            toggles = self.driver.find_elements(By.CSS_SELECTOR, ".toggle-pw, button[class*='eye'], button[class*='toggle']")
            if toggles:
                toggles[0].click()
                return True
            return False

    def toggle_new_password_visibility(self):
        """Toggle visibility of new password field"""
        try:
            btn = self.driver.find_element(*self.NEW_PW_TOGGLE)
            btn.click()
            return True
        except NoSuchElementException:
            toggles = self.driver.find_elements(By.CSS_SELECTOR, ".toggle-pw, button[class*='eye'], button[class*='toggle']")
            if len(toggles) > 1:
                toggles[1].click()
                return True
            return False

    def toggle_confirm_password_visibility(self):
        """Toggle visibility of confirm password field"""
        try:
            btn = self.driver.find_element(*self.CONFIRM_PW_TOGGLE)
            btn.click()
            return True
        except NoSuchElementException:
            toggles = self.driver.find_elements(By.CSS_SELECTOR, ".toggle-pw, button[class*='eye'], button[class*='toggle']")
            if len(toggles) > 2:
                toggles[2].click()
                return True
            return False

    # ================================================================= OTP helpers
    def enter_otp(self, otp_code):
        """Enter OTP code"""
        try:
            field = self.wait.until(EC.visibility_of_element_located(self.OTP_INPUT))
            field.clear()
            field.send_keys(otp_code)
        except TimeoutException:
            pass

    def click_otp_confirm(self):
        """Click OTP confirm button"""
        try:
            btn = self.wait.until(EC.element_to_be_clickable(self.OTP_CONFIRM_BUTTON))
            btn.click()
        except TimeoutException:
            pass

    # ================================================================= 2FA helpers
    def click_2fa_toggle(self):
        """Click 2FA toggle switch"""
        try:
            toggle = self.wait.until(EC.element_to_be_clickable(self.TWO_FA_TOGGLE))
            toggle.click()
            return True
        except TimeoutException:
            return False

    def is_2fa_section_present(self):
        """Check if 2FA section is present on page"""
        try:
            return self.driver.find_element(*self.TWO_FA_SECTION).is_displayed()
        except NoSuchElementException:
            return False

    # ================================================================= Device / session helpers
    def is_device_list_present(self):
        """Check if device list section is present"""
        try:
            return self.driver.find_element(*self.DEVICE_LIST).is_displayed()
        except NoSuchElementException:
            return False

    def get_device_items(self):
        """Return list of device/session items"""
        try:
            return self.driver.find_elements(*self.DEVICE_ITEMS)
        except NoSuchElementException:
            return []

    def click_remove_session(self, index=0):
        """Click remove button for a session at given index"""
        try:
            buttons = self.driver.find_elements(*self.REMOVE_SESSION_BUTTONS)
            if buttons and index < len(buttons):
                buttons[index].click()
                return True
        except NoSuchElementException:
            pass
        return False

    def confirm_remove_session(self):
        """Handle confirmation dialog for session removal"""
        try:
            WebDriverWait(self.driver, 3).until(EC.alert_is_present())
            self.driver.switch_to.alert.accept()
        except TimeoutException:
            # Modal confirm button
            try:
                confirm_btn = self.driver.find_element(By.CSS_SELECTOR, ".modal .btn-danger, .confirm-btn, #confirmDelete")
                confirm_btn.click()
            except NoSuchElementException:
                pass

    # ================================================================= Quick actions helpers
    def click_create_post(self):
        """Click 'Dang tin moi' quick action button"""
        btn = self.wait.until(EC.element_to_be_clickable(self.CREATE_POST_BTN))
        btn.click()

    def click_my_posts(self):
        """Click 'Quan ly tin dang' quick action button"""
        btn = self.wait.until(EC.element_to_be_clickable(self.MY_POSTS_BTN))
        btn.click()

    def is_admin_button_visible(self):
        """Check if admin button is visible"""
        try:
            btn = self.driver.find_element(*self.ADMIN_BTN)
            return btn.is_displayed()
        except NoSuchElementException:
            return False

    def click_admin_button(self):
        """Click admin panel quick action button"""
        btn = self.wait.until(EC.element_to_be_clickable(self.ADMIN_BTN))
        btn.click()

    def click_logout(self):
        """Click logout button"""
        btn = self.wait.until(EC.element_to_be_clickable(self.LOGOUT_BTN))
        btn.click()
        # Handle confirmation dialog/modal if present
        try:
            WebDriverWait(self.driver, 3).until(EC.alert_is_present())
            self.driver.switch_to.alert.accept()
        except TimeoutException:
            try:
                confirm = self.driver.find_element(By.CSS_SELECTOR, ".modal .btn-danger, #confirmLogout")
                confirm.click()
            except NoSuchElementException:
                pass

    # ================================================================= Breadcrumb helpers
    def is_breadcrumb_present(self):
        """Check if breadcrumb is present"""
        try:
            return self.driver.find_element(*self.BREADCRUMB).is_displayed()
        except NoSuchElementException:
            return False

    def click_breadcrumb_home(self):
        """Click breadcrumb home link"""
        link = self.wait.until(EC.element_to_be_clickable(self.BREADCRUMB_HOME_LINK))
        link.click()

    # ================================================================= Alert helpers
    def get_success_message(self):
        """Get success alert text"""
        try:
            elem = self.wait.until(EC.visibility_of_element_located(self.ALERT_SUCCESS))
            return elem.text
        except TimeoutException:
            return None

    def get_error_message(self):
        """Get error alert text"""
        try:
            elem = self.wait.until(EC.visibility_of_element_located(self.ALERT_ERROR))
            return elem.text
        except TimeoutException:
            return None

    def get_any_alert_message(self):
        """Get text of any visible alert"""
        try:
            elem = self.wait.until(EC.visibility_of_element_located(self.ALERT_ANY))
            return elem.text
        except TimeoutException:
            return None

    def is_spinner_visible(self):
        """Check if spinner/loading indicator is visible"""
        try:
            return self.driver.find_element(*self.SPINNER).is_displayed()
        except NoSuchElementException:
            return False

    # ================================================================= Validation helpers
    def get_validation_message_for(self, field_locator):
        """Get HTML5 or custom validation message near a field"""
        try:
            field = self.driver.find_element(*field_locator)
            html5_msg = field.get_attribute("validationMessage")
            if html5_msg:
                return html5_msg
        except NoSuchElementException:
            pass
        return None

    def get_field_error_text(self, error_locator):
        """Get custom error message element text"""
        try:
            elem = self.driver.find_element(*error_locator)
            if elem.is_displayed():
                return elem.text
        except NoSuchElementException:
            pass
        return None

    # ================================================================= Utility
    def is_element_present(self, locator):
        """Check if element exists in DOM"""
        try:
            self.driver.find_element(*locator)
            return True
        except NoSuchElementException:
            return False

    def set_window_mobile(self):
        """Set window to mobile size"""
        self.driver.set_window_size(375, 812)

    def set_window_desktop(self):
        """Set window to desktop size"""
        self.driver.set_window_size(1920, 1080)

    def hover_element(self, locator):
        """Hover over an element"""
        elem = self.wait.until(EC.presence_of_element_located(locator))
        ActionChains(self.driver).move_to_element(elem).perform()

    def is_cookies_cleared(self):
        """Check if session cookies are removed after logout"""
        cookies = self.driver.get_cookies()
        session_cookies = [c for c in cookies if 'sid' in c['name'].lower() or 'session' in c['name'].lower()]
        return len(session_cookies) == 0
