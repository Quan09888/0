from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import time


class UpdatePostPage:
    """Page Object Model for Update/Edit Post Page"""

    # ------------------------------------------------------------------ URLs
    LOGIN_URL = "/login"
    MY_POSTS_URL = "/my-posts"
    EDIT_POST_URL_PATTERN = "/posts/{post_id}/edit"

    # -------------------------------------------------------- Locators - Login
    LOGIN_EMAIL_INPUT = (By.ID, "email")
    LOGIN_PASSWORD_INPUT = (By.ID, "password")
    LOGIN_BUTTON = (By.CSS_SELECTOR, "button[type='submit']")

    # ------------------------------------------------ Locators - My Posts list
    POST_ITEMS = (By.CSS_SELECTOR, "[class*='post-item'], [class*='post-card'], .post-list-item")
    EDIT_POST_BUTTONS = (By.CSS_SELECTOR, "a[href*='edit'], button[class*='edit'], [class*='btn-edit']")
    POST_STATUS_BADGES = (By.CSS_SELECTOR, "[class*='status'], [class*='badge'], .badge")

    # ------------------------------------------------ Locators - Edit form fields
    TITLE_INPUT = (By.ID, "title")
    DESCRIPTION_INPUT = (By.ID, "description")
    PRICE_INPUT = (By.ID, "price")
    AREA_INPUT = (By.ID, "area")
    ADDRESS_INPUT = (By.ID, "address")
    PHONE_INPUT = (By.ID, "phone")

    # Dropdowns
    LISTING_TYPE_SELECT = (By.ID, "listingType")
    PROPERTY_TYPE_SELECT = (By.ID, "propertyType")

    # Submit / Cancel buttons
    SUBMIT_BUTTON = (By.CSS_SELECTOR,
        "button[type='submit'], button[class*='update'], button[class*='cap-nhat'], button[class*='save']")
    CANCEL_BUTTON = (By.CSS_SELECTOR,
        "button[class*='cancel'], a[class*='cancel'], button[class*='huy'], a[href*='my-posts']")

    # ------------------------------------------------ Locators - Image section
    IMAGE_INPUT = (By.CSS_SELECTOR, "input[type='file'][accept*='image'], input[type='file']")
    IMAGE_PREVIEW_ITEMS = (By.CSS_SELECTOR,
        "[class*='image-preview'] img, [class*='preview-item'], [class*='img-thumb'], [class*='old-image']")
    DELETE_IMAGE_BUTTONS = (By.CSS_SELECTOR,
        "[class*='delete-img'], [class*='remove-img'], button[class*='img'] svg, [class*='img-close']")
    IMAGE_LIMIT_ERROR = (By.CSS_SELECTOR,
        "[class*='image-error'], [class*='img-error'], [id*='imageError']")

    # ------------------------------------------------ Locators - Validation / Alerts
    TITLE_ERROR = (By.CSS_SELECTOR, "#titleError, #title ~ .invalid-feedback, [class*='title-error']")
    PRICE_ERROR = (By.CSS_SELECTOR, "#priceError, #price ~ .invalid-feedback, [class*='price-error']")
    AREA_ERROR = (By.CSS_SELECTOR, "#areaError, #area ~ .invalid-feedback, [class*='area-error']")
    PHONE_ERROR = (By.CSS_SELECTOR, "#phoneError, #phone ~ .invalid-feedback, [class*='phone-error']")

    ALERT_SUCCESS = (By.CSS_SELECTOR,
        ".alert-success, [class*='alert-success'], [class*='toast-success'], [class*='success']")
    ALERT_ERROR = (By.CSS_SELECTOR,
        ".alert-danger, [class*='alert-danger'], [class*='toast-error'], [class*='error']")
    ALERT_ANY = (By.CSS_SELECTOR, ".alert, [role='alert'], [class*='toast'], [class*='alert']")

    CONFIRM_MODAL = (By.CSS_SELECTOR, ".modal, [class*='modal'], [role='dialog']")
    CONFIRM_CANCEL_BTN = (By.CSS_SELECTOR,
        ".modal .btn-danger, .modal .btn-warning, #confirmCancel, button[class*='confirm']")

    def __init__(self, driver, base_url):
        self.driver = driver
        self.base_url = base_url
        self.wait = WebDriverWait(driver, 10)

    # ================================================================= Navigation
    def navigate_to_login(self):
        self.driver.get(f"{self.base_url}{self.LOGIN_URL}")

    def navigate_to_my_posts(self):
        self.driver.get(f"{self.base_url}{self.MY_POSTS_URL}")

    def navigate_to_edit_post(self, post_id):
        url = self.EDIT_POST_URL_PATTERN.format(post_id=post_id)
        self.driver.get(f"{self.base_url}{url}")

    def get_current_url(self):
        return self.driver.current_url

    # ================================================================= Login helper
    def login(self, email, password):
        """Login and wait for redirect"""
        self.navigate_to_login()
        self.wait.until(EC.presence_of_element_located(self.LOGIN_EMAIL_INPUT)).clear()
        self.driver.find_element(*self.LOGIN_EMAIL_INPUT).send_keys(email)
        self.driver.find_element(*self.LOGIN_PASSWORD_INPUT).clear()
        self.driver.find_element(*self.LOGIN_PASSWORD_INPUT).send_keys(password)
        self.driver.find_element(*self.LOGIN_BUTTON).click()
        time.sleep(2)

    # ================================================================= My Posts helpers
    def click_first_edit_button(self):
        """Click the first edit button in the post list"""
        try:
            btn = self.wait.until(EC.element_to_be_clickable(self.EDIT_POST_BUTTONS))
            btn.click()
            time.sleep(1)
            return True
        except TimeoutException:
            return False

    def get_first_post_status(self):
        """Get status badge text of first post in my-posts list"""
        try:
            badges = self.wait.until(EC.presence_of_all_elements_located(self.POST_STATUS_BADGES))
            return badges[0].text if badges else None
        except TimeoutException:
            return None

    # ================================================================= Form field helpers
    def get_title_value(self):
        try:
            return self.driver.find_element(*self.TITLE_INPUT).get_attribute("value")
        except NoSuchElementException:
            return None

    def get_price_value(self):
        try:
            return self.driver.find_element(*self.PRICE_INPUT).get_attribute("value")
        except NoSuchElementException:
            return None

    def get_area_value(self):
        try:
            return self.driver.find_element(*self.AREA_INPUT).get_attribute("value")
        except NoSuchElementException:
            return None

    def get_phone_value(self):
        try:
            return self.driver.find_element(*self.PHONE_INPUT).get_attribute("value")
        except NoSuchElementException:
            return None

    def get_description_value(self):
        try:
            return self.driver.find_element(*self.DESCRIPTION_INPUT).get_attribute("value")
        except NoSuchElementException:
            return None

    def update_title(self, new_title):
        field = self.wait.until(EC.presence_of_element_located(self.TITLE_INPUT))
        field.clear()
        field.send_keys(new_title)

    def clear_title(self):
        try:
            field = self.wait.until(EC.presence_of_element_located(self.TITLE_INPUT))
            field.clear()
        except TimeoutException:
            pass

    def update_description(self, new_description):
        field = self.wait.until(EC.presence_of_element_located(self.DESCRIPTION_INPUT))
        field.clear()
        field.send_keys(new_description)

    def update_price(self, new_price):
        field = self.wait.until(EC.presence_of_element_located(self.PRICE_INPUT))
        field.clear()
        field.send_keys(str(new_price))

    def update_area(self, new_area):
        field = self.wait.until(EC.presence_of_element_located(self.AREA_INPUT))
        field.clear()
        field.send_keys(str(new_area))

    def update_phone(self, new_phone):
        field = self.wait.until(EC.presence_of_element_located(self.PHONE_INPUT))
        field.clear()
        field.send_keys(str(new_phone))

    def select_listing_type(self, value):
        """Select listing type by visible text (e.g. 'Bán', 'Cho thuê')"""
        try:
            select_elem = self.wait.until(EC.presence_of_element_located(self.LISTING_TYPE_SELECT))
            sel = Select(select_elem)
            try:
                sel.select_by_visible_text(value)
            except Exception:
                sel.select_by_value(value)
        except (TimeoutException, NoSuchElementException):
            try:
                dropdown = self.driver.find_element(By.CSS_SELECTOR, "[class*='listing-type'], [id*='listingType']")
                dropdown.click()
                time.sleep(0.5)
                option = self.driver.find_element(By.XPATH, f"//*[contains(text(), '{value}')]")
                option.click()
            except NoSuchElementException:
                pass

    def get_property_type_options(self):
        """Return list of all available property type dropdown options"""
        try:
            select_elem = self.wait.until(EC.presence_of_element_located(self.PROPERTY_TYPE_SELECT))
            sel = Select(select_elem)
            return [opt.text for opt in sel.options]
        except (TimeoutException, NoSuchElementException):
            return []

    def get_selected_listing_type(self):
        """Return currently selected listing type text"""
        try:
            select_elem = self.driver.find_element(*self.LISTING_TYPE_SELECT)
            sel = Select(select_elem)
            return sel.first_selected_option.text
        except NoSuchElementException:
            return None

    # ================================================================= Image helpers
    def get_image_count(self):
        """Return count of currently displayed image previews"""
        try:
            items = self.driver.find_elements(*self.IMAGE_PREVIEW_ITEMS)
            return len(items)
        except NoSuchElementException:
            return 0

    def delete_images(self, count=1):
        """Click delete button on first N images"""
        try:
            delete_btns = self.driver.find_elements(*self.DELETE_IMAGE_BUTTONS)
            for i in range(min(count, len(delete_btns))):
                delete_btns[i].click()
                time.sleep(0.3)
        except NoSuchElementException:
            pass

    def upload_new_images(self, file_paths):
        """Upload additional images. file_paths is a list of absolute file paths."""
        try:
            file_input = self.wait.until(EC.presence_of_element_located(self.IMAGE_INPUT))
            file_input.send_keys("\n".join(file_paths))
            time.sleep(1)
        except TimeoutException:
            pass

    def get_image_limit_error(self):
        """Get image limit exceeded error text"""
        try:
            elem = self.wait.until(EC.visibility_of_element_located(self.IMAGE_LIMIT_ERROR))
            return elem.text
        except TimeoutException:
            return None

    # ================================================================= Submit / Cancel helpers
    def click_submit(self):
        btn = self.wait.until(EC.element_to_be_clickable(self.SUBMIT_BUTTON))
        btn.click()

    def click_cancel(self):
        try:
            btn = self.wait.until(EC.element_to_be_clickable(self.CANCEL_BUTTON))
            btn.click()
        except TimeoutException:
            self.driver.back()

    def confirm_cancel_prompt(self):
        """Handle any confirmation dialog/modal after clicking Cancel"""
        try:
            WebDriverWait(self.driver, 3).until(EC.alert_is_present())
            self.driver.switch_to.alert.accept()
        except TimeoutException:
            try:
                confirm = self.wait.until(EC.element_to_be_clickable(self.CONFIRM_CANCEL_BTN))
                confirm.click()
            except TimeoutException:
                pass

    def is_confirm_modal_visible(self):
        """Check if a confirmation modal is displayed"""
        try:
            modal = WebDriverWait(self.driver, 3).until(
                EC.visibility_of_element_located(self.CONFIRM_MODAL)
            )
            return modal.is_displayed()
        except TimeoutException:
            return False

    # ================================================================= Alert / Validation helpers
    def get_success_message(self):
        try:
            elem = self.wait.until(EC.visibility_of_element_located(self.ALERT_SUCCESS))
            return elem.text
        except TimeoutException:
            return None

    def get_error_message(self):
        try:
            elem = self.wait.until(EC.visibility_of_element_located(self.ALERT_ERROR))
            return elem.text
        except TimeoutException:
            return None

    def get_any_alert_message(self):
        try:
            elem = self.wait.until(EC.visibility_of_element_located(self.ALERT_ANY))
            return elem.text
        except TimeoutException:
            return None

    def get_field_error(self, error_locator):
        try:
            elem = self.wait.until(EC.visibility_of_element_located(error_locator))
            return elem.text
        except TimeoutException:
            return None

    def get_title_error(self):
        return self.get_field_error(self.TITLE_ERROR)

    def get_price_error(self):
        return self.get_field_error(self.PRICE_ERROR)

    def get_area_error(self):
        return self.get_field_error(self.AREA_ERROR)

    def get_phone_error(self):
        return self.get_field_error(self.PHONE_ERROR)

    def get_html5_validation_message(self, locator):
        try:
            field = self.driver.find_element(*locator)
            return field.get_attribute("validationMessage") or ""
        except NoSuchElementException:
            return ""

    def get_post_status_after_update(self):
        """Go back to my-posts and return status of the first post"""
        self.navigate_to_my_posts()
        time.sleep(1)
        return self.get_first_post_status()
