from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import time


class SignupPage:
    """Page Object Model for Registration Page (/register)"""

    # ---------------------------------------------------------------- Locators
    NAME_INPUT = (By.ID, "name")
    EMAIL_INPUT = (By.ID, "email")
    PHONE_INPUT = (By.ID, "phone")
    PASSWORD_INPUT = (By.ID, "password")
    CONFIRM_PASSWORD_INPUT = (By.ID, "confirmPassword")
    AGREE_CHECKBOX = (By.ID, "agree")
    SUBMIT_BUTTON = (By.XPATH, "//button[@type='submit']")
    PASSWORD_TOGGLE = (By.XPATH, "//button[@class='toggle-pw']")
    LOGIN_LINK = (By.XPATH, "//a[contains(text(), 'Đăng nhập')]")
    TERMS_LINK = (By.XPATH, "//a[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), 'điều khoản')]")
    PRIVACY_LINK = (By.XPATH, "//a[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), 'chính sách')]")
    ALERT_SUCCESS = (By.CSS_SELECTOR, ".alert.alert-success, .alert-success")
    ALERT_ERROR = (By.CSS_SELECTOR, ".alert.alert-danger, .alert-danger")
    PW_MATCH_MSG = (By.ID, "pwMatchMsg")

    def __init__(self, driver, base_url):
        self.driver = driver
        self.base_url = base_url
        self.wait = WebDriverWait(driver, 10)

    # ---------------------------------------------------------------- Navigation
    def open(self):
        self.driver.get(f"{self.base_url}/register")
        self.wait.until(EC.presence_of_element_located(self.NAME_INPUT))

    # ---------------------------------------------------------------- Field actions
    def enter_name(self, name):
        elem = self.wait.until(EC.presence_of_element_located(self.NAME_INPUT))
        elem.clear()
        elem.send_keys(name)

    def enter_email(self, email):
        elem = self.driver.find_element(*self.EMAIL_INPUT)
        elem.clear()
        elem.send_keys(email)

    def enter_phone(self, phone):
        elem = self.driver.find_element(*self.PHONE_INPUT)
        elem.clear()
        elem.send_keys(phone)

    def enter_password(self, password):
        elem = self.driver.find_element(*self.PASSWORD_INPUT)
        elem.clear()
        elem.send_keys(password)

    def enter_confirm_password(self, password):
        elem = self.driver.find_element(*self.CONFIRM_PASSWORD_INPUT)
        elem.clear()
        elem.send_keys(password)

    def check_agree_terms(self):
        cb = self.driver.find_element(*self.AGREE_CHECKBOX)
        if not cb.is_selected():
            cb.click()

    def submit_form(self):
        self.driver.find_element(*self.SUBMIT_BUTTON).click()

    def submit_with_enter(self):
        self.driver.find_element(*self.CONFIRM_PASSWORD_INPUT).send_keys(Keys.RETURN)

    def toggle_password_visibility(self, field_type="password"):
        """Toggle visibility for 'password' or 'confirm' field."""
        toggles = self.driver.find_elements(*self.PASSWORD_TOGGLE)
        idx = 1 if field_type == "confirm" else 0
        if idx < len(toggles):
            toggles[idx].click()

    def get_password_field_type(self, field_type="password"):
        locator = self.CONFIRM_PASSWORD_INPUT if field_type == "confirm" else self.PASSWORD_INPUT
        return self.driver.find_element(*locator).get_attribute("type")

    # ---------------------------------------------------------------- Combined fill
    def fill_form(self, name="", email="", phone="", password="", confirm_pw="", agree=True):
        if name:
            self.enter_name(name)
        if email:
            self.enter_email(email)
        if phone:
            self.enter_phone(phone)
        if password:
            self.enter_password(password)
        if confirm_pw:
            self.enter_confirm_password(confirm_pw)
        if agree:
            self.check_agree_terms()

    # ---------------------------------------------------------------- Links
    def click_login_link(self):
        self.driver.find_element(*self.LOGIN_LINK).click()

    def click_terms_link(self):
        self.driver.find_element(*self.TERMS_LINK).click()

    def click_privacy_link(self):
        self.driver.find_element(*self.PRIVACY_LINK).click()

    def scroll_to_bottom(self):
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

    # ---------------------------------------------------------------- Getters
    def get_success_message(self):
        try:
            return self.wait.until(EC.visibility_of_element_located(self.ALERT_SUCCESS)).text
        except TimeoutException:
            return None

    def get_error_message(self):
        try:
            elem = self.driver.find_element(*self.ALERT_ERROR)
            return elem.text if elem.is_displayed() else None
        except NoSuchElementException:
            return None

    def get_password_match_message(self):
        try:
            return self.driver.find_element(*self.PW_MATCH_MSG).text
        except NoSuchElementException:
            return ""

    def is_name_field_focused(self):
        return self.driver.switch_to.active_element == self.driver.find_element(*self.NAME_INPUT)

    def get_field_validation_message(self, field_id):
        elem = self.driver.find_element(By.ID, field_id)
        return elem.get_attribute("validationMessage")

    def get_field_value(self, field_id):
        return self.driver.find_element(By.ID, field_id).get_attribute("value")
