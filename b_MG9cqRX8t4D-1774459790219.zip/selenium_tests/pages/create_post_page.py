from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import time
import os


class CreatePostPage:
    """Page Object Model for Create Post Page (/posts/create)"""

    # ------------------------------------------------------------------ URLs
    LOGIN_URL = "/login"
    CREATE_POST_URL = "/posts/create"
    MY_POSTS_URL = "/my-posts"

    # -------------------------------------------------------- Locators - Login
    LOGIN_EMAIL_INPUT = (By.ID, "email")
    LOGIN_PASSWORD_INPUT = (By.ID, "password")
    LOGIN_BUTTON = (By.CSS_SELECTOR, "button[type='submit']")

    # ------------------------------------------------ Locators - Form fields
    TITLE_INPUT = (By.ID, "title")
    DESCRIPTION_INPUT = (By.ID, "description")
    PRICE_INPUT = (By.ID, "price")
    AREA_INPUT = (By.ID, "area")
    ADDRESS_INPUT = (By.ID, "address")
    PHONE_INPUT = (By.ID, "phone")

    # Dropdowns
    LISTING_TYPE_SELECT = (By.ID, "listingType")          # Loại hình: Bán / Cho thuê
    PROPERTY_TYPE_SELECT = (By.ID, "propertyType")        # Loại BĐS / Danh mục BĐS

    # Checkbox điều khoản
    TERMS_CHECKBOX = (By.ID, "terms")
    TERMS_CHECKBOX_ALT = (By.CSS_SELECTOR, "input[type='checkbox'][id*='term'], input[type='checkbox'][name*='term']")

    # Submit / Cancel
    SUBMIT_BUTTON = (By.CSS_SELECTOR, "button[type='submit'], button[class*='submit'], button[class*='post']")
    CANCEL_BUTTON = (By.CSS_SELECTOR, "button[class*='cancel'], a[class*='cancel'], button[class*='huy']")

    # ------------------------------------------------ Locators - Image upload
    IMAGE_INPUT = (By.CSS_SELECTOR, "input[type='file'][accept*='image'], input[type='file']")
    IMAGE_PREVIEW_ITEMS = (By.CSS_SELECTOR, "[class*='image-preview'] img, [class*='preview-item'], [class*='img-thumb']")
    IMAGE_ERROR = (By.CSS_SELECTOR, "[class*='image-error'], [id*='imageError'], [class*='img'] .invalid-feedback")

    # ------------------------------------------------ Locators - Validation / Alerts
    TITLE_ERROR = (By.CSS_SELECTOR, "#titleError, #title ~ .invalid-feedback, [class*='title-error']")
    ADDRESS_ERROR = (By.CSS_SELECTOR, "#addressError, #address ~ .invalid-feedback, [class*='address-error']")
    PRICE_ERROR = (By.CSS_SELECTOR, "#priceError, #price ~ .invalid-feedback, [class*='price-error']")
    AREA_ERROR = (By.CSS_SELECTOR, "#areaError, #area ~ .invalid-feedback, [class*='area-error']")
    PHONE_ERROR = (By.CSS_SELECTOR, "#phoneError, #phone ~ .invalid-feedback, [class*='phone-error']")
    TERMS_ERROR = (By.CSS_SELECTOR, "#termsError, [class*='terms-error'], [class*='dieu-khoan']")

    ALERT_SUCCESS = (By.CSS_SELECTOR, ".alert-success, [class*='alert-success'], [class*='toast-success'], [class*='success']")
    ALERT_ERROR = (By.CSS_SELECTOR, ".alert-danger, [class*='alert-danger'], [class*='toast-error'], [class*='error']")
    ALERT_ANY = (By.CSS_SELECTOR, ".alert, [role='alert'], [class*='toast'], [class*='alert']")

    # Status indicators in my-posts
    POST_STATUS_BADGE = (By.CSS_SELECTOR, "[class*='status'], [class*='badge'], .badge")

    def __init__(self, driver, base_url):
        self.driver = driver
        self.base_url = base_url
        self.wait = WebDriverWait(driver, 10)

    # ================================================================= Navigation
    def navigate_to_login(self):
        self.driver.get(f"{self.base_url}{self.LOGIN_URL}")

    def navigate_to_create_post(self):
        self.driver.get(f"{self.base_url}{self.CREATE_POST_URL}")

    def navigate_to_my_posts(self):
        self.driver.get(f"{self.base_url}{self.MY_POSTS_URL}")

    def get_current_url(self):
        return self.driver.current_url

    # ================================================================= Login helper
    def login(self, email, password):
        """Login and wait for redirect"""
        self.navigate_to_login()
        self.wait.until(EC.presence_of_element_located(self.LOGIN_EMAIL_INPUT)).clear()
        self.driver.find_element(*self.LOGIN_EMAIL_INPUT).send_keys(email)
        self.driver.find_element(*self.LOGIN_PASSWORD_INPUT).clear()
        self.driver.find_element(*self.LOGIN_PASSWORD_INPUT).send_keys(password)
        self.driver.find_element(*self.LOGIN_BUTTON).click()
        time.sleep(2)

    # ================================================================= Form helpers
    def enter_title(self, title):
        field = self.wait.until(EC.presence_of_element_located(self.TITLE_INPUT))
        field.clear()
        field.send_keys(title)

    def clear_title(self):
        try:
            field = self.wait.until(EC.presence_of_element_located(self.TITLE_INPUT))
            field.clear()
        except TimeoutException:
            pass

    def enter_description(self, description):
        field = self.wait.until(EC.presence_of_element_located(self.DESCRIPTION_INPUT))
        field.clear()
        field.send_keys(description)

    def enter_price(self, price):
        field = self.wait.until(EC.presence_of_element_located(self.PRICE_INPUT))
        field.clear()
        field.send_keys(str(price))

    def enter_area(self, area):
        field = self.wait.until(EC.presence_of_element_located(self.AREA_INPUT))
        field.clear()
        field.send_keys(str(area))

    def enter_address(self, address):
        field = self.wait.until(EC.presence_of_element_located(self.ADDRESS_INPUT))
        field.clear()
        field.send_keys(address)

    def clear_address(self):
        try:
            field = self.wait.until(EC.presence_of_element_located(self.ADDRESS_INPUT))
            field.clear()
        except TimeoutException:
            pass

    def enter_phone(self, phone):
        field = self.wait.until(EC.presence_of_element_located(self.PHONE_INPUT))
        field.clear()
        field.send_keys(str(phone))

    def select_listing_type(self, value):
        """Select listing type by visible text or value (e.g. 'Bán', 'Cho thuê')"""
        try:
            select_elem = self.wait.until(EC.presence_of_element_located(self.LISTING_TYPE_SELECT))
            sel = Select(select_elem)
            try:
                sel.select_by_visible_text(value)
            except Exception:
                sel.select_by_value(value)
        except (TimeoutException, NoSuchElementException):
            # Fallback: custom dropdown
            try:
                dropdown = self.driver.find_element(By.CSS_SELECTOR, "[class*='listing-type'], [id*='listingType']")
                dropdown.click()
                time.sleep(0.5)
                option = self.driver.find_element(By.XPATH, f"//*[contains(text(), '{value}')]")
                option.click()
            except NoSuchElementException:
                pass

    def select_property_type(self, value):
        """Select property type by visible text (e.g. 'Chung cư', 'Nhà phố')"""
        try:
            select_elem = self.wait.until(EC.presence_of_element_located(self.PROPERTY_TYPE_SELECT))
            sel = Select(select_elem)
            try:
                sel.select_by_visible_text(value)
            except Exception:
                sel.select_by_value(value)
        except (TimeoutException, NoSuchElementException):
            try:
                dropdown = self.driver.find_element(By.CSS_SELECTOR, "[class*='property-type'], [id*='propertyType']")
                dropdown.click()
                time.sleep(0.5)
                option = self.driver.find_element(By.XPATH, f"//*[contains(text(), '{value}')]")
                option.click()
            except NoSuchElementException:
                pass

    def get_property_type_options(self):
        """Return list of all available property type options"""
        try:
            select_elem = self.wait.until(EC.presence_of_element_located(self.PROPERTY_TYPE_SELECT))
            sel = Select(select_elem)
            return [opt.text for opt in sel.options]
        except (TimeoutException, NoSuchElementException):
            return []

    def tick_terms(self):
        """Check the terms and conditions checkbox"""
        try:
            checkbox = self.wait.until(EC.presence_of_element_located(self.TERMS_CHECKBOX))
            if not checkbox.is_selected():
                checkbox.click()
        except (TimeoutException, NoSuchElementException):
            try:
                checkbox = self.driver.find_element(*self.TERMS_CHECKBOX_ALT)
                if not checkbox.is_selected():
                    checkbox.click()
            except NoSuchElementException:
                pass

    def is_terms_checked(self):
        try:
            checkbox = self.driver.find_element(*self.TERMS_CHECKBOX)
            return checkbox.is_selected()
        except NoSuchElementException:
            try:
                checkbox = self.driver.find_element(*self.TERMS_CHECKBOX_ALT)
                return checkbox.is_selected()
            except NoSuchElementException:
                return False

    def click_submit(self):
        btn = self.wait.until(EC.element_to_be_clickable(self.SUBMIT_BUTTON))
        btn.click()

    def click_cancel(self):
        try:
            btn = self.wait.until(EC.element_to_be_clickable(self.CANCEL_BUTTON))
            btn.click()
        except TimeoutException:
            # Fallback: navigate back
            self.driver.back()

    def confirm_cancel_prompt(self):
        """Handle browser confirm dialog after cancel"""
        try:
            WebDriverWait(self.driver, 3).until(EC.alert_is_present())
            self.driver.switch_to.alert.accept()
        except TimeoutException:
            # Modal confirm button
            try:
                confirm = self.driver.find_element(By.CSS_SELECTOR, ".modal .btn-danger, #confirmCancel, button[class*='confirm']")
                confirm.click()
            except NoSuchElementException:
                pass

    # ================================================================= Image upload helpers
    def upload_images(self, file_paths):
        """Upload one or more image files. file_paths is a list of absolute paths."""
        try:
            file_input = self.wait.until(EC.presence_of_element_located(self.IMAGE_INPUT))
            # Send all paths joined by newline for multi-file input
            file_input.send_keys("\n".join(file_paths))
            time.sleep(1)
        except TimeoutException:
            pass

    def get_image_preview_count(self):
        """Return count of image preview thumbnails"""
        try:
            items = self.driver.find_elements(*self.IMAGE_PREVIEW_ITEMS)
            return len(items)
        except NoSuchElementException:
            return 0

    def get_image_error_text(self):
        """Get image upload error message"""
        try:
            elem = self.wait.until(EC.visibility_of_element_located(self.IMAGE_ERROR))
            return elem.text
        except TimeoutException:
            return None

    # ================================================================= Validation / Alert helpers
    def get_field_error(self, error_locator):
        """Get error message text for a specific field"""
        try:
            elem = self.wait.until(EC.visibility_of_element_located(error_locator))
            return elem.text
        except TimeoutException:
            return None

    def get_title_error(self):
        return self.get_field_error(self.TITLE_ERROR)

    def get_address_error(self):
        return self.get_field_error(self.ADDRESS_ERROR)

    def get_price_error(self):
        return self.get_field_error(self.PRICE_ERROR)

    def get_area_error(self):
        return self.get_field_error(self.AREA_ERROR)

    def get_phone_error(self):
        return self.get_field_error(self.PHONE_ERROR)

    def get_terms_error(self):
        return self.get_field_error(self.TERMS_ERROR)

    def get_html5_validation_message(self, locator):
        """Get HTML5 native validation message for a field"""
        try:
            field = self.driver.find_element(*locator)
            return field.get_attribute("validationMessage") or ""
        except NoSuchElementException:
            return ""

    def get_price_field_value(self):
        try:
            return self.driver.find_element(*self.PRICE_INPUT).get_attribute("value")
        except NoSuchElementException:
            return ""

    def get_area_field_value(self):
        try:
            return self.driver.find_element(*self.AREA_INPUT).get_attribute("value")
        except NoSuchElementException:
            return ""

    def get_success_message(self):
        try:
            elem = self.wait.until(EC.visibility_of_element_located(self.ALERT_SUCCESS))
            return elem.text
        except TimeoutException:
            return None

    def get_error_message(self):
        try:
            elem = self.wait.until(EC.visibility_of_element_located(self.ALERT_ERROR))
            return elem.text
        except TimeoutException:
            return None

    def get_any_alert_message(self):
        try:
            elem = self.wait.until(EC.visibility_of_element_located(self.ALERT_ANY))
            return elem.text
        except TimeoutException:
            return None

    def get_post_status_from_my_posts(self):
        """Navigate to my-posts and return status of latest post"""
        self.navigate_to_my_posts()
        time.sleep(1)
        try:
            badges = self.driver.find_elements(*self.POST_STATUS_BADGE)
            if badges:
                return badges[0].text
        except NoSuchElementException:
            pass
        return None

    # ================================================================= Full form helpers
    def fill_valid_post_form(self,
                             title="Bán đất nền quận 9",
                             description="Mô tả chi tiết bất động sản",
                             price="2500000000",
                             area="100",
                             address="123 Đường ABC, Quận 9, TP.HCM",
                             phone="0901234567",
                             listing_type="Bán",
                             property_type=None):
        """Fill all required fields with valid data"""
        self.enter_title(title)
        self.enter_description(description)
        self.enter_price(price)
        self.enter_area(area)
        self.enter_address(address)
        self.enter_phone(phone)
        self.select_listing_type(listing_type)
        if property_type:
            self.select_property_type(property_type)
