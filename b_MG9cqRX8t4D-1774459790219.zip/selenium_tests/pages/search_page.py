from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import time


class SearchPage:
    """Page Object Model for Search & Filter functionality (Blue Group Real Estate)"""

    # ---------------------------------------------------------------- Locators
    # Search bar — matches common selector patterns in the Blue Group template
    SEARCH_INPUT = (By.CSS_SELECTOR,
                    "input[name='q'], input[placeholder*='tìm kiếm'], "
                    "input[placeholder*='Tìm kiếm'], input[type='search']")
    SEARCH_BUTTON = (By.CSS_SELECTOR, "button[type='submit'], .btn-search, .search-btn")

    # Loại hình dropdown (Nhà đất bán / Nhà đất cho thuê)
    PROPERTY_TYPE_DROPDOWN = (By.CSS_SELECTOR,
                               "select[name='loaihinh'], select[name='type'], .select-type")

    # Loại BĐS dropdown (Căn hộ, Chung cư, ...)
    CATEGORY_DROPDOWN = (By.CSS_SELECTOR,
                          "select[name='loaibds'], select[name='category'], .select-category")

    # Sắp xếp dropdown
    SORT_DROPDOWN = (By.CSS_SELECTOR,
                     "select[name='sapxep'], select[name='sort'], .select-sort")

    # Giá từ / Giá đến  (on listing page)
    PRICE_FROM_INPUT = (By.CSS_SELECTOR,
                         "input[name='giatu'], input[name='price_from'], input[placeholder*='Giá từ']")
    PRICE_TO_INPUT = (By.CSS_SELECTOR,
                       "input[name='giaden'], input[name='price_to'], input[placeholder*='Giá đến']")

    # Results
    RESULT_LIST = (By.CSS_SELECTOR,
                   ".property-list, .listing-list, .result-list, .danh-sach-bds")
    RESULT_ITEMS = (By.CSS_SELECTOR,
                    ".property-item, .listing-item, .result-item, .tin-bds")
    NO_RESULT_MSG = (By.CSS_SELECTOR,
                     ".no-result, .empty-result, .khong-tim-thay")
    SEARCH_SUGGESTIONS = (By.CSS_SELECTOR,
                           ".search-suggestions, .autocomplete-list, .suggestions-list")
    SUGGESTION_ITEMS = (By.CSS_SELECTOR,
                         ".suggestion-item, .autocomplete-item, li.suggestion")

    FLASH_MESSAGE = (By.CSS_SELECTOR, ".alert, .flash-message, .notification")
    ERROR_ALERT = (By.CSS_SELECTOR, ".alert-danger, .error-message")

    def __init__(self, driver, base_url):
        self.driver = driver
        self.base_url = base_url
        self.wait = WebDriverWait(driver, 10)

    # ---------------------------------------------------------------- Navigation
    def navigate_to_home(self):
        self.driver.get(self.base_url)
        time.sleep(1)

    def navigate_to_listing(self):
        self.driver.get(f"{self.base_url}/bat-dong-san")
        time.sleep(1)

    def get_current_url(self):
        return self.driver.current_url

    # ---------------------------------------------------------------- Search actions
    def enter_keyword(self, keyword):
        field = self.wait.until(EC.presence_of_element_located(self.SEARCH_INPUT))
        field.clear()
        field.send_keys(keyword)

    def press_search_button(self):
        btn = self.wait.until(EC.element_to_be_clickable(self.SEARCH_BUTTON))
        btn.click()

    def press_enter_to_search(self):
        self.driver.find_element(*self.SEARCH_INPUT).send_keys(Keys.RETURN)

    def search(self, keyword):
        """Full search: enter keyword and press Enter."""
        self.enter_keyword(keyword)
        self.press_enter_to_search()
        time.sleep(1)

    # ---------------------------------------------------------------- Filter actions
    def select_property_type(self, value_or_text):
        """Select Loại hình (e.g. 'Nhà đất bán')."""
        dropdown = self.wait.until(EC.presence_of_element_located(self.PROPERTY_TYPE_DROPDOWN))
        sel = Select(dropdown)
        try:
            sel.select_by_visible_text(value_or_text)
        except Exception:
            sel.select_by_value(value_or_text)

    def select_category(self, value_or_text):
        """Select Loại BĐS (e.g. 'Căn hộ')."""
        dropdown = self.wait.until(EC.presence_of_element_located(self.CATEGORY_DROPDOWN))
        sel = Select(dropdown)
        try:
            sel.select_by_visible_text(value_or_text)
        except Exception:
            sel.select_by_value(value_or_text)

    def select_sort(self, value_or_text):
        """Select sắp xếp (e.g. 'Mới nhất', 'Giá thấp đến cao')."""
        dropdown = self.wait.until(EC.presence_of_element_located(self.SORT_DROPDOWN))
        sel = Select(dropdown)
        try:
            sel.select_by_visible_text(value_or_text)
        except Exception:
            sel.select_by_value(value_or_text)

    def enter_price_from(self, price):
        field = self.wait.until(EC.presence_of_element_located(self.PRICE_FROM_INPUT))
        field.clear()
        field.send_keys(str(price))

    def enter_price_to(self, price):
        field = self.wait.until(EC.presence_of_element_located(self.PRICE_TO_INPUT))
        field.clear()
        field.send_keys(str(price))

    def is_category_option_present(self, option_text):
        try:
            sel = Select(self.driver.find_element(*self.CATEGORY_DROPDOWN))
            return any(option_text.lower() in o.text.lower() for o in sel.options)
        except NoSuchElementException:
            return False

    # ---------------------------------------------------------------- Result helpers
    def get_result_items(self):
        try:
            self.wait.until(EC.presence_of_element_located(self.RESULT_LIST))
            return self.driver.find_elements(*self.RESULT_ITEMS)
        except TimeoutException:
            return []

    def has_results(self):
        return len(self.get_result_items()) > 0

    def get_no_result_message(self):
        try:
            return self.wait.until(EC.visibility_of_element_located(self.NO_RESULT_MSG)).text
        except TimeoutException:
            return None

    def wait_for_suggestions(self, timeout=3):
        try:
            WebDriverWait(self.driver, timeout).until(
                EC.visibility_of_element_located(self.SEARCH_SUGGESTIONS)
            )
            return True
        except TimeoutException:
            return False

    def get_suggestion_items(self):
        return self.driver.find_elements(*self.SUGGESTION_ITEMS)

    def click_first_suggestion(self):
        suggestions = self.get_suggestion_items()
        if suggestions:
            suggestions[0].click()
            time.sleep(1)
            return True
        return False

    def get_result_prices(self):
        """Parse price values from result cards for sort-order validation."""
        items = self.get_result_items()
        prices = []
        for item in items:
            try:
                price_elem = item.find_element(By.CSS_SELECTOR, ".price, .gia, .property-price")
                txt = price_elem.text.lower()
                if "tỷ" in txt:
                    num = float("".join(c for c in txt.split("tỷ")[0] if c.isdigit() or c == "."))
                    prices.append(num * 1_000_000_000)
                elif "triệu" in txt:
                    num = float("".join(c for c in txt.split("triệu")[0] if c.isdigit() or c == "."))
                    prices.append(num * 1_000_000)
                else:
                    prices.append(float("".join(c for c in txt if c.isdigit())))
            except Exception:
                continue
        return prices

    def get_result_areas(self):
        """Parse area values from result cards for sort-order validation."""
        items = self.get_result_items()
        areas = []
        for item in items:
            try:
                area_elem = item.find_element(By.CSS_SELECTOR, ".area, .dien-tich, .property-area")
                txt = area_elem.text.replace("m²", "").replace("m2", "").strip()
                areas.append(float("".join(c for c in txt if c.isdigit() or c == ".")))
            except Exception:
                continue
        return areas

    def get_flash_message(self):
        try:
            return self.wait.until(EC.presence_of_element_located(self.FLASH_MESSAGE)).text
        except TimeoutException:
            return None

    def is_element_present(self, locator):
        try:
            self.driver.find_element(*locator)
            return True
        except NoSuchElementException:
            return False
