from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from selenium.webdriver.common.action_chains import ActionChains
import time


class AdminPage:
    """Page Object Model for Admin Panel (Posts, Users, Categories)"""

    # ------------------------------------------------------------------ URLs
    ADMIN_URL = "/admin"
    ADMIN_POSTS_URL = "/admin/posts"
    ADMIN_USERS_URL = "/admin/users"
    ADMIN_CATEGORIES_URL = "/admin/categories"
    LOGIN_URL = "/login"

    # -------------------------------------------------------- Locators - Login
    LOGIN_EMAIL_INPUT = (By.ID, "email")
    LOGIN_PASSWORD_INPUT = (By.ID, "password")
    LOGIN_BUTTON = (By.CSS_SELECTOR, "button[type='submit']")

    # -------------------------------------------- Locators - Admin nav/sidebar
    NAV_POSTS = (By.CSS_SELECTOR, "a[href*='admin/posts'], a[href*='quan-ly-tin'], [class*='nav'] a[href*='post']")
    NAV_USERS = (By.CSS_SELECTOR, "a[href*='admin/users'], a[href*='quan-ly-nguoi'], [class*='nav'] a[href*='user']")
    NAV_CATEGORIES = (By.CSS_SELECTOR, "a[href*='admin/categories'], a[href*='danh-muc'], [class*='nav'] a[href*='categor']")

    # ------------------------------------------ Locators - Posts management table
    POSTS_TABLE = (By.CSS_SELECTOR, "table, [class*='table'], [class*='post-list']")
    POST_TABLE_HEADERS = (By.CSS_SELECTOR, "table th, [class*='table'] th, [class*='col-header']")
    POST_ROWS = (By.CSS_SELECTOR, "table tbody tr, [class*='post-row'], [class*='post-item']")
    POST_TITLE_COL = (By.CSS_SELECTOR, "td:nth-child(1), [class*='title-col']")
    POST_AUTHOR_COL = (By.CSS_SELECTOR, "td:nth-child(2), [class*='author-col']")
    POST_STATUS_COL = (By.CSS_SELECTOR, "td[class*='status'], [class*='status-badge']")

    # ----------------------------------------- Locators - Posts filter/search
    POST_STATUS_FILTER = (By.CSS_SELECTOR, "select[name*='status'], select[id*='status'], [class*='status-filter']")
    POST_SEARCH_BTN = (By.CSS_SELECTOR, "button[type='submit'], button[class*='search'], button[class*='tim-kiem']")
    POST_SEARCH_INPUT = (By.CSS_SELECTOR, "input[name*='search'], input[placeholder*='tìm'], input[placeholder*='tim'], input[type='search']")

    # ----------------------------------------- Locators - Post action buttons (per row)
    POST_APPROVE_BTN = (By.CSS_SELECTOR, "button[class*='approve'], button[class*='duyet'], a[class*='approve']")
    POST_REJECT_BTN = (By.CSS_SELECTOR, "button[class*='reject'], button[class*='tu-choi'], a[class*='reject']")
    POST_VIEW_BTN = (By.CSS_SELECTOR, "button[class*='view'], a[class*='view'], a[href*='posts/']")
    POST_DELETE_BTN = (By.CSS_SELECTOR, "button[class*='delete'], button[class*='xoa'], a[class*='delete']")
    POST_DELETE_CONFIRM_BTN = (By.CSS_SELECTOR, ".modal .btn-danger, #confirmDelete, button[class*='confirm']")

    # ------------------------------------------ Locators - Users management table
    USERS_TABLE = (By.CSS_SELECTOR, "table, [class*='table'], [class*='user-list']")
    USER_TABLE_HEADERS = (By.CSS_SELECTOR, "table th, [class*='table'] th, [class*='col-header']")
    USER_ROWS = (By.CSS_SELECTOR, "table tbody tr, [class*='user-row'], [class*='user-item']")

    # ----------------------------------------- Locators - Users filter/search
    USER_ROLE_FILTER = (By.CSS_SELECTOR, "select[name*='role'], select[id*='role'], [class*='role-filter']")
    USER_STATUS_FILTER = (By.CSS_SELECTOR, "select[name*='status'], select[id*='status'], [class*='status-filter']")
    USER_SEARCH_INPUT = (By.CSS_SELECTOR, "input[name*='search'], input[placeholder*='tìm'], input[placeholder*='tim'], input[type='search']")
    USER_SEARCH_BTN = (By.CSS_SELECTOR, "button[type='submit'], button[class*='search'], button[class*='tim-kiem']")

    # ----------------------------------------- Locators - User action buttons (per row)
    USER_GRANT_ADMIN_BTN = (By.CSS_SELECTOR, "button[class*='grant'], button[class*='cap-quyen'], button[title*='admin']")
    USER_REVOKE_ADMIN_BTN = (By.CSS_SELECTOR, "button[class*='revoke'], button[class*='huy-quyen'], button[title*='revoke']")
    USER_DEACTIVATE_BTN = (By.CSS_SELECTOR, "button[class*='deactivate'], button[class*='vo-hieu'], button[class*='block']")
    USER_ACTIVATE_BTN = (By.CSS_SELECTOR, "button[class*='activate'], button[class*='kich-hoat'], button[class*='unblock']")
    USER_CHANGE_PASSWORD_BTN = (By.CSS_SELECTOR, "button[class*='change-pw'], button[class*='doi-mat-khau'], button[title*='password']")
    USER_DELETE_BTN = (By.CSS_SELECTOR, "button[class*='delete-user'], button[class*='xoa-user'], button[class*='remove-user']")
    USER_DELETE_CONFIRM_BTN = (By.CSS_SELECTOR, ".modal .btn-danger, #confirmDelete, button[class*='confirm']")

    # ----------------------------------------- Locators - Change password modal (user)
    CHANGE_PW_MODAL = (By.CSS_SELECTOR, ".modal, [class*='modal'], [role='dialog']")
    CHANGE_PW_NEW_INPUT = (By.CSS_SELECTOR, ".modal input[type='password'], [role='dialog'] input[type='password']")
    CHANGE_PW_CONFIRM_INPUT = (By.CSS_SELECTOR, ".modal input[id*='confirm'], [role='dialog'] input[id*='confirm']")
    CHANGE_PW_SUBMIT_BTN = (By.CSS_SELECTOR, ".modal button[type='submit'], [role='dialog'] button[type='submit'], .modal .btn-primary")

    # ------------------------------------------ Locators - Categories management
    CATEGORIES_TABLE = (By.CSS_SELECTOR, "table, [class*='table'], [class*='category-list']")
    CATEGORY_ROWS = (By.CSS_SELECTOR, "table tbody tr, [class*='category-row'], [class*='category-item']")
    ADD_CATEGORY_BTN = (By.CSS_SELECTOR, "button[class*='add'], button[class*='them'], a[class*='add-category']")
    EDIT_CATEGORY_BTN = (By.CSS_SELECTOR, "button[class*='edit'], button[class*='chinh-sua'], a[class*='edit']")
    DISABLE_CATEGORY_BTN = (By.CSS_SELECTOR, "button[class*='disable'], button[class*='vo-hieu'], button[class*='deactivate']")
    DELETE_CATEGORY_BTN = (By.CSS_SELECTOR, "button[class*='delete'], button[class*='xoa'], a[class*='delete']")
    DELETE_CATEGORY_CONFIRM_BTN = (By.CSS_SELECTOR, ".modal .btn-danger, #confirmDelete, button[class*='confirm']")

    # ----------------------------------------- Locators - Category modal (add/edit)
    CAT_MODAL = (By.CSS_SELECTOR, ".modal, [class*='modal'], [role='dialog']")
    CAT_NAME_INPUT = (By.CSS_SELECTOR, ".modal input[name*='name'], .modal #catName, [role='dialog'] input[name*='name']")
    CAT_DESC_INPUT = (By.CSS_SELECTOR, ".modal textarea[name*='desc'], .modal #catDesc, [role='dialog'] textarea")
    CAT_SUBMIT_BTN = (By.CSS_SELECTOR, ".modal button[type='submit'], [role='dialog'] button[type='submit'], .modal .btn-primary")

    # ----------------------------------------- Locators - Categories filter/search
    CAT_SEARCH_INPUT = (By.CSS_SELECTOR, "input[name*='search'], input[placeholder*='tìm'], input[placeholder*='tim'], input[type='search']")
    CAT_STATUS_FILTER = (By.CSS_SELECTOR, "select[name*='status'], select[id*='status'], [class*='status-filter']")
    CAT_SEARCH_BTN = (By.CSS_SELECTOR, "button[type='submit'], button[class*='search'], button[class*='tim-kiem']")

    # ----------------------------------------- Locators - Alerts
    ALERT_SUCCESS = (By.CSS_SELECTOR, ".alert-success, [class*='alert-success'], [class*='success']")
    ALERT_ERROR = (By.CSS_SELECTOR, ".alert-danger, [class*='alert-danger'], [class*='error']")
    ALERT_ANY = (By.CSS_SELECTOR, ".alert, [class*='alert'], [role='alert'], .toast, [class*='toast']")

    # ----------------------------------------- Locators - Empty state
    EMPTY_STATE = (By.CSS_SELECTOR, "[class*='empty'], [class*='no-result'], td[colspan]")

    def __init__(self, driver, base_url):
        self.driver = driver
        self.base_url = base_url
        self.wait = WebDriverWait(driver, 10)

    # ================================================================= Navigation
    def navigate_to_login(self):
        self.driver.get(f"{self.base_url}{self.LOGIN_URL}")

    def navigate_to_admin(self):
        self.driver.get(f"{self.base_url}{self.ADMIN_URL}")

    def navigate_to_admin_posts(self):
        self.driver.get(f"{self.base_url}{self.ADMIN_POSTS_URL}")

    def navigate_to_admin_users(self):
        self.driver.get(f"{self.base_url}{self.ADMIN_USERS_URL}")

    def navigate_to_admin_categories(self):
        self.driver.get(f"{self.base_url}{self.ADMIN_CATEGORIES_URL}")

    def get_current_url(self):
        return self.driver.current_url

    # ================================================================= Login helpers
    def login(self, email, password):
        """Login and wait for redirect"""
        self.navigate_to_login()
        self.wait.until(EC.presence_of_element_located(self.LOGIN_EMAIL_INPUT)).clear()
        self.driver.find_element(*self.LOGIN_EMAIL_INPUT).send_keys(email)
        self.driver.find_element(*self.LOGIN_PASSWORD_INPUT).clear()
        self.driver.find_element(*self.LOGIN_PASSWORD_INPUT).send_keys(password)
        self.driver.find_element(*self.LOGIN_BUTTON).click()
        time.sleep(2)

    # ================================================================= Posts helpers
    def get_post_table_headers(self):
        """Return list of column header texts from posts table"""
        try:
            headers = self.wait.until(EC.presence_of_all_elements_located(self.POST_TABLE_HEADERS))
            return [h.text.strip() for h in headers]
        except TimeoutException:
            return []

    def get_post_rows(self):
        """Return list of post row elements"""
        try:
            return self.wait.until(EC.presence_of_all_elements_located(self.POST_ROWS))
        except TimeoutException:
            return []

    def select_post_status_filter(self, status_value):
        """Select post status filter option by visible text or value"""
        try:
            from selenium.webdriver.support.ui import Select
            select_el = self.wait.until(EC.presence_of_element_located(self.POST_STATUS_FILTER))
            sel = Select(select_el)
            try:
                sel.select_by_visible_text(status_value)
            except Exception:
                sel.select_by_value(status_value)
            return True
        except (TimeoutException, NoSuchElementException):
            return False

    def click_post_search(self):
        """Click the search/filter button in posts management"""
        try:
            btn = self.wait.until(EC.element_to_be_clickable(self.POST_SEARCH_BTN))
            btn.click()
            time.sleep(1)
        except TimeoutException:
            pass

    def get_post_statuses_in_table(self):
        """Return list of visible status texts from posts table rows"""
        statuses = []
        try:
            rows = self.driver.find_elements(*self.POST_ROWS)
            for row in rows:
                try:
                    status_el = row.find_element(*self.POST_STATUS_COL)
                    statuses.append(status_el.text.strip())
                except NoSuchElementException:
                    # Fallback: grab all td text
                    tds = row.find_elements(By.TAG_NAME, "td")
                    if tds:
                        statuses.append(tds[-2].text.strip() if len(tds) >= 2 else "")
        except Exception:
            pass
        return statuses

    def click_approve_for_post(self, post_title):
        """Find post row by title and click its approve button"""
        return self._click_action_btn_for_row(post_title, self.POST_APPROVE_BTN)

    def click_reject_for_post(self, post_title):
        """Find post row by title and click its reject button"""
        return self._click_action_btn_for_row(post_title, self.POST_REJECT_BTN)

    def click_view_for_post(self, post_title):
        """Find post row by title and click its view button"""
        return self._click_action_btn_for_row(post_title, self.POST_VIEW_BTN)

    def click_delete_for_post(self, post_title):
        """Find post row by title and click its delete button"""
        return self._click_action_btn_for_row(post_title, self.POST_DELETE_BTN)

    def confirm_delete_post(self):
        """Confirm deletion via modal or browser alert"""
        self._confirm_action()

    def get_post_status_by_title(self, post_title):
        """Return status text of a post row matching the given title"""
        try:
            rows = self.driver.find_elements(*self.POST_ROWS)
            for row in rows:
                if post_title.lower() in row.text.lower():
                    tds = row.find_elements(By.TAG_NAME, "td")
                    for td in tds:
                        td_text = td.text.strip()
                        if any(s in td_text.lower() for s in ["duyệt", "chờ", "từ chối", "approved", "pending", "rejected"]):
                            return td_text
                    return row.text
        except Exception:
            pass
        return None

    def is_post_in_table(self, post_title):
        """Check if a post with given title exists in the table"""
        try:
            rows = self.driver.find_elements(*self.POST_ROWS)
            for row in rows:
                if post_title.lower() in row.text.lower():
                    return True
        except Exception:
            pass
        return False

    def get_post_row_text_by_title(self, post_title):
        """Return full text of the row containing the given post title"""
        try:
            rows = self.driver.find_elements(*self.POST_ROWS)
            for row in rows:
                if post_title.lower() in row.text.lower():
                    return row.text
        except Exception:
            pass
        return None

    # ================================================================= Users helpers
    def get_user_table_headers(self):
        """Return list of column header texts from users table"""
        try:
            headers = self.wait.until(EC.presence_of_all_elements_located(self.USER_TABLE_HEADERS))
            return [h.text.strip() for h in headers]
        except TimeoutException:
            return []

    def get_user_rows(self):
        """Return list of user row elements"""
        try:
            return self.wait.until(EC.presence_of_all_elements_located(self.USER_ROWS))
        except TimeoutException:
            return []

    def select_user_role_filter(self, role_value):
        """Select role filter option"""
        try:
            from selenium.webdriver.support.ui import Select
            select_el = self.wait.until(EC.presence_of_element_located(self.USER_ROLE_FILTER))
            sel = Select(select_el)
            try:
                sel.select_by_visible_text(role_value)
            except Exception:
                sel.select_by_value(role_value)
            return True
        except (TimeoutException, NoSuchElementException):
            return False

    def select_user_status_filter(self, status_value):
        """Select status filter option"""
        try:
            from selenium.webdriver.support.ui import Select
            select_el = self.wait.until(EC.presence_of_element_located(self.USER_STATUS_FILTER))
            sel = Select(select_el)
            try:
                sel.select_by_visible_text(status_value)
            except Exception:
                sel.select_by_value(status_value)
            return True
        except (TimeoutException, NoSuchElementException):
            return False

    def enter_user_search(self, keyword):
        """Type keyword into user search input"""
        try:
            field = self.wait.until(EC.presence_of_element_located(self.USER_SEARCH_INPUT))
            field.clear()
            field.send_keys(keyword)
        except TimeoutException:
            pass

    def click_user_search(self):
        """Click user search button"""
        try:
            btn = self.wait.until(EC.element_to_be_clickable(self.USER_SEARCH_BTN))
            btn.click()
            time.sleep(1)
        except TimeoutException:
            pass

    def get_user_row_texts(self):
        """Return list of text content for each user row"""
        try:
            rows = self.driver.find_elements(*self.USER_ROWS)
            return [row.text.strip() for row in rows]
        except Exception:
            return []

    def is_user_in_table(self, keyword):
        """Check if a user matching keyword exists in the table"""
        try:
            rows = self.driver.find_elements(*self.USER_ROWS)
            for row in rows:
                if keyword.lower() in row.text.lower():
                    return True
        except Exception:
            pass
        return False

    def get_row_roles_in_table(self):
        """Return list of role texts from all user rows"""
        roles = []
        try:
            rows = self.driver.find_elements(*self.USER_ROWS)
            for row in rows:
                tds = row.find_elements(By.TAG_NAME, "td")
                for td in tds:
                    td_text = td.text.strip().lower()
                    if "admin" in td_text or "người dùng" in td_text or "user" in td_text:
                        roles.append(td.text.strip())
                        break
        except Exception:
            pass
        return roles

    def get_row_statuses_in_table(self):
        """Return list of status texts from all user rows"""
        statuses = []
        try:
            rows = self.driver.find_elements(*self.USER_ROWS)
            for row in rows:
                tds = row.find_elements(By.TAG_NAME, "td")
                for td in tds:
                    td_text = td.text.strip().lower()
                    if "hoạt động" in td_text or "bị khóa" in td_text or "active" in td_text or "blocked" in td_text:
                        statuses.append(td.text.strip())
                        break
        except Exception:
            pass
        return statuses

    def hover_and_click_user_action(self, user_keyword, action_btn_locator):
        """Hover over the user row matching keyword and click the action button"""
        try:
            rows = self.driver.find_elements(*self.USER_ROWS)
            for row in rows:
                if user_keyword.lower() in row.text.lower():
                    ActionChains(self.driver).move_to_element(row).perform()
                    time.sleep(0.5)
                    try:
                        btn = row.find_element(*action_btn_locator)
                        btn.click()
                        return True
                    except NoSuchElementException:
                        # Fallback: try visible buttons in row
                        btns = row.find_elements(By.TAG_NAME, "button")
                        if btns:
                            btns[0].click()
                            return True
        except Exception:
            pass
        return False

    def click_grant_admin_for_user(self, user_keyword):
        """Click grant admin button for user matching keyword"""
        return self.hover_and_click_user_action(user_keyword, self.USER_GRANT_ADMIN_BTN)

    def click_revoke_admin_for_user(self, user_keyword):
        """Click revoke admin button for user matching keyword"""
        return self.hover_and_click_user_action(user_keyword, self.USER_REVOKE_ADMIN_BTN)

    def click_deactivate_for_user(self, user_keyword):
        """Click deactivate button for user matching keyword"""
        return self.hover_and_click_user_action(user_keyword, self.USER_DEACTIVATE_BTN)

    def click_activate_for_user(self, user_keyword):
        """Click activate button for user matching keyword"""
        return self.hover_and_click_user_action(user_keyword, self.USER_ACTIVATE_BTN)

    def click_change_password_for_user(self, user_keyword):
        """Click change password button for user matching keyword"""
        return self.hover_and_click_user_action(user_keyword, self.USER_CHANGE_PASSWORD_BTN)

    def click_delete_for_user(self, user_keyword):
        """Click delete button for user matching keyword"""
        return self.hover_and_click_user_action(user_keyword, self.USER_DELETE_BTN)

    def fill_change_password_modal(self, new_password, confirm_password=None):
        """Fill new password fields in change-password modal"""
        try:
            self.wait.until(EC.visibility_of_element_located(self.CHANGE_PW_MODAL))
            pw_inputs = self.driver.find_elements(*self.CHANGE_PW_NEW_INPUT)
            if pw_inputs:
                pw_inputs[0].clear()
                pw_inputs[0].send_keys(new_password)
            if confirm_password and len(pw_inputs) > 1:
                pw_inputs[1].clear()
                pw_inputs[1].send_keys(confirm_password)
            elif confirm_password:
                try:
                    confirm_field = self.driver.find_element(*self.CHANGE_PW_CONFIRM_INPUT)
                    confirm_field.clear()
                    confirm_field.send_keys(confirm_password)
                except NoSuchElementException:
                    pass
        except TimeoutException:
            pass

    def submit_change_password_modal(self):
        """Click submit in change-password modal"""
        try:
            btn = self.wait.until(EC.element_to_be_clickable(self.CHANGE_PW_SUBMIT_BTN))
            btn.click()
        except TimeoutException:
            pass

    def get_user_role_by_keyword(self, user_keyword):
        """Return role text for a user row matching keyword"""
        try:
            rows = self.driver.find_elements(*self.USER_ROWS)
            for row in rows:
                if user_keyword.lower() in row.text.lower():
                    tds = row.find_elements(By.TAG_NAME, "td")
                    for td in tds:
                        td_text = td.text.strip().lower()
                        if "admin" in td_text or "người dùng" in td_text or "user" in td_text:
                            return td.text.strip()
        except Exception:
            pass
        return None

    def get_user_status_by_keyword(self, user_keyword):
        """Return status text for a user row matching keyword"""
        try:
            rows = self.driver.find_elements(*self.USER_ROWS)
            for row in rows:
                if user_keyword.lower() in row.text.lower():
                    tds = row.find_elements(By.TAG_NAME, "td")
                    for td in tds:
                        td_text = td.text.strip().lower()
                        if "hoạt động" in td_text or "bị khóa" in td_text or "active" in td_text or "blocked" in td_text:
                            return td.text.strip()
        except Exception:
            pass
        return None

    # ================================================================= Categories helpers
    def get_category_rows(self):
        """Return list of category row elements"""
        try:
            return self.wait.until(EC.presence_of_all_elements_located(self.CATEGORY_ROWS))
        except TimeoutException:
            return []

    def click_add_category(self):
        """Click the Add Category button"""
        try:
            btn = self.wait.until(EC.element_to_be_clickable(self.ADD_CATEGORY_BTN))
            btn.click()
            time.sleep(0.5)
        except TimeoutException:
            pass

    def fill_category_modal(self, name, description=""):
        """Fill name and description in category modal"""
        try:
            self.wait.until(EC.visibility_of_element_located(self.CAT_MODAL))
            name_field = self.wait.until(EC.presence_of_element_located(self.CAT_NAME_INPUT))
            name_field.clear()
            name_field.send_keys(name)
            if description:
                try:
                    desc_field = self.driver.find_element(*self.CAT_DESC_INPUT)
                    desc_field.clear()
                    desc_field.send_keys(description)
                except NoSuchElementException:
                    pass
        except TimeoutException:
            pass

    def submit_category_modal(self):
        """Click submit button in category modal"""
        try:
            btn = self.wait.until(EC.element_to_be_clickable(self.CAT_SUBMIT_BTN))
            btn.click()
            time.sleep(1)
        except TimeoutException:
            pass

    def click_edit_for_category(self, cat_keyword):
        """Click edit button for category row matching keyword"""
        return self._click_action_btn_for_row(cat_keyword, self.EDIT_CATEGORY_BTN)

    def click_disable_for_category(self, cat_keyword):
        """Click disable/deactivate button for category matching keyword"""
        return self._click_action_btn_for_row(cat_keyword, self.DISABLE_CATEGORY_BTN)

    def click_delete_for_category(self, cat_keyword):
        """Click delete button for category matching keyword"""
        return self._click_action_btn_for_row(cat_keyword, self.DELETE_CATEGORY_BTN)

    def confirm_delete_category(self):
        """Confirm deletion of category via modal or alert"""
        self._confirm_action()

    def enter_category_search(self, keyword):
        """Type keyword into category search input"""
        try:
            field = self.wait.until(EC.presence_of_element_located(self.CAT_SEARCH_INPUT))
            field.clear()
            field.send_keys(keyword)
        except TimeoutException:
            pass

    def select_category_status_filter(self, status_value):
        """Select category status filter option"""
        try:
            from selenium.webdriver.support.ui import Select
            select_el = self.wait.until(EC.presence_of_element_located(self.CAT_STATUS_FILTER))
            sel = Select(select_el)
            try:
                sel.select_by_visible_text(status_value)
            except Exception:
                sel.select_by_value(status_value)
            return True
        except (TimeoutException, NoSuchElementException):
            return False

    def click_category_search(self):
        """Click category search button"""
        try:
            btn = self.wait.until(EC.element_to_be_clickable(self.CAT_SEARCH_BTN))
            btn.click()
            time.sleep(1)
        except TimeoutException:
            pass

    def is_category_in_table(self, keyword):
        """Check if category with keyword exists in the table"""
        try:
            rows = self.driver.find_elements(*self.CATEGORY_ROWS)
            for row in rows:
                if keyword.lower() in row.text.lower():
                    return True
        except Exception:
            pass
        return False

    def get_category_row_texts(self):
        """Return list of text content for each category row"""
        try:
            rows = self.driver.find_elements(*self.CATEGORY_ROWS)
            return [row.text.strip() for row in rows]
        except Exception:
            return []

    def get_category_status_by_keyword(self, cat_keyword):
        """Return status text for a category row matching keyword"""
        try:
            rows = self.driver.find_elements(*self.CATEGORY_ROWS)
            for row in rows:
                if cat_keyword.lower() in row.text.lower():
                    tds = row.find_elements(By.TAG_NAME, "td")
                    for td in tds:
                        td_text = td.text.strip().lower()
                        if "hoạt động" in td_text or "vô hiệu" in td_text or "active" in td_text or "disabled" in td_text:
                            return td.text.strip()
        except Exception:
            pass
        return None

    # ================================================================= Alert helpers
    def get_success_message(self):
        """Get success alert text"""
        try:
            elem = self.wait.until(EC.visibility_of_element_located(self.ALERT_SUCCESS))
            return elem.text
        except TimeoutException:
            return None

    def get_error_message(self):
        """Get error alert text"""
        try:
            elem = self.wait.until(EC.visibility_of_element_located(self.ALERT_ERROR))
            return elem.text
        except TimeoutException:
            return None

    def get_any_alert_message(self):
        """Get text of any visible alert or toast"""
        try:
            elem = self.wait.until(EC.visibility_of_element_located(self.ALERT_ANY))
            return elem.text
        except TimeoutException:
            return None

    def is_empty_state_shown(self):
        """Check if empty/no-result state is displayed"""
        try:
            el = self.driver.find_element(*self.EMPTY_STATE)
            return el.is_displayed()
        except NoSuchElementException:
            return False

    # ================================================================= Private helpers
    def _click_action_btn_for_row(self, row_keyword, btn_locator):
        """Generic: find row by keyword and click action button within it"""
        try:
            rows = self.driver.find_elements(By.CSS_SELECTOR, "table tbody tr, [class*='row'], [class*='item']")
            for row in rows:
                if row_keyword.lower() in row.text.lower():
                    try:
                        btn = row.find_element(*btn_locator)
                        btn.click()
                        return True
                    except NoSuchElementException:
                        # Fallback: click first button in row
                        btns = row.find_elements(By.TAG_NAME, "button")
                        links = row.find_elements(By.TAG_NAME, "a")
                        for el in btns + links:
                            if any(k in (el.get_attribute("class") or "").lower()
                                   for k in btn_locator[1].split(",")):
                                el.click()
                                return True
        except Exception:
            pass
        return False

    def _confirm_action(self):
        """Handle confirmation via browser alert or modal"""
        try:
            WebDriverWait(self.driver, 3).until(EC.alert_is_present())
            self.driver.switch_to.alert.accept()
        except TimeoutException:
            try:
                confirm_btn = self.driver.find_element(
                    By.CSS_SELECTOR, ".modal .btn-danger, #confirmDelete, button[class*='confirm']"
                )
                confirm_btn.click()
            except NoSuchElementException:
                pass
        time.sleep(1)
