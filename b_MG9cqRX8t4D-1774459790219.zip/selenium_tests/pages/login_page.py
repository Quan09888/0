from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
import time


class LoginPage:
    """Page Object Model for Login Page (/login)"""

    # ---------------------------------------------------------------- Locators
    EMAIL_INPUT = (By.ID, "email")
    PASSWORD_INPUT = (By.ID, "password")
    REMEMBER_CHECKBOX = (By.ID, "remember")
    LOGIN_BUTTON = (By.CSS_SELECTOR, "button[type='submit']")
    PASSWORD_TOGGLE_BTN = (By.CSS_SELECTOR, ".toggle-pw")
    FORGOT_PASSWORD_LINK = (By.LINK_TEXT, "Quên mật khẩu?")
    SIGNUP_LINK = (By.LINK_TEXT, "Đăng ký ngay")
    SUCCESS_MESSAGE = (By.CSS_SELECTOR, ".alert-success")
    ERROR_MESSAGE = (By.CSS_SELECTOR, ".alert-danger")
    FLASH_MESSAGE = (By.CSS_SELECTOR, ".alert")

    def __init__(self, driver, base_url):
        self.driver = driver
        self.base_url = base_url
        self.wait = WebDriverWait(driver, 10)

    # ---------------------------------------------------------------- Navigation
    def navigate_to_login(self):
        self.driver.get(f"{self.base_url}/login")

    # ---------------------------------------------------------------- Actions
    def enter_email(self, email):
        field = self.wait.until(EC.presence_of_element_located(self.EMAIL_INPUT))
        field.clear()
        field.send_keys(email)

    def enter_password(self, password):
        field = self.wait.until(EC.presence_of_element_located(self.PASSWORD_INPUT))
        field.clear()
        field.send_keys(password)

    def click_login_button(self):
        btn = self.wait.until(EC.element_to_be_clickable(self.LOGIN_BUTTON))
        btn.click()

    def click_remember_me(self):
        cb = self.driver.find_element(*self.REMEMBER_CHECKBOX)
        if not cb.is_selected():
            cb.click()

    def unclick_remember_me(self):
        cb = self.driver.find_element(*self.REMEMBER_CHECKBOX)
        if cb.is_selected():
            cb.click()

    def toggle_password_visibility(self):
        self.driver.find_element(*self.PASSWORD_TOGGLE_BTN).click()

    def get_password_input_type(self):
        return self.driver.find_element(*self.PASSWORD_INPUT).get_attribute("type")

    def submit_form_with_enter(self):
        self.driver.find_element(*self.PASSWORD_INPUT).send_keys(Keys.RETURN)

    def click_forgot_password_link(self):
        self.driver.find_element(*self.FORGOT_PASSWORD_LINK).click()

    def click_signup_link(self):
        self.driver.find_element(*self.SIGNUP_LINK).click()

    def login(self, email, password, remember=False):
        """Full login flow."""
        self.enter_email(email)
        self.enter_password(password)
        if remember:
            self.click_remember_me()
        self.click_login_button()

    # ---------------------------------------------------------------- Getters
    def get_flash_message(self):
        try:
            return self.wait.until(EC.presence_of_element_located(self.FLASH_MESSAGE)).text
        except Exception:
            return None

    def get_error_message(self):
        try:
            return self.wait.until(EC.presence_of_element_located(self.ERROR_MESSAGE)).text
        except Exception:
            return None

    def get_success_message(self):
        try:
            return self.wait.until(EC.presence_of_element_located(self.SUCCESS_MESSAGE)).text
        except Exception:
            return None

    def is_element_present(self, locator):
        try:
            self.driver.find_element(*locator)
            return True
        except Exception:
            return False
