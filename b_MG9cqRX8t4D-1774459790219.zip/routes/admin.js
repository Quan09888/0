const express = require("express");
const router = express.Router();
const adminController = require("../controllers/adminController");
const { requireAuth, requireAdmin } = require("../middleware/auth");

// All admin routes require authentication and admin role
router.use(requireAuth);
router.use(requireAdmin);

// Dashboard
router.get("/", adminController.dashboard);

// Post management
router.get("/posts", adminController.posts);
router.post("/posts/:id/approve", adminController.approvePost);
router.post("/posts/:id/reject", adminController.rejectPost);
router.delete("/posts/:id", adminController.deletePost);

// User management
router.get("/users", adminController.users);
router.post("/users/:id/activate", adminController.activateUser);
router.post("/users/:id/deactivate", adminController.deactivateUser);
router.post("/users/:id/make-admin", adminController.makeAdmin);
router.post("/users/:id/remove-admin", adminController.removeAdmin);
router.post("/users/:id/change-password", adminController.changeUserPassword);
router.delete("/users/:id", adminController.deleteUser);

// Category management
router.get("/categories", adminController.categories);
router.post("/categories", adminController.createCategory);
router.put("/categories/:id", adminController.updateCategory);
router.post("/categories/:id/activate", adminController.activateCategory);
router.post("/categories/:id/deactivate", adminController.deactivateCategory);
router.delete("/categories/:id", adminController.deleteCategory);

// Seed database (for development)
router.post("/seed-database", adminController.seedDatabase);

module.exports = router;
