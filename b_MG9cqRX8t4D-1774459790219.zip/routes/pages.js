const express = require('express');
const router = express.Router();
const { Post, Category } = require('../models');

// Home page
router.get('/', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = 12;
    const skip = (page - 1) * limit;

    const filter = { isApproved: true };

    if (req.query.search) {
      filter.$or = [
        { title: { $regex: req.query.search, $options: 'i' } },
        { description: { $regex: req.query.search, $options: 'i' } },
      ];
    }

    if (req.query.category) {
      filter.category = req.query.category;
    }

    if (req.query.type) {
      filter.type = req.query.type;
    }

    const [posts, totalPosts, categories] = await Promise.all([
      Post.find(filter)
        .populate('userId', 'name phone')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      Post.countDocuments(filter),
      Category.find({ isActive: true }).lean(),
    ]);

    const totalPages = Math.ceil(totalPosts / limit);

    res.render('index', {
      title: 'Trang Chủ - Bất Động Sản',
      posts,
      categories,
      pagination: {
        currentPage: page,
        totalPages,
        totalPosts,
        hasNext: page < totalPages,
        hasPrev: page > 1,
        nextPage: page + 1,
        prevPage: page - 1,
      },
      query: req.query,
    });
  } catch (error) {
    console.error('[v0] Error loading homepage:', error);
    res.render('index', {
      title: 'Trang Chủ - Bất Động Sản',
      posts: [],
      categories: [],
      error: 'Có lỗi xảy ra khi tải dữ liệu',
    });
  }
});

module.exports = router;
