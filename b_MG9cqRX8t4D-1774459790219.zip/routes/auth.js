const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { userValidation, handleValidationErrors } = require('../middleware/validation');
const { requireAuth, requireGuest, rateLimitAuth } = require('../middleware/auth');

// Apply rate limiting to auth attempts
const limiter = rateLimitAuth(5, 15 * 60 * 1000); // 5 attempts per 15 minutes

// Login routes
router.get('/login', requireGuest, authController.showLogin);
router.post('/login', requireGuest, limiter, userValidation.login, handleValidationErrors, authController.login);

// Register routes
router.get('/register', requireGuest, authController.showRegister);
router.post('/register', requireGuest, userValidation.register, handleValidationErrors, authController.register);

// Logout routes
router.post('/logout', requireAuth, authController.logout);
router.get('/logout', requireAuth, authController.logout);

// Profile routes
router.get('/profile', requireAuth, authController.showProfile);
router.post('/profile', requireAuth, userValidation.updateProfile, handleValidationErrors, authController.updateProfile);

// Password change route
router.post('/change-password', requireAuth, authController.changePassword);

module.exports = router;
