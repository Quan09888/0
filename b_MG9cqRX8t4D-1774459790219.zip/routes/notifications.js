const express = require("express");
const router = express.Router();
const { requireAuth } = require("../middleware/auth");
const { History } = require("../models");

// Get user notifications
router.get("/", requireAuth, async (req, res) => {
  try {
    // Get notifications from History model
    const notifications = await History.find()
      .sort({ createdAt: -1 })
      .limit(20)
      .populate("postId", "title slug")
      .populate("userId", "name");

    res.render("notifications", {
      title: "Thông báo",
      notifications: notifications || [],
    });
  } catch (error) {
    console.error("Error fetching notifications:", error);
    res.render("notifications", {
      title: "Thông báo",
      notifications: [],
      error: "Lỗi khi tải thông báo"
    });
  }
});

// Mark notification as read
router.post("/:id/read", requireAuth, async (req, res) => {
  try {
    const notification = await History.findById(req.params.id);
    if (notification) {
      await notification.markAsRead(req.user._id);
    }
    res.json({ success: true, message: "Đã đánh dấu đã đọc" });
  } catch (error) {
    console.error("Error marking notification as read:", error);
    res.status(500).json({ success: false, message: "Lỗi" });
  }
});

// Get unread count
router.get("/unread-count", requireAuth, async (req, res) => {
  try {
    const count = await History.getUnreadCount(req.user._id);
    res.json({ success: true, count });
  } catch (error) {
    console.error("Error getting unread count:", error);
    res.status(500).json({ success: false, count: 0 });
  }
});

module.exports = router;
