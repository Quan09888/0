# Deployment Guide - Real Estate Rental Platform

## Pre-Deployment Checklist

### 1. Environment Configuration
- Copy `.env.example` to `.env`
- Update all environment variables for production:
  - Change `NODE_ENV` to `production`
  - Use strong `SESSION_SECRET`
  - Configure MongoDB connection with authentication
  - Set secure CORS origins
  - Configure SMTP for email notifications

### 2. Security Requirements
- Ensure HTTPS is enabled
- Set secure cookies flag to true (done automatically in production)
- Configure rate limiting
- Enable CSRF protection
- Set Content Security Policy headers (helmet is configured)

### 3. Database Setup
```bash
# Create MongoDB database
mongosh
> use bat_dong_san

# Create indexes
> db.posts.createIndex({ title: "text", description: "text", address: "text" })
> db.posts.createIndex({ userId: 1 })
> db.posts.createIndex({ type: 1, category: 1, isApproved: 1, isActive: 1 })
> db.users.createIndex({ email: 1 }, { unique: true })
```

### 4. Dependencies Installation
```bash
npm install
```

### 5. File Structure Requirements
```
project/
├── public/
│   ├── css/
│   ├── js/
│   ├── uploads/        # Must be writable
│   └── images/
├── views/
│   ├── layouts/
│   ├── posts/
│   ├── admin/
│   └── ...
├── models/
├── controllers/
├── routes/
├── middleware/
├── config/
├── utils/
├── .env               # MUST create from .env.example
└── app.js
```

## Deployment Methods

### Option 1: Vercel (Recommended)
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel --prod

# Set environment variables
vercel env add MONGODB_URI
vercel env add SESSION_SECRET
# ... add other variables

# Redeploy after env setup
vercel --prod
```

**Note**: Vercel has a 10-second timeout for serverless functions. For long-running tasks, use background jobs or cron.

### Option 2: Heroku
```bash
# Install Heroku CLI
# Deploy
git push heroku main

# Set environment variables
heroku config:set NODE_ENV=production
heroku config:set SESSION_SECRET=your-secret
heroku config:set MONGODB_URI=your-mongo-uri
```

### Option 3: Self-Hosted (VPS/Dedicated Server)

#### Using PM2 (Process Manager)
```bash
# Install PM2 globally
npm install -g pm2

# Start application
pm2 start app.js --name "real-estate"

# Set auto-restart on reboot
pm2 startup
pm2 save

# Monitor
pm2 monit
pm2 logs
```

#### Using Docker
```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install --production

COPY . .

EXPOSE 3000
CMD ["node", "app.js"]
```

```bash
# Build and run
docker build -t real-estate .
docker run -p 3000:3000 --env-file .env real-estate
```

#### Using Nginx as Reverse Proxy
```nginx
server {
    listen 80;
    server_name yourdomain.com;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## Production Optimization

### 1. Enable Compression
- Gzip compression is enabled via `compression` middleware
- Configure in Nginx/Apache if available

### 2. Caching Strategy
```javascript
// Redis caching (optional enhancement)
const redis = require('redis');
const client = redis.createClient();
```

### 3. Image Optimization
- Images are automatically optimized using Sharp
- WebP format is used for better compression
- Thumbnails are generated for faster loading

### 4. Database Optimization
- Indexes are created for common queries
- Use MongoDB Atlas with auto-scaling for production
- Enable backup and replication

### 5. Monitoring & Logging
```bash
# View logs
pm2 logs real-estate

# Monitor performance
pm2 monit

# Daily log rotation
npm install pm2-logrotate -g
pm2 install pm2-logrotate
```

## SSL/HTTPS Setup

### Using Let's Encrypt (Free)
```bash
# Install Certbot
sudo apt-get install certbot python3-certbot-nginx

# Get certificate
sudo certbot certonly --nginx -d yourdomain.com

# Auto-renew
sudo systemctl enable certbot.timer
```

## Backup Strategy

### MongoDB Backup
```bash
# Manual backup
mongodump --uri="mongodb+srv://user:pass@cluster.mongodb.net/bat_dong_san" --out=./backup

# Restore
mongorestore --uri="mongodb+srv://user:pass@cluster.mongodb.net/bat_dong_san" ./backup
```

### File Backup
```bash
# Backup uploads directory
tar -czf uploads-backup.tar.gz public/uploads/

# Schedule daily backups
0 2 * * * tar -czf /backup/uploads-$(date +%Y%m%d).tar.gz /home/app/public/uploads/
```

## Performance Monitoring

### Key Metrics to Monitor
- Response time (target: < 200ms)
- Database query performance
- Memory usage (target: < 500MB)
- CPU usage (target: < 70%)
- Error rate (target: < 0.1%)

### Tools
- PM2 Plus for monitoring
- MongoDB Atlas metrics
- Google Analytics for user behavior
- New Relic or DataDog for APM

## Troubleshooting

### High Memory Usage
```bash
# Check node process memory
ps aux | grep node

# Increase heap size if needed
node --max-old-space-size=4096 app.js
```

### Database Connection Issues
- Verify MONGODB_URI is correct
- Check network access in MongoDB Atlas
- Verify IP whitelist includes server IP

### Slow Queries
- Check indexes are created
- Use `explain()` to analyze queries
- Consider adding database caching

## Post-Deployment

### 1. Verify Functionality
- Test user registration and login
- Create a test post
- Test search and filtering
- Verify admin dashboard
- Test image uploads

### 2. Monitor First 24 Hours
- Check error logs regularly
- Monitor server resources
- Verify email notifications work
- Test payment (if applicable)

### 3. Setup Alerts
```javascript
// Example: Alert on high error rate
if (errorCount > threshold) {
  sendAlert('High error rate detected');
}
```

## Rollback Procedure

```bash
# If something goes wrong
git revert <commit-hash>
npm install
pm2 restart real-estate

# Or go to previous version
pm2 startup
pm2 start previous-version/app.js
```

## Additional Resources

- MongoDB Atlas: https://www.mongodb.com/cloud/atlas
- Vercel: https://vercel.com
- PM2: https://pm2.keymetrics.io
- Nginx: https://nginx.org
- Let's Encrypt: https://letsencrypt.org
