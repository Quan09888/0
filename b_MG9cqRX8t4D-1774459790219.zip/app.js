const express = require("express");
const session = require("express-session");
const { engine } = require("express-handlebars");
const path = require("path");
const methodOverride = require("method-override");
const handlebarsHelpers = require("./config/handlebars-helpers");
const { connectDB } = require("./config/database");
const flash = require("./middleware/flash");
const { csrfProtection } = require("./middleware/csrf");
const {
  loadUser,
  secureSession,
  requireActiveAccount,
} = require("./middleware/auth");
const { sanitizeInput } = require("./middleware/validation");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

// Handlebars setup
app.engine(
  "hbs",
  engine({
    extname: ".hbs",
    defaultLayout: "main",
    layoutsDir: path.join(__dirname, "views/layouts"),
    partialsDir: path.join(__dirname, "views/partials"),
    helpers: handlebarsHelpers,
    runtimeOptions: {
      allowProtoPropertiesByDefault: true,
      allowProtoMethodsByDefault: true,
    },
  })
);
app.set("view engine", "hbs");
app.set("views", path.join(__dirname, "views"));

// Static files
app.use(express.static(path.join(__dirname, "public")));

// Body parser middleware
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(express.json({ limit: '10mb' }));

// Method override for PUT/DELETE from forms (supports both body and query string)
app.use(methodOverride('_method'));
app.use(methodOverride(function (req, res) {
  if (req.body && typeof req.body === 'object' && '_method' in req.body) {
    var method = req.body._method;
    delete req.body._method;
    return method;
  }
}));

// Session configuration
app.use(
  session({
    secret: process.env.SESSION_SECRET || "your-secret-key-here-change-in-production",
    resave: false,
    saveUninitialized: false,
    name: "sessionId", // Custom session name
    cookie: {
      secure: process.env.NODE_ENV === "production", // Use secure cookies in production
      httpOnly: true, // Prevent XSS attacks
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
      sameSite: "lax", // CSRF protection - lax for form compatibility
    },
  })
);

// Security and utility middleware
app.use(flash);
app.use(sanitizeInput);
app.use(csrfProtection);
app.use(secureSession);
app.use(requireActiveAccount);
app.use(loadUser);

// MongoDB connection
connectDB();

// Import models
const { User, Post, Category } = require("./models");

// Import routes
const authRoutes = require("./routes/auth");
const postsRoutes = require("./routes/posts");
const adminRoutes = require("./routes/admin");
const notificationsRoutes = require("./routes/notifications");

// Home route (before other routes to ensure it's not overridden)
app.get("/", async (req, res) => {
  try {
    // Get latest approved posts
    const posts = await Post.findApproved()
      .populate("userId", "name")
      .sort({ createdAt: -1 })
      .limit(6);

    // Get categories
    const categories = await Category.findActive();

    res.render("index", {
      title: "Trang chủ - Website Rao Vặt Bất Động Sản",
      user: req.session.user,
      posts,
      categories,
    });
  } catch (error) {
    console.error("Error loading homepage:", error);
    res.render("index", {
      title: "Trang chủ - Website Rao Vặt Bất Động Sản",
      user: req.session.user,
      posts: [],
      categories: [],
    });
  }
});

// My posts route
app.get(
  "/my-posts",
  require("./middleware/auth").requireAuth,
  require("./controllers/postsController").myPosts
);

// Routes
app.use("/", authRoutes);
app.use("/posts", postsRoutes);
app.use("/admin", adminRoutes);
app.use("/notifications", notificationsRoutes);

// Initialize database with seed data (only if no users exist)
app.get("/init-db", async (req, res) => {
  try {
    const userCount = await User.countDocuments();
    
    if (userCount > 0) {
      return res.json({
        success: false,
        message: "Database đã có dữ liệu. Nếu muốn reset, hãy đăng nhập admin và sử dụng chức năng Seed Database trong Admin Dashboard."
      });
    }

    // Seed data inline
    const categoriesData = [
      { name: "chung cư", description: "Căn hộ chung cư, apartment", icon: "fas fa-building", color: "#007bff", sortOrder: 1 },
      { name: "nhà riêng", description: "Nhà riêng, nhà phố", icon: "fas fa-home", color: "#28a745", sortOrder: 2 },
      { name: "đất nền", description: "Đất nền, đất thổ cư", icon: "fas fa-map", color: "#ffc107", sortOrder: 3 },
      { name: "nhà mặt phố", description: "Nhà mặt phố, mặt tiền", icon: "fas fa-store", color: "#dc3545", sortOrder: 4 },
      { name: "biệt thự", description: "Biệt thự, villa", icon: "fas fa-crown", color: "#6f42c1", sortOrder: 5 },
      { name: "shophouse", description: "Shophouse, nhà phố thương mại", icon: "fas fa-shopping-bag", color: "#fd7e14", sortOrder: 6 },
      { name: "kho xưởng", description: "Kho xưởng, nhà máy", icon: "fas fa-warehouse", color: "#6c757d", sortOrder: 7 },
      { name: "văn phòng", description: "Văn phòng, tòa nhà", icon: "fas fa-briefcase", color: "#20c997", sortOrder: 8 },
    ];

    const adminData = { name: "Admin", email: "admin@gmail.com", password: "admin123", role: "admin", phone: "0123456789", emailVerified: true };

    const usersData = [
      { name: "Nguyễn Văn An", email: "vudovn@gmail.com", password: "Vudo354@", phone: "0987654321", emailVerified: true },
      { name: "Trần Thị Bình", email: "tranthib@gmail.com", password: "123456", phone: "0987654322", emailVerified: true },
      { name: "Lê Văn Cường", email: "levanc@gmail.com", password: "123456", phone: "0987654323", emailVerified: true },
    ];

    // Create categories
    const categories = await Category.insertMany(categoriesData);
    
    // Create admin
    const admin = await User.create(adminData);
    
    // Create users
    const users = await User.insertMany(usersData);

    // Create sample posts
    const postsData = [
      { title: "Bán căn hộ chung cư 2PN tại Vinhomes Central Park", description: "Căn hộ cao cấp 2 phòng ngủ, 2 toilet, đầy đủ nội thất nhập khẩu, view sông Sài Gòn tuyệt đẹp.", price: 4500000000, area: 85, address: "208 Nguyễn Hữu Cảnh, Quận Bình Thạnh, TP.HCM", phone: "0987654321", type: "bán", category: "chung cư", images: ["/images/apartment.jpg"], userId: users[0]._id, isApproved: true, views: 156 },
      { title: "Cho thuê căn hộ studio Vinhomes Grand Park quận 9", description: "Căn hộ studio full nội thất cao cấp, máy lạnh, tủ lạnh, máy giặt.", price: 6500000, area: 32, address: "Long Thạnh Mỹ, Quận 9, TP.HCM", phone: "0987654323", type: "cho thuê", category: "chung cư", images: ["/images/apartment.jpg"], userId: users[2]._id, isApproved: true, views: 234 },
      { title: "Bán nhà riêng 3 tầng HXH Nguyễn Văn Đậu Bình Thạnh", description: "Nhà 3 tầng BTCT, 4 phòng ngủ, 3 WC, phòng khách rộng.", price: 6800000000, area: 65, address: "Hẻm 158 Nguyễn Văn Đậu, Quận Bình Thạnh, TP.HCM", phone: "0987654321", type: "bán", category: "nhà riêng", images: ["/images/sample-house.jpg"], userId: users[0]._id, isApproved: true, views: 312 },
      { title: "Bán đất nền dự án Mega City 2 Long Thành", description: "Đất nền dự án quy hoạch đồng bộ, hạ tầng hoàn thiện.", price: 1850000000, area: 100, address: "Xã Phước Thái, Huyện Long Thành, Đồng Nai", phone: "0987654323", type: "bán", category: "đất nền", images: ["/images/land.jpg"], userId: users[2]._id, isApproved: true, views: 567 },
      { title: "Bán biệt thự nghỉ dưỡng view biển Nha Trang", description: "Biệt thự view biển tuyệt đẹp, 5 phòng ngủ VIP, hồ bơi riêng.", price: 15000000000, area: 450, address: "Bãi Dài, Cam Lâm, Khánh Hòa", phone: "0987654321", type: "bán", category: "biệt thự", images: ["/images/villa.jpg"], userId: users[0]._id, isApproved: true, views: 723 },
      { title: "Cho thuê văn phòng hạng A Bitexco quận 1", description: "Văn phòng hạng A tòa Bitexco Financial Tower, tầng 28.", price: 850000, area: 100, address: "2 Hải Triều, Quận 1, TP.HCM", phone: "0987654322", type: "cho thuê", category: "văn phòng", images: ["/images/apartment.jpg"], userId: users[1]._id, isApproved: true, views: 234 },
    ];

    const posts = await Post.insertMany(postsData);

    // Update category post counts
    for (const category of categories) {
      await category.updatePostsCount();
    }

    res.json({
      success: true,
      message: "Database đã được khởi tạo thành công!",
      data: {
        admin: { email: adminData.email, password: adminData.password },
        usersCount: users.length + 1,
        categoriesCount: categories.length,
        postsCount: posts.length
      }
    });
  } catch (error) {
    console.error("Init DB error:", error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Test route to check database
app.get("/test-db", async (req, res) => {
  try {
    const userCount = await User.countDocuments();
    const postCount = await Post.countDocuments();
    const categoryCount = await Category.countDocuments();
    const approvedPosts = await Post.countDocuments({ isApproved: true });
    const pendingPosts = await Post.countDocuments({ isApproved: null });

    res.json({
      success: true,
      data: {
        users: userCount,
        posts: postCount,
        categories: categoryCount,
        approvedPosts,
        pendingPosts,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Debug session route
app.get("/debug-session", (req, res) => {
  res.json({
    session: req.session,
    sessionID: req.sessionID,
    user: req.session?.user || null,
    cookies: req.headers.cookie,
  });
});

// Error handling middleware (must be last)
const { notFound, errorHandler } = require("./middleware/errorHandler");
app.use(notFound);
app.use(errorHandler);

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server is running on http://localhost:${PORT}`);
});

module.exports = app;
