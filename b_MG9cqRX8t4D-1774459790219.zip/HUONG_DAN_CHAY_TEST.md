# Huong Dan Chay Selenium Test – Blue Group Real Estate

## Cau truc thu muc

```
selenium_tests/
├── __init__.py
├── config.py              # Cau hinh URL, tai khoan, timeout
├── conftest.py            # WebDriver fixture (ChromeDriver)
├── pages/                 # Page Object Model
│   ├── login_page.py
│   ├── signup_page.py
│   ├── search_page.py
│   ├── account_page.py
│   ├── admin_page.py
│   ├── create_post_page.py
│   └── update_post_page.py
└── tests/                 # Test cases
    ├── test_login.py       # TC_LOG_001 – TC_LOG_030  (30 TCs)
    ├── test_signup.py      # TC_REG_001 – TC_REG_030  (30 TCs)
    ├── test_search.py      # TC_SEARCH_001 – TC_SEARCH_032  (32 TCs)
    ├── test_account.py     # TC_Account_001 – TC_Account_050  (50 TCs)
    ├── test_admin.py       # TC_Admin_001 – TC_Admin_036  (36 TCs)
    ├── test_create_post.py # TC_Post_001 – TC_Post_021  (21 TCs)
    └── test_update_post.py # TC_PostUpDate_001 – TC_PostUpDate_011  (11 TCs)
```

---

## Yeu cau he thong

| Phan mem | Phien ban |
|----------|-----------|
| Python | >= 3.9 |
| Google Chrome | Moi nhat |
| pip | >= 23 |

---

## Cai dat moi truong

```bash
# 1. Tao virtual environment
python -m venv venv
source venv/bin/activate        # Linux / Mac
venv\Scripts\activate           # Windows

# 2. Cai dat thu vien
pip install selenium webdriver-manager pytest pytest-html python-dotenv

# 3. (Tuy chon) Tao file .env o thu muc goc de ghi de cau hinh
cp .env.example .env
```

### Noi dung file .env (vi du)

```env
BASE_URL=http://localhost:3000
HEADLESS=False
IMPLICIT_WAIT=10
PAGE_LOAD_TIMEOUT=15
TEST_USER_EMAIL=user@test.com
TEST_USER_PASSWORD=123456
TEST_ADMIN_EMAIL=admin@test.com
TEST_ADMIN_PASSWORD=admin123
```

---

## Chay toan bo test

```bash
# Chay tat ca 210 test cases
pytest selenium_tests/ -v

# Chay kem bao cao HTML
pytest selenium_tests/ -v --html=reports/report.html --self-contained-html

# Chay che do headless (khong mo trinh duyet)
HEADLESS=True pytest selenium_tests/ -v
```

---

## Chay tung module test case

### 1. Dang nhap – TC_LOG_001 den TC_LOG_030

```bash
pytest selenium_tests/tests/test_login.py -v
```

Chay 1 test case cu the (vi du TC_LOG_001):

```bash
pytest selenium_tests/tests/test_login.py::TestLogin::test_TC_LOG_001_successful_user_login -v
```

Dieu kien truoc:
- Server dang chay tai BASE_URL
- Tai khoan `user@test.com / 123456` ton tai va isActive=true
- Tai khoan `admin@test.com / admin123` co role=admin

---

### 2. Dang ky – TC_REG_001 den TC_REG_030

```bash
pytest selenium_tests/tests/test_signup.py -v
```

Vi du chay 1 test:

```bash
pytest selenium_tests/tests/test_signup.py::TestSignup::test_TC_REG_001_success_full_info -v
```

Dieu kien truoc:
- Email test (nva_001@test.com, tranb_002@test.com, ...) chua ton tai trong DB
- Xoa cac email test sau moi lan chay de tranh loi "email da ton tai"

---

### 3. Tim kiem va Loc – TC_SEARCH_001 den TC_SEARCH_032

```bash
pytest selenium_tests/tests/test_search.py -v
```

Chay chi test co trang thai Pass:

```bash
pytest selenium_tests/tests/test_search.py -v -k "not xfail"
```

Dieu kien truoc:
- Co it nhat 1 tin dang khop tu khoa "Can ho Vinhome" trong DB
- Trang danh sach BDS co URL /bat-dong-san

Test co trang thai Fail (da danh dau xfail – chay nhung khong lam fail build):
- TC_SEARCH_003: Tim kiem rong – he thong khong canh bao
- TC_SEARCH_004: Tim kiem khoang trang – hien ket qua thay vi canh bao
- TC_SEARCH_007/008: Khong co goi y tu dong
- TC_SEARCH_011: Sai chinh ta khong tra ket qua tuong tu
- TC_SEARCH_014–017: Khong co option Loai BDS (Can ho, Chung cu, Nha rieng, Biet thu)
- TC_SEARCH_027/028: Khong canh bao khi nhap tam gia nguoc / am

---

### 4. Tai khoan / Ho so – TC_Account_001 den TC_Account_050

```bash
pytest selenium_tests/tests/test_account.py -v
```

Vi du chay nhom test doi mat khau:

```bash
pytest selenium_tests/tests/test_account.py -v -k "password"
```

Dieu kien truoc:
- Dang nhap bang tai khoan user hop le truoc khi chay
- Cac test OTP (TC_Account_005, 007, 008, 016, 017) yeu cau SIM/email nhan OTP that

Test co trang thai Fail (xfail):
- TC_Account_005: OTP gui cham
- TC_Account_013: Luu dia chi bao loi server
- TC_Account_020: Xoa phien dang nhap khac that bai

---

### 5. Admin Panel – TC_Admin_001 den TC_Admin_036

```bash
pytest selenium_tests/tests/test_admin.py -v
```

Chay nhom quan ly tin dang:

```bash
pytest selenium_tests/tests/test_admin.py -v -k "Post"
```

Chay nhom quan ly nguoi dung:

```bash
pytest selenium_tests/tests/test_admin.py -v -k "User"
```

Chay nhom quan ly danh muc:

```bash
pytest selenium_tests/tests/test_admin.py -v -k "Cat"
```

Dieu kien truoc:
- Tai khoan admin hop le (admin@test.com / admin123)
- Co san du lieu: tin dang "Ban dat nen du an moi tai Da Nang", user "Nguyen Van A" (vudovn@gmail.com), danh muc "Chung cu"
- Khoi phuc du lieu trong DB sau moi lan chay xoa/vo hieu hoa

---

### 6. Dang tin – TC_Post_001 den TC_Post_021

```bash
pytest selenium_tests/tests/test_create_post.py -v
```

Chay 1 test cu the:

```bash
pytest selenium_tests/tests/test_create_post.py::TestCreatePost::test_TC_Post_001_create_post_success -v
```

Dieu kien truoc:
- User da dang nhap (user@test.com / 123456)
- Thu muc /tmp ton tai de tao file anh test tam thoi (Linux/Mac)
  - Windows: chinh duong dan trong ham `_dummy_image_paths()` thanh `C:\Temp`

---

### 7. Cap nhat tin dang – TC_PostUpDate_001 den TC_PostUpDate_011

```bash
pytest selenium_tests/tests/test_update_post.py -v
```

Dieu kien truoc:
- User da co it nhat 1 tin dang duoc duyet (status=approved) trong he thong
- URL cap nhat tin co dang: /posts/{id}/edit
- Cac test lien quan den anh yeu cau tin dang co 2, 3, hoac 4 anh hien tai

Test co trang thai Fail (xfail):
- TC_PostUpDate_005: SĐT khong hop le duoc chap nhan thanh cong (bug validation)
- TC_PostUpDate_011: Nut Huy khong hien dialog xac nhan, chuyen ve cho duyet ngay

---

## Chay theo Priority

```bash
# Chi chay test Priority = High va Critical
pytest selenium_tests/ -v -m "high or critical"
```

Luu y: can them markers vao pytest.ini neu muon loc theo priority:

```ini
# pytest.ini
[pytest]
markers =
    critical: Critical priority tests
    high: High priority tests
    medium: Medium priority tests
    low: Low priority tests
```

---

## Xem ket qua

```bash
# Chay kem bao cao HTML chi tiet
pytest selenium_tests/ -v --html=reports/report.html --self-contained-html

# Mo bao cao trong trinh duyet
open reports/report.html     # Mac
start reports/report.html    # Windows
```

---

## Ket qua xfail (Bug da ghi nhan)

Cac test duoi day duoc danh dau `@pytest.mark.xfail` – chung se chay nhung KHONG lam fail toan bo build. Day la cac bug da xac nhan can xu ly:

| Test Case ID | Mo ta Bug |
|---|---|
| TC_LOG_021 | Margin Submit va Checkbox "Ghi nho" bi dinh sat tren Tablet |
| TC_LOG_027 | Chua co co che khoa IP / Captcha chong Brute Force |
| TC_REG_011 | DB luu email nguyen dinh dang in hoa thay vi toLowerCase() |
| TC_REG_029 | Form bi lech trai ~10px tren mobile |
| TC_SEARCH_003 | Tim kiem rong khong canh bao, tra ve "khong ket qua" |
| TC_SEARCH_004 | Tim kiem khoang trang hien danh sach BDS thay vi canh bao |
| TC_SEARCH_007 | Khong hien goi y tu dong khi nhap tu khoa |
| TC_SEARCH_008 | Khong the chon goi y tu dong |
| TC_SEARCH_011 | Sai chinh ta khong tra ket qua tuong tu |
| TC_SEARCH_014 | Khong co option Loai BDS = Can ho |
| TC_SEARCH_015 | Khong co option Loai BDS = Chung cu |
| TC_SEARCH_016 | Khong co option Loai BDS = Nha rieng |
| TC_SEARCH_017 | Khong co option Loai BDS = Biet thu |
| TC_SEARCH_027 | Tam gia nguoc (tu > den) khong canh bao |
| TC_SEARCH_028 | Gia am khong bi tu choi |
| TC_Account_005 | OTP gui cham, can gui lai 2 lan |
| TC_Account_013 | Luu dia chi bao loi server |
| TC_Account_020 | Xoa phien dang nhap khac: "Thao tac that bai" |
| TC_PostUpDate_005 | SĐT khong hop le duoc chap nhan khi cap nhat tin |
| TC_PostUpDate_011 | Nut Huy khong hien dialog xac nhan truoc khi roi trang |
