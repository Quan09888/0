# Testing Guide - Real Estate Rental Platform

## Test Coverage Areas

### 1. Authentication Flow Tests

#### Registration Test
- [ ] User can register with valid data
- [ ] Duplicate email is rejected
- [ ] Password validation enforced (min 6 chars, 1 uppercase, 1 lowercase, 1 number)
- [ ] Weak password is rejected
- [ ] Phone number validation (10-11 digits)
- [ ] Session is created after registration

#### Login Test
- [ ] User can login with correct credentials
- [ ] Login fails with incorrect email
- [ ] Login fails with incorrect password
- [ ] Rate limiting on failed attempts (5 attempts/15 minutes)
- [ ] Session expires after 24 hours

#### Logout Test
- [ ] User can logout
- [ ] Session is destroyed
- [ ] User is redirected to home page
- [ ] User cannot access protected pages after logout

### 2. Post Management Tests

#### Create Post Test
- [ ] Authenticated user can create post
- [ ] Unauthenticated user cannot create post
- [ ] Post requires all mandatory fields
- [ ] Title validation (10-200 characters)
- [ ] Description validation (50-2000 characters)
- [ ] Price validation (0 - 999,999,999,999)
- [ ] Area validation (1 - 10,000 m²)
- [ ] Images are properly processed
- [ ] Post status is "pending" after creation
- [ ] User receives success notification

#### Read Post Test
- [ ] User can view published posts
- [ ] User can view post details
- [ ] Post views counter increments
- [ ] Related posts are displayed
- [ ] User cannot view unapproved posts (except owner)
- [ ] 404 error for non-existent posts

#### Update Post Test
- [ ] Only owner can edit post
- [ ] Admin can edit any post
- [ ] Validation rules apply to updates
- [ ] Updated date changes
- [ ] Status remains pending after edit

#### Delete Post Test
- [ ] Only owner can delete post
- [ ] Admin can delete any post
- [ ] Post is removed from database
- [ ] Related images are deleted
- [ ] User receives success notification

### 3. Search & Filter Tests

#### Search Test
- [ ] Text search works by title
- [ ] Text search works by description
- [ ] Text search works by address
- [ ] Results are relevant
- [ ] No results shows appropriate message

#### Filter Test
- [ ] Filter by type (bán/cho thuê)
- [ ] Filter by category
- [ ] Filter by price range
- [ ] Filter by area range
- [ ] Combined filters work correctly
- [ ] Filters show result count

#### Sort Test
- [ ] Sort by newest first
- [ ] Sort by oldest first
- [ ] Sort by price ascending
- [ ] Sort by price descending
- [ ] Sort by views
- [ ] Sort by featured

### 4. Admin Panel Tests

#### Dashboard Test
- [ ] Admin can access dashboard
- [ ] Statistics display correctly (total posts, users, etc.)
- [ ] Recent posts are listed
- [ ] Recent users are listed

#### Post Moderation Test
- [ ] Admin can view all posts
- [ ] Admin can approve pending posts
- [ ] Admin can reject posts
- [ ] Admin can delete posts
- [ ] Admin can feature posts
- [ ] Notifications sent to users

#### User Management Test
- [ ] Admin can view all users
- [ ] Admin can deactivate users
- [ ] Admin can reactivate users
- [ ] Admin can reset user passwords

#### Category Management Test
- [ ] Admin can create categories
- [ ] Admin can edit categories
- [ ] Admin can delete categories
- [ ] Categories are used in filters

### 5. Security Tests

#### CSRF Protection
- [ ] CSRF token is generated for forms
- [ ] POST requests without token are rejected
- [ ] Token validation works correctly

#### Input Validation
- [ ] HTML injection is prevented
- [ ] Script injection is prevented
- [ ] SQL injection is prevented
- [ ] XSS attacks are prevented

#### Password Security
- [ ] Passwords are hashed with bcrypt
- [ ] Passwords are not stored in plain text
- [ ] Passwords cannot be viewed

#### Session Security
- [ ] Cookies are httpOnly
- [ ] Cookies are secure in production
- [ ] Sessions expire properly
- [ ] Session hijacking is prevented

### 6. UI/UX Tests

#### Responsive Design
- [ ] Mobile view (< 576px)
- [ ] Tablet view (576px - 992px)
- [ ] Desktop view (> 992px)
- [ ] Navigation works on all sizes
- [ ] Forms are readable on mobile

#### Error Handling
- [ ] Error messages are clear
- [ ] 404 page displays correctly
- [ ] 500 page displays correctly
- [ ] Validation errors are shown
- [ ] User can recover from errors

#### Performance
- [ ] Page loads in < 3 seconds
- [ ] Images are optimized
- [ ] CSS/JS are minified
- [ ] No console errors
- [ ] No memory leaks

### 7. API Tests

#### Endpoint Availability
- [ ] GET /posts - Get all posts
- [ ] GET /posts/:id - Get post detail
- [ ] POST /posts - Create post
- [ ] PUT /posts/:id - Update post
- [ ] DELETE /posts/:id - Delete post
- [ ] GET /admin/* - Admin endpoints

#### Response Format
- [ ] All responses have proper status codes
- [ ] Error responses include error messages
- [ ] Success responses include data
- [ ] Pagination works correctly

## Manual Testing Checklist

### Before Each Release
- [ ] All authentication flows work
- [ ] Post creation/editing works
- [ ] Search and filters work
- [ ] Admin panel is functional
- [ ] No console errors
- [ ] No broken images
- [ ] Links work correctly
- [ ] Forms validate properly
- [ ] Mobile responsiveness tested
- [ ] Page load times acceptable

### Critical Path Test
```
1. Register new account
   ↓
2. Verify email (if enabled)
   ↓
3. Login with credentials
   ↓
4. Create a post with images
   ↓
5. Search for the post
   ↓
6. Edit the post
   ↓
7. View post details
   ↓
8. Logout
   ↓
9. Login as admin
   ↓
10. Approve pending posts
   ↓
11. View dashboard statistics
```

## Automated Testing Setup (Recommended)

### Jest Configuration
```bash
npm install jest supertest --save-dev
```

### Sample Test
```javascript
const request = require('supertest');
const app = require('../app');

describe('Authentication', () => {
  test('User can register', async () => {
    const res = await request(app)
      .post('/register')
      .send({
        name: 'Test User',
        email: 'test@example.com',
        password: 'Test1234',
        phone: '09123456789'
      });

    expect(res.statusCode).toBe(302);
    expect(res.headers.location).toContain('/');
  });
});
```

## Performance Testing

### Load Testing with Artillery
```bash
npm install -g artillery
artillery quick --count 100 --num 1000 http://localhost:3000
```

### Memory Profiling
```javascript
// In app.js
const monitor = new PerformanceMonitor();
setInterval(() => {
  console.log('Memory:', monitor.recordMemoryUsage());
}, 5000);
```

## Browser Testing Tools

- **Chrome DevTools**: Network, Performance, Console
- **Lighthouse**: Performance audit
- **WebAIM**: Accessibility testing
- **BrowserStack**: Cross-browser testing

## Test Data Seeding

```bash
npm run seed
```

This creates:
- 10 test users
- 50 test posts across categories
- 5 categories
- Admin user (email: admin@test.com, password: Admin123)

## Continuous Integration

### GitHub Actions Example
```yaml
name: Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
      - run: npm install
      - run: npm test
      - run: npm run lint
```

## Known Issues & Limitations

- [ ] Payment integration not yet implemented
- [ ] Email notifications (SMTP) needs configuration
- [ ] Two-factor authentication not implemented
- [ ] Real-time notifications use polling instead of WebSockets
- [ ] Image compression may take time on slow connections

## Testing in Production

- Monitor error logs regularly
- Check performance metrics
- Verify backups are working
- Test disaster recovery plan
- Monitor server resources
- Track user behavior with analytics

## Reporting Issues

When testing, please report:
1. Steps to reproduce
2. Expected behavior
3. Actual behavior
4. Browser/device information
5. Screenshots/console errors
6. Severity level (critical/high/medium/low)
