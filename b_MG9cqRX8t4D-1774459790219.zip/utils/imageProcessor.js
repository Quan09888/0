const sharp = require('sharp');
const path = require('path');
const fs = require('fs').promises;

const IMAGE_SIZES = {
  thumbnail: { width: 200, height: 200, quality: 80 },
  medium: { width: 500, height: 400, quality: 85 },
  large: { width: 1200, height: 800, quality: 90 },
  hero: { width: 1920, height: 600, quality: 85 },
};

const IMAGE_UPLOAD_DIR = path.join(__dirname, '../public/uploads');
const THUMBNAIL_DIR = path.join(IMAGE_UPLOAD_DIR, 'thumbnails');

const createDirectories = async () => {
  try {
    await fs.mkdir(IMAGE_UPLOAD_DIR, { recursive: true });
    await fs.mkdir(THUMBNAIL_DIR, { recursive: true });
  } catch (error) {
    console.error('Error creating directories:', error);
  }
};

const processImage = async (inputPath, filename, sizes = ['thumbnail', 'medium']) => {
  try {
    await createDirectories();

    const results = {};
    const name = filename.replace(/\.[^/.]+$/, '');

    // Process each size
    for (const sizeName of sizes) {
      if (!IMAGE_SIZES[sizeName]) continue;

      const size = IMAGE_SIZES[sizeName];
      const outputFilename = `${name}-${sizeName}.webp`;
      const outputPath = path.join(IMAGE_UPLOAD_DIR, outputFilename);

      await sharp(inputPath)
        .resize(size.width, size.height, {
          fit: 'cover',
          position: 'center',
        })
        .webp({ quality: size.quality })
        .toFile(outputPath);

      results[sizeName] = `/uploads/${outputFilename}`;
    }

    // Also keep original as webp
    const originalPath = path.join(IMAGE_UPLOAD_DIR, `${name}.webp`);
    await sharp(inputPath)
      .webp({ quality: 90 })
      .toFile(originalPath);

    results.original = `/uploads/${name}.webp`;

    return results;
  } catch (error) {
    console.error('Image processing error:', error);
    throw error;
  }
};

const deleteImage = async (filename) => {
  try {
    const name = filename.replace(/\.[^/.]+$/, '');
    const patterns = [`${name}*.webp`];

    for (const pattern of patterns) {
      const files = await fs.readdir(IMAGE_UPLOAD_DIR);
      const matching = files.filter(f => f.startsWith(name));
      
      for (const file of matching) {
        await fs.unlink(path.join(IMAGE_UPLOAD_DIR, file));
      }
    }
  } catch (error) {
    console.error('Error deleting image:', error);
  }
};

const optimizeImage = async (buffer, options = {}) => {
  try {
    const {
      width = 1200,
      height = 800,
      quality = 85,
      format = 'webp',
    } = options;

    let pipeline = sharp(buffer)
      .resize(width, height, {
        fit: 'cover',
        position: 'center',
        withoutEnlargement: true,
      });

    if (format === 'webp') {
      pipeline = pipeline.webp({ quality });
    } else if (format === 'jpeg') {
      pipeline = pipeline.jpeg({ quality });
    } else if (format === 'png') {
      pipeline = pipeline.png({ quality });
    }

    return await pipeline.toBuffer();
  } catch (error) {
    console.error('Image optimization error:', error);
    throw error;
  }
};

module.exports = {
  processImage,
  deleteImage,
  optimizeImage,
  IMAGE_SIZES,
  createDirectories,
};
