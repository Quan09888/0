const cache = new Map();

class CacheManager {
  constructor(ttl = 60000) {
    this.ttl = ttl;
    this.cache = new Map();
  }

  set(key, value, ttl = this.ttl) {
    const expiredAt = Date.now() + ttl;
    this.cache.set(key, { value, expiredAt });
    
    // Auto cleanup after TTL
    setTimeout(() => {
      this.cache.delete(key);
    }, ttl);
  }

  get(key) {
    const item = this.cache.get(key);
    
    if (!item) return null;
    
    if (Date.now() > item.expiredAt) {
      this.cache.delete(key);
      return null;
    }
    
    return item.value;
  }

  has(key) {
    return this.get(key) !== null;
  }

  delete(key) {
    this.cache.delete(key);
  }

  clear() {
    this.cache.clear();
  }

  flush(pattern) {
    for (const [key] of this.cache) {
      if (key.match(pattern)) {
        this.cache.delete(key);
      }
    }
  }
}

// Export singleton instances for different cache types
const cacheManager = {
  posts: new CacheManager(60000),      // 1 minute
  categories: new CacheManager(300000),  // 5 minutes
  users: new CacheManager(180000),      // 3 minutes
  search: new CacheManager(120000),     // 2 minutes
};

// Cache middleware for GET requests
const cacheMiddleware = (cacheName = 'posts') => {
  return (req, res, next) => {
    if (req.method !== 'GET') {
      return next();
    }

    const key = req.originalUrl || req.url;
    const cached = cacheManager[cacheName]?.get(key);

    if (cached) {
      console.log(`[Cache Hit] ${key}`);
      return res.json(cached);
    }

    // Store original json method
    const originalJson = res.json;

    // Override json method to cache response
    res.json = function(data) {
      cacheManager[cacheName]?.set(key, data);
      originalJson.call(this, data);
    };

    next();
  };
};

module.exports = {
  CacheManager,
  cacheManager,
  cacheMiddleware,
};
