const sendResponse = (res, statusCode, success, message, data = null) => {
  res.status(statusCode).json({
    success,
    message,
    ...(data && { data }),
  });
};

const sendError = (res, statusCode, message, errors = null) => {
  res.status(statusCode).json({
    success: false,
    message,
    ...(errors && { errors }),
  });
};

const asyncHandler = (fn) => {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};

const getPaginationParams = (query) => {
  const page = Math.max(1, parseInt(query.page) || 1);
  const limit = Math.min(100, parseInt(query.limit) || 10);
  const skip = (page - 1) * limit;

  return { page, limit, skip };
};

const buildPaginationMeta = (page, limit, total) => {
  const totalPages = Math.ceil(total / limit);

  return {
    page,
    limit,
    total,
    totalPages,
    hasNextPage: page < totalPages,
    hasPrevPage: page > 1,
  };
};

const buildFilterQuery = (filters) => {
  const query = {};

  if (filters.type) {
    query.type = filters.type;
  }

  if (filters.category) {
    query.category = filters.category;
  }

  if (filters.priceMin || filters.priceMax) {
    query.price = {};
    if (filters.priceMin) query.price.$gte = parseInt(filters.priceMin);
    if (filters.priceMax) query.price.$lte = parseInt(filters.priceMax);
  }

  if (filters.areaMin || filters.areaMax) {
    query.area = {};
    if (filters.areaMin) query.area.$gte = parseInt(filters.areaMin);
    if (filters.areaMax) query.area.$lte = parseInt(filters.areaMax);
  }

  if (filters.userId) {
    query.userId = filters.userId;
  }

  if (filters.isApproved !== undefined) {
    query.isApproved = filters.isApproved === 'true' ? true : filters.isApproved === 'false' ? false : null;
  }

  if (filters.isActive !== undefined) {
    query.isActive = filters.isActive === 'true';
  }

  // Status filter
  if (filters.status === 'pending') {
    query.isApproved = null;
  } else if (filters.status === 'approved') {
    query.isApproved = true;
  } else if (filters.status === 'rejected') {
    query.isApproved = false;
  }

  return query;
};

const buildSortQuery = (sortBy) => {
  const sortMap = {
    'newest': { createdAt: -1 },
    'oldest': { createdAt: 1 },
    'price-asc': { price: 1 },
    'price-desc': { price: -1 },
    'area-asc': { area: 1 },
    'area-desc': { area: -1 },
    'views': { views: -1 },
    'featured': { isFeatured: -1, createdAt: -1 },
  };

  return sortMap[sortBy] || { createdAt: -1 };
};

const buildSearchQuery = (searchText) => {
  if (!searchText) return {};

  return {
    $text: { $search: searchText },
  };
};

const formatPostResponse = (post) => {
  return {
    _id: post._id,
    title: post.title,
    description: post.description,
    type: post.type,
    category: post.category,
    price: post.price,
    area: post.area,
    address: post.address,
    phone: post.phone,
    images: post.images,
    views: post.views,
    isFeatured: post.isFeatured,
    isApproved: post.isApproved,
    isActive: post.isActive,
    userId: post.userId,
    createdAt: post.createdAt,
    updatedAt: post.updatedAt,
    expiresAt: post.expiresAt,
    formattedPrice: post.formattedPrice,
    pricePerSqm: post.pricePerSqm,
    statusText: post.statusText,
    timeAgo: post.timeAgo,
  };
};

const calculateStats = (posts) => {
  if (!Array.isArray(posts) || posts.length === 0) {
    return {
      totalListings: 0,
      averagePrice: 0,
      averageArea: 0,
      priceRange: { min: 0, max: 0 },
      areaRange: { min: 0, max: 0 },
    };
  }

  const prices = posts.map(p => p.price).filter(p => p > 0);
  const areas = posts.map(p => p.area).filter(a => a > 0);

  return {
    totalListings: posts.length,
    averagePrice: prices.length > 0 ? Math.round(prices.reduce((a, b) => a + b, 0) / prices.length) : 0,
    averageArea: areas.length > 0 ? Math.round(areas.reduce((a, b) => a + b, 0) / areas.length * 10) / 10 : 0,
    priceRange: {
      min: prices.length > 0 ? Math.min(...prices) : 0,
      max: prices.length > 0 ? Math.max(...prices) : 0,
    },
    areaRange: {
      min: areas.length > 0 ? Math.min(...areas) : 0,
      max: areas.length > 0 ? Math.max(...areas) : 0,
    },
  };
};

module.exports = {
  sendResponse,
  sendError,
  asyncHandler,
  getPaginationParams,
  buildPaginationMeta,
  buildFilterQuery,
  buildSortQuery,
  buildSearchQuery,
  formatPostResponse,
  calculateStats,
};
