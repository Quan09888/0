const validateEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePassword = (password) => {
  // At least 6 chars, 1 uppercase, 1 lowercase, 1 number
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{6,}$/;
  return passwordRegex.test(password);
};

const validatePhoneNumber = (phone) => {
  const phoneRegex = /^[0-9]{10,11}$/;
  return phoneRegex.test(phone);
};

const validateVietnamPhoneNumber = (phone) => {
  // Vietnamese phone number format
  const vietnamPhoneRegex = /^(\+84|0)[1-9]\d{8,9}$/;
  return vietnamPhoneRegex.test(phone);
};

const validateURL = (url) => {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
};

const validatePrice = (price) => {
  const num = Number(price);
  return !isNaN(num) && num >= 0 && num <= 999999999999;
};

const validateArea = (area) => {
  const num = Number(area);
  return !isNaN(num) && num > 0 && num <= 10000;
};

const sanitizeString = (str) => {
  if (typeof str !== 'string') return '';
  
  return str
    .trim()
    .replace(/[<>]/g, '') // Remove potential HTML tags
    .replace(/javascript:/gi, '') // Remove javascript protocol
    .slice(0, 5000); // Limit length
};

const sanitizeHTML = (html) => {
  // Basic sanitization - remove script tags and event handlers
  return html
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/on\w+\s*=\s*"[^"]*"/gi, '');
};

const validatePostData = (data) => {
  const errors = [];

  if (!data.title || data.title.length < 10) {
    errors.push('Tiêu đề phải có ít nhất 10 ký tự');
  }

  if (!data.description || data.description.length < 50) {
    errors.push('Mô tả phải có ít nhất 50 ký tự');
  }

  if (!validatePrice(data.price)) {
    errors.push('Giá không hợp lệ');
  }

  if (!validateArea(data.area)) {
    errors.push('Diện tích không hợp lệ');
  }

  if (!data.address || data.address.length < 10) {
    errors.push('Địa chỉ phải có ít nhất 10 ký tự');
  }

  if (!validateVietnamPhoneNumber(data.phone)) {
    errors.push('Số điện thoại không hợp lệ (định dạng Việt Nam)');
  }

  if (!['bán', 'cho thuê'].includes(data.type)) {
    errors.push('Loại hình không hợp lệ');
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
};

const validateUserData = (data) => {
  const errors = [];

  if (!data.name || data.name.length < 2) {
    errors.push('Tên phải có ít nhất 2 ký tự');
  }

  if (!validateEmail(data.email)) {
    errors.push('Email không hợp lệ');
  }

  if (!validatePassword(data.password)) {
    errors.push('Mật khẩu phải có ít nhất 6 ký tự, bao gồm chữ hoa, chữ thường và số');
  }

  if (data.phone && !validateVietnamPhoneNumber(data.phone)) {
    errors.push('Số điện thoại không hợp lệ');
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
};

const rateLimitKey = (identifier, action) => {
  return `ratelimit:${action}:${identifier}`;
};

const generateSlug = (text) => {
  return text
    .toLowerCase()
    .trim()
    .replace(/[àáạảãâầấậẩẫăằắặẳẵ]/g, 'a')
    .replace(/[èéẹẻẽêềếệểễ]/g, 'e')
    .replace(/[ìíịỉĩ]/g, 'i')
    .replace(/[òóọỏõôồốộổỗơờớợởỡ]/g, 'o')
    .replace(/[ùúụủũưừứựửữ]/g, 'u')
    .replace(/[ỳýỵỷỹ]/g, 'y')
    .replace(/đ/g, 'd')
    .replace(/[^a-z0-9 -]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
};

module.exports = {
  validateEmail,
  validatePassword,
  validatePhoneNumber,
  validateVietnamPhoneNumber,
  validateURL,
  validatePrice,
  validateArea,
  sanitizeString,
  sanitizeHTML,
  validatePostData,
  validateUserData,
  rateLimitKey,
  generateSlug,
};
