const metrics = {
  requests: {
    total: 0,
    failed: 0,
    avgResponseTime: 0,
  },
  database: {
    queries: 0,
    slowQueries: 0,
    avgQueryTime: 0,
  },
  memory: {
    peakUsage: 0,
    currentUsage: 0,
  },
};

class PerformanceMonitor {
  constructor() {
    this.metrics = new Map();
    this.slowQueryThreshold = 100; // ms
    this.startTime = Date.now();
  }

  recordRequest(duration, status) {
    metrics.requests.total++;
    
    if (status >= 400) {
      metrics.requests.failed++;
    }

    // Update average response time
    const prevAvg = metrics.requests.avgResponseTime;
    metrics.requests.avgResponseTime = 
      (prevAvg * (metrics.requests.total - 1) + duration) / metrics.requests.total;

    return {
      duration,
      status,
      avgResponseTime: metrics.requests.avgResponseTime,
    };
  }

  recordDatabaseQuery(duration, query = '') {
    metrics.database.queries++;

    if (duration > this.slowQueryThreshold) {
      metrics.database.slowQueries++;
      console.warn(`[SLOW QUERY] ${duration}ms - ${query}`);
    }

    // Update average query time
    const prevAvg = metrics.database.avgQueryTime;
    metrics.database.avgQueryTime = 
      (prevAvg * (metrics.database.queries - 1) + duration) / metrics.database.queries;

    return {
      duration,
      isSlowQuery: duration > this.slowQueryThreshold,
      avgQueryTime: metrics.database.avgQueryTime,
    };
  }

  recordMemoryUsage() {
    const usage = process.memoryUsage();
    metrics.memory.currentUsage = Math.round(usage.heapUsed / 1024 / 1024); // MB
    metrics.memory.peakUsage = Math.max(metrics.memory.peakUsage, metrics.memory.currentUsage);

    return {
      heapUsed: metrics.memory.currentUsage,
      heapTotal: Math.round(usage.heapTotal / 1024 / 1024),
      rss: Math.round(usage.rss / 1024 / 1024),
      peakUsage: metrics.memory.peakUsage,
    };
  }

  getMetrics() {
    return {
      ...metrics,
      uptime: Math.floor((Date.now() - this.startTime) / 1000),
      memory: this.recordMemoryUsage(),
    };
  }

  resetMetrics() {
    metrics.requests = { total: 0, failed: 0, avgResponseTime: 0 };
    metrics.database = { queries: 0, slowQueries: 0, avgQueryTime: 0 };
  }
}

// Middleware to monitor request performance
const performanceMiddleware = (monitor) => {
  return (req, res, next) => {
    const startTime = Date.now();

    // Override res.json to track response
    const originalJson = res.json;
    res.json = function(data) {
      const duration = Date.now() - startTime;
      monitor.recordRequest(duration, res.statusCode);

      if (duration > 1000) {
        console.warn(`[SLOW REQUEST] ${duration}ms - ${req.method} ${req.path}`);
      }

      originalJson.call(this, data);
    };

    next();
  };
};

module.exports = {
  PerformanceMonitor,
  performanceMiddleware,
  metrics,
};
