// Admin Panel JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Confirm delete actions
    const deleteButtons = document.querySelectorAll('[data-confirm-delete]');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Bạn có chắc chắn muốn xóa?')) {
                e.preventDefault();
            }
        });
    });

    // Search form auto-submit on select change
    const filterSelects = document.querySelectorAll('form.filter-form select');
    filterSelects.forEach(select => {
        select.addEventListener('change', function() {
            this.closest('form').submit();
        });
    });
});

// Approve post via AJAX
async function approvePost(postId, buttonElement) {
    try {
        const response = await fetch(`/admin/posts/${postId}/approve`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            credentials: 'same-origin'
        });

        const data = await response.json();
        
        if (data.success) {
            // Update UI
            const row = buttonElement.closest('tr');
            const statusCell = row.querySelector('td:nth-child(6)');
            statusCell.innerHTML = '<span class="badge bg-success">Duyệt</span>';
            
            // Remove approve/reject buttons
            const actionButtons = row.querySelectorAll('form[action*="approve"], form[action*="reject"]');
            actionButtons.forEach(btn => btn.remove());
            
            showNotification('success', data.message);
        } else {
            showNotification('error', data.message);
        }
    } catch (error) {
        console.error('Error approving post:', error);
        showNotification('error', 'Có lỗi xảy ra');
    }
}

// Reject post via AJAX
async function rejectPost(postId, buttonElement) {
    try {
        const response = await fetch(`/admin/posts/${postId}/reject`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            credentials: 'same-origin'
        });

        const data = await response.json();
        
        if (data.success) {
            // Update UI
            const row = buttonElement.closest('tr');
            const statusCell = row.querySelector('td:nth-child(6)');
            statusCell.innerHTML = '<span class="badge bg-danger">Từ chối</span>';
            
            // Remove approve/reject buttons
            const actionButtons = row.querySelectorAll('form[action*="approve"], form[action*="reject"]');
            actionButtons.forEach(btn => btn.remove());
            
            showNotification('success', data.message);
        } else {
            showNotification('error', data.message);
        }
    } catch (error) {
        console.error('Error rejecting post:', error);
        showNotification('error', 'Có lỗi xảy ra');
    }
}

// Show notification
function showNotification(type, message) {
    const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
    const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
    
    const alertHtml = `
        <div class="alert ${alertClass} alert-dismissible fade show" role="alert">
            <i class="fas ${icon} me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    const container = document.querySelector('.main-content .border-bottom');
    if (container) {
        container.insertAdjacentHTML('afterend', alertHtml);
        
        // Auto-hide after 3 seconds
        setTimeout(() => {
            const newAlert = container.nextElementSibling;
            if (newAlert && newAlert.classList.contains('alert')) {
                const bsAlert = new bootstrap.Alert(newAlert);
                bsAlert.close();
            }
        }, 3000);
    }
}
