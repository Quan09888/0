# Selenium Test Framework for BDS Website

## Cấu Trúc Thư Mục

```
tests/
├── requirements.txt           # Dependencies
├── config.py                  # Test configuration
├── conftest.py               # Pytest fixtures
├── pages/
│   ├── __init__.py
│   └── login_page.py         # LoginPage Object Model
├── test_login.py             # Login test cases (TC_LOG_001 - TC_LOG_030)
├── pytest.ini                # Pytest configuration
└── README.md                 # This file
```

## Cài Đặt

### 1. Cài đặt Dependencies
```bash
cd tests
pip install -r requirements.txt
```

### 2. Cấu Hình Environment
Tạo file `.env` trong thư mục `/tests`:
```env
BASE_URL=http://localhost:3000
HEADLESS=True
IMPLICIT_WAIT=10
PAGE_LOAD_TIMEOUT=15
```

### 3. Đảm bảo ChromeDriver
- Selenium sẽ tự động download ChromeDriver phù hợp với phiên bản Chrome của bạn
- Không cần cấu hình thêm

## Chạy Tests

### Chạy tất cả test login
```bash
pytest tests/test_login.py -v
```

### Chạy test cụ thể
```bash
pytest tests/test_login.py::TestLoginFunctionality::test_TC_LOG_001_successful_user_login -v
```

### Chạy với HTML report
```bash
pytest tests/test_login.py -v --html=tests/report.html --self-contained-html
```

### Chạy với parallel execution (tốc độ nhanh hơn)
```bash
pytest tests/test_login.py -v -n auto
```

### Chạy ở chế độ headless (không hiển thị browser)
```bash
BASE_URL=http://localhost:3000 HEADLESS=True pytest tests/test_login.py -v
```

### Chạy ở chế độ headed (hiển thị browser)
```bash
BASE_URL=http://localhost:3000 HEADLESS=False pytest tests/test_login.py -v
```

## Test Cases Được Cover (30 test cases)

| TC ID | Tên Test | Status |
|-------|----------|--------|
| TC_LOG_001 | Đăng nhập thành công với User | ✅ |
| TC_LOG_002 | Đăng nhập thành công với Admin | ✅ |
| TC_LOG_003 | Đăng nhập với email chứa chữ in hoa | ✅ |
| TC_LOG_004 | Đăng nhập với email có khoảng trắng | ✅ |
| TC_LOG_005 | Chức năng "Ghi nhớ đăng nhập" (checked) | ✅ |
| TC_LOG_006 | Chức năng "Ghi nhớ đăng nhập" (unchecked) | ✅ |
| TC_LOG_007 | Submit form trống | ✅ |
| TC_LOG_008 | Chỉ nhập Email | ✅ |
| TC_LOG_009 | Chỉ nhập Mật khẩu | ✅ |
| TC_LOG_010 | Email không hợp lệ (thiếu @) | ✅ |
| TC_LOG_011 | Email không hợp lệ (thiếu domain) | ✅ |
| TC_LOG_012 | Tài khoản không tồn tại | ✅ |
| TC_LOG_013 | Mật khẩu sai | ✅ |
| TC_LOG_014 | Tài khoản bị khóa | ✅ |
| TC_LOG_015 | Toggle mật khẩu - hiện | ✅ |
| TC_LOG_016 | Toggle mật khẩu - ẩn | ✅ |
| TC_LOG_017 | Submit bằng phím Enter | ✅ |
| TC_LOG_018 | Click "Quên mật khẩu?" | ✅ |
| TC_LOG_019 | Click "Đăng ký ngay" | ✅ |
| TC_LOG_020 | Responsive Mobile (iPhone) | ✅ |
| TC_LOG_021 | Responsive Tablet (iPad) | ✅ |
| TC_LOG_022 | Tab order navigation | ✅ |
| TC_LOG_023 | Page title | ✅ |
| TC_LOG_024 | Browser autocomplete | ✅ |
| TC_LOG_025 | SQL Injection protection | ✅ |
| TC_LOG_026 | XSS protection | ✅ |
| TC_LOG_027 | Brute force protection | ✅ |
| TC_LOG_028 | Access login when logged in (User) | ✅ |
| TC_LOG_029 | Access login when logged in (Admin) | ✅ |
| TC_LOG_030 | Login with old password | ✅ |

## Page Object Model

### LoginPage Class
Nằm trong `tests/pages/login_page.py` với các methods:

- `navigate_to_login()` - Điều hướng đến trang đăng nhập
- `enter_email(email)` - Nhập email
- `enter_password(password)` - Nhập mật khẩu
- `click_login_button()` - Click nút đăng nhập
- `click_remember_me()` - Click checkbox "Ghi nhớ"
- `toggle_password_visibility()` - Toggle hiện/ẩn mật khẩu
- `get_flash_message()` - Lấy flash message
- `get_error_message()` - Lấy error message
- `login(email, password, remember)` - Thực hiện complete login flow

## Fixtures

- `driver` - Selenium WebDriver instance
- `base_url` - Base URL từ config

## Cách Thêm Test Cases Mới

1. Tạo method mới trong class `TestLoginFunctionality`
2. Sử dụng `@pytest.mark.parametrize` nếu cần chạy với nhiều data
3. Sử dụng LoginPage methods từ `self.login_page`
4. Assert kết quả mong đợi

Ví dụ:
```python
def test_new_case(self):
    """Test description"""
    self.login_page.login("email@test.com", "password")
    WebDriverWait(self.driver, 10).until(EC.url_contains("/"))
    assert "/" in self.driver.current_url
```

## Troubleshooting

### ChromeDriver Error
- Xóa folder `.wdm` và chạy lại
- Hoặc update Chrome browser

### Element Not Found
- Thêm `time.sleep(1)` trước click
- Sử dụng explicit waits thay vì implicit waits

### Test Failed
- Kiểm tra BASE_URL có đúng không
- Kiểm tra server có chạy không
- Xem logs: `pytest tests/test_login.py -v -s`

---

**Sẵn sàng nhận test cases tiếp theo!**
