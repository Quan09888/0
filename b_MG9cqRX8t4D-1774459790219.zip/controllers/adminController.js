const { User, Post, Category, History } = require("../models");
const bcrypt = require('bcrypt'); // đổi mật khẩu

// Seed data configuration
const categoriesData = [
  { name: "chung cư", description: "Căn hộ chung cư, apartment", icon: "fas fa-building", color: "#007bff", sortOrder: 1 },
  { name: "nhà riêng", description: "Nhà riêng, nhà phố", icon: "fas fa-home", color: "#28a745", sortOrder: 2 },
  { name: "đất nền", description: "Đất nền, đất thổ cư", icon: "fas fa-map", color: "#ffc107", sortOrder: 3 },
  { name: "nhà mặt phố", description: "Nhà mặt phố, mặt tiền", icon: "fas fa-store", color: "#dc3545", sortOrder: 4 },
  { name: "biệt thự", description: "Biệt thự, villa", icon: "fas fa-crown", color: "#6f42c1", sortOrder: 5 },
  { name: "shophouse", description: "Shophouse, nhà phố thương mại", icon: "fas fa-shopping-bag", color: "#fd7e14", sortOrder: 6 },
  { name: "kho xưởng", description: "Kho xưởng, nhà máy", icon: "fas fa-warehouse", color: "#6c757d", sortOrder: 7 },
  { name: "văn phòng", description: "Văn phòng, tòa nhà", icon: "fas fa-briefcase", color: "#20c997", sortOrder: 8 },
];

const adminData = { name: "Admin", email: "admin@gmail.com", password: "admin123", role: "admin", phone: "0123456789", emailVerified: true };

const usersData = [
  { name: "Nguyễn Văn An", email: "vudovn@gmail.com", password: "Vudo354@", phone: "0987654321", emailVerified: true },
  { name: "Trần Thị Bình", email: "tranthib@gmail.com", password: "123456", phone: "0987654322", emailVerified: true },
  { name: "Lê Văn Cường", email: "levanc@gmail.com", password: "123456", phone: "0987654323", emailVerified: true },
  { name: "Phạm Minh Đức", email: "phamminhduc@gmail.com", password: "123456", phone: "0987654324", emailVerified: true },
  { name: "Hoàng Thị Hương", email: "hoanghuong@gmail.com", password: "123456", phone: "0987654325", emailVerified: true },
];

const getPostsData = (users) => [
  { title: "Bán căn hộ chung cư 2PN tại Vinhomes Central Park", description: "Căn hộ cao cấp 2 phòng ngủ, 2 toilet, đầy đủ nội thất nhập khẩu, view sông Sài Gòn tuyệt đẹp.", price: 4500000000, area: 85, address: "208 Nguyễn Hữu Cảnh, Quận Bình Thạnh, TP.HCM", phone: "0987654321", type: "bán", category: "chung cư", images: ["/images/apartment.jpg"], userId: users[0]._id, isApproved: true, views: 156 },
  { title: "Bán căn hộ 3PN Masteri Thảo Điền quận 2", description: "Căn hộ 3 phòng ngủ, 2 WC, diện tích 98m2, tầng cao view sông.", price: 5200000000, area: 98, address: "159 Xa Lộ Hà Nội, Quận 2, TP.HCM", phone: "0987654322", type: "bán", category: "chung cư", images: ["/images/apartment.jpg"], userId: users[1]._id, isApproved: true, views: 89 },
  { title: "Cho thuê căn hộ studio Vinhomes Grand Park quận 9", description: "Căn hộ studio full nội thất cao cấp, máy lạnh, tủ lạnh, máy giặt.", price: 6500000, area: 32, address: "Long Thạnh Mỹ, Quận 9, TP.HCM", phone: "0987654323", type: "cho thuê", category: "chung cư", images: ["/images/apartment.jpg"], userId: users[2]._id, isApproved: true, views: 234 },
  { title: "Cho thuê căn hộ 2PN The Sun Avenue quận 2", description: "Căn hộ 2 phòng ngủ, 2 toilet, nội thất đẹp, ban công view sông.", price: 12000000, area: 76, address: "28 Mai Chí Thọ, Quận 2, TP.HCM", phone: "0987654324", type: "cho thuê", category: "chung cư", images: ["/images/apartment.jpg"], userId: users[3]._id, isApproved: true, views: 178 },
  { title: "Bán nhà riêng 3 tầng HXH Nguyễn Văn Đậu Bình Thạnh", description: "Nhà 3 tầng BTCT, 4 phòng ngủ, 3 WC, phòng khách rộng.", price: 6800000000, area: 65, address: "Hẻm 158 Nguyễn Văn Đậu, Quận Bình Thạnh, TP.HCM", phone: "0987654321", type: "bán", category: "nhà riêng", images: ["/images/sample-house.jpg"], userId: users[0]._id, isApproved: true, views: 312 },
  { title: "Bán nhà 2 mặt tiền hẻm Lê Văn Sỹ quận 3", description: "Nhà 2 mặt tiền hẻm xe hơi, 1 trệt 2 lầu, 3PN 2WC.", price: 8500000000, area: 48, address: "Hẻm 567 Lê Văn Sỹ, Quận 3, TP.HCM", phone: "0987654325", type: "bán", category: "nhà riêng", images: ["/images/sample-house.jpg"], userId: users[4]._id, isApproved: true, views: 445 },
  { title: "Cho thuê nhà nguyên căn 3 tầng Thảo Điền quận 2", description: "Nhà nguyên căn 3 tầng, 4PN 3WC, có sân để 2 xe hơi.", price: 35000000, area: 150, address: "Đường 65, Quận 2, TP.HCM", phone: "0987654322", type: "cho thuê", category: "nhà riêng", images: ["/images/sample-house.jpg"], userId: users[1]._id, isApproved: true, views: 167 },
  { title: "Bán đất nền dự án Mega City 2 Long Thành", description: "Đất nền dự án quy hoạch đồng bộ, hạ tầng hoàn thiện.", price: 1850000000, area: 100, address: "Xã Phước Thái, Huyện Long Thành, Đồng Nai", phone: "0987654323", type: "bán", category: "đất nền", images: ["/images/land.jpg"], userId: users[2]._id, isApproved: true, views: 567 },
  { title: "Bán đất thổ cư mặt tiền đường nhựa Củ Chi", description: "Đất thổ cư 100%, mặt tiền đường nhựa 8m, SHR.", price: 980000000, area: 120, address: "Xã Phú Hòa Đông, Huyện Củ Chi, TP.HCM", phone: "0987654324", type: "bán", category: "đất nền", images: ["/images/land.jpg"], userId: users[3]._id, isApproved: true, views: 389 },
  { title: "Bán biệt thự nghỉ dưỡng view biển Nha Trang", description: "Biệt thự view biển tuyệt đẹp, 5 phòng ngủ VIP, hồ bơi riêng.", price: 15000000000, area: 450, address: "Bãi Dài, Cam Lâm, Khánh Hòa", phone: "0987654321", type: "bán", category: "biệt thự", images: ["/images/villa.jpg"], userId: users[0]._id, isApproved: true, views: 723 },
  { title: "Bán biệt thự Vinhomes Grand Park quận 9", description: "Biệt thự đơn lập The Manhattan, 4 tầng, 5PN 6WC.", price: 32000000000, area: 200, address: "Vinhomes Grand Park, Quận 9, TP.HCM", phone: "0987654325", type: "bán", category: "biệt thự", images: ["/images/villa.jpg"], userId: users[4]._id, isApproved: true, views: 456 },
  { title: "Cho thuê văn phòng hạng A Bitexco quận 1", description: "Văn phòng hạng A tòa Bitexco Financial Tower, tầng 28.", price: 850000, area: 100, address: "2 Hải Triều, Quận 1, TP.HCM", phone: "0987654322", type: "cho thuê", category: "văn phòng", images: ["/images/apartment.jpg"], userId: users[1]._id, isApproved: true, views: 234 },
  { title: "Cho thuê văn phòng view hồ Tây Hà Nội", description: "Văn phòng mới 100%, view hồ Tây tuyệt đẹp.", price: 25000000, area: 120, address: "16 Quảng An, Quận Tây Hồ, Hà Nội", phone: "0987654323", type: "cho thuê", category: "văn phòng", images: ["/images/apartment.jpg"], userId: users[2]._id, isApproved: true, views: 189 },
  { title: "Bán shophouse Vinhomes Ocean Park Gia Lâm", description: "Shophouse mặt đường 30m, 5 tầng, có thang máy.", price: 18500000000, area: 90, address: "Đại lộ Kinh Đô, Vinhomes Ocean Park, Gia Lâm, Hà Nội", phone: "0987654324", type: "bán", category: "shophouse", images: ["/images/sample-house.jpg"], userId: users[3]._id, isApproved: true, views: 345 },
  { title: "Cho thuê kho xưởng 1500m2 KCN Tân Bình", description: "Kho xưởng mới xây, nền BTCT chịu lực 5 tấn/m2.", price: 180000000, area: 1500, address: "Lô C2-5, KCN Tân Bình, Quận Tân Phú, TP.HCM", phone: "0987654325", type: "cho thuê", category: "kho xưởng", images: ["/images/apartment.jpg"], userId: users[4]._id, isApproved: true, views: 123 },
  { title: "Bán nhà mặt tiền Nguyễn Trãi quận 5", description: "Nhà mặt tiền đường lớn, 1 trệt 4 lầu, 5PN 5WC.", price: 42000000000, area: 99, address: "568 Nguyễn Trãi, Quận 5, TP.HCM", phone: "0987654321", type: "bán", category: "nhà mặt phố", images: ["/images/sample-house.jpg"], userId: users[0]._id, isApproved: true, views: 567 },
  { title: "Bán căn hộ 1PN Saigon Royal quận 4", description: "Căn hộ 1 phòng ngủ, view Bitexco, nội thất cao cấp.", price: 3200000000, area: 52, address: "34-35 Bến Vân Đồn, Quận 4, TP.HCM", phone: "0987654322", type: "bán", category: "chung cư", images: ["/images/apartment.jpg"], userId: users[1]._id, isApproved: null, views: 0 },
  { title: "Cho thuê nhà nguyên căn Gò Vấp giá rẻ", description: "Nhà 2 tầng, 3PN 2WC, có sân để xe máy.", price: 9000000, area: 80, address: "Hẻm 90 Quang Trung, Quận Gò Vấp, TP.HCM", phone: "0987654323", type: "cho thuê", category: "nhà riêng", images: ["/images/sample-house.jpg"], userId: users[2]._id, isApproved: null, views: 0 },
];

const adminController = {
  dashboard: async (req, res) => {
    try {
      const [
        totalUsers,
        totalPosts,
        pendingPosts,
        approvedPosts,
        rejectedPosts,
        activeUsers,
        inactiveUsers,
        totalCategories,
      ] = await Promise.all([
        User.countDocuments(),
        Post.countDocuments(),
        Post.countDocuments({ isApproved: null }),
        Post.countDocuments({ isApproved: true }),
        Post.countDocuments({ isApproved: false }),
        User.countDocuments({ isActive: true }),
        User.countDocuments({ isActive: false }),
        Category.countDocuments(),
      ]);

      const recentPosts = await Post.find()
        .populate("userId", "name email")
        .sort({ createdAt: -1 })
        .limit(5);

      const recentUsers = await User.find().sort({ createdAt: -1 }).limit(5);

      res.render("admin/dashboard", {
        title: "Admin Dashboard",
        layout: "admin",
        stats: {
          totalUsers,
          totalPosts,
          pendingPosts,
          approvedPosts,
          rejectedPosts,
          activeUsers,
          inactiveUsers,
          totalCategories,
        },
        recentPosts,
        recentUsers,
      });
    } catch (error) {
      console.error("Admin dashboard error:", error);
      req.flash("error", "Có lỗi xảy ra khi tải dashboard");
      res.redirect("/");
    }
  },

  posts: async (req, res) => {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = 20;
      const skip = (page - 1) * limit;

      const filter = {};
      if (req.query.status === "pending") filter.isApproved = null;
      else if (req.query.status === "approved") filter.isApproved = true;
      else if (req.query.status === "rejected") filter.isApproved = false;

      if (req.query.search) {
        filter.$or = [
          { title: { $regex: req.query.search, $options: "i" } },
          { description: { $regex: req.query.search, $options: "i" } },
        ];
      }

      const [posts, totalPosts] = await Promise.all([
        Post.find(filter)
          .populate("userId", "name email")
          .sort({ createdAt: -1 })
          .skip(skip)
          .limit(limit),
        Post.countDocuments(filter),
      ]);

      const totalPages = Math.ceil(totalPosts / limit);

      res.render("admin/posts", {
        title: "Quản lý tin đăng",
        layout: "admin",
        posts,
        pagination: {
          currentPage: page,
          totalPages,
          totalPosts,
          hasNext: page < totalPages,
          hasPrev: page > 1,
          nextPage: page + 1,
          prevPage: page - 1,
        },
        filters: req.query,
      });
    } catch (error) {
      console.error("Admin posts error:", error);
      req.flash("error", "Có lỗi xảy ra khi tải danh sách tin đăng");
      res.redirect("/admin");
    }
  },

  approvePost: async (req, res) => {
    try {
      const post = await Post.findByIdAndUpdate(
        req.params.id,
        { isApproved: true },
        { new: true }
      ).populate('userId', 'name');

      if (!post) {
        return res.status(404).json({
          success: false,
          message: "Tin đăng không tồn tại",
        });
      }

      // Tạo thông báo khi tin được duyệt
      await History.create({
        postId: post._id,
        userId: post.userId._id,
        title: post.title
      });

      res.json({
        success: true,
        message: "Đã duyệt tin đăng thành công",
      });
    } catch (error) {
      console.error("Approve post error:", error);
      res.status(500).json({
        success: false,
        message: "Có lỗi xảy ra",
      });
    }
  },

  rejectPost: async (req, res) => {
    try {
      const post = await Post.findByIdAndUpdate(
        req.params.id,
        { isApproved: false },
        { new: true }
      );

      if (!post) {
        return res.status(404).json({
          success: false,
          message: "Tin đăng không tồn tại",
        });
      }

      res.json({
        success: true,
        message: "Đã từ chối tin đăng",
      });
    } catch (error) {
      console.error("Reject post error:", error);
      res.status(500).json({
        success: false,
        message: "Có lỗi xảy ra",
      });
    }
  },

  deletePost: async (req, res) => {
    try {
      const post = await Post.findByIdAndDelete(req.params.id);

      if (!post) {
        return res.status(404).json({
          success: false,
          message: "Tin đăng không tồn tại",
        });
      }

      res.json({
        success: true,
        message: "Đã xóa tin đăng thành công",
      });
    } catch (error) {
      console.error("Delete post error:", error);
      res.status(500).json({
        success: false,
        message: "Có lỗi xảy ra",
      });
    }
  },

  users: async (req, res) => {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = 20;
      const skip = (page - 1) * limit;

      const filter = {};
      if (req.query.status === "active") filter.isActive = true;
      else if (req.query.status === "inactive") filter.isActive = false;
      if (req.query.role === "admin") filter.role = "admin";
      else if (req.query.role === "user") filter.role = "user";

      if (req.query.search) {
        filter.$or = [
          { name: { $regex: req.query.search, $options: "i" } },
          { email: { $regex: req.query.search, $options: "i" } },
        ];
      }

      const [users, totalUsers] = await Promise.all([
        User.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit),
        User.countDocuments(filter),
      ]);

      const totalPages = Math.ceil(totalUsers / limit);

      res.render("admin/users", {
        title: "Quản lý người dùng",
        layout: "admin",
        users,
        pagination: {
          currentPage: page,
          totalPages,
          totalUsers,
          hasNext: page < totalPages,
          hasPrev: page > 1,
          nextPage: page + 1,
          prevPage: page - 1,
        },
        filters: req.query,
      });
    } catch (error) {
      console.error("Admin users error:", error);
      req.flash("error", "Có lỗi xảy ra khi tải danh sách người dùng");
      res.redirect("/admin");
    }
  },

  activateUser: async (req, res) => {
    try {
      const user = await User.findByIdAndUpdate(
        req.params.id,
        { isActive: true },
        { new: true }
      );

      if (!user) {
        return res.status(404).json({
          success: false,
          message: "Người dùng không tồn tại",
        });
      }

      res.json({
        success: true,
        message: "Đã kích hoạt tài khoản thành công",
      });
    } catch (error) {
      console.error("Activate user error:", error);
      res.status(500).json({
        success: false,
        message: "Có lỗi xảy ra",
      });
    }
  },

  deactivateUser: async (req, res) => {
    try {
      // Prevent deactivating the current logged-in admin
      if (req.params.id === req.session.user._id.toString()) {
        return res.status(400).json({
          success: false,
          message: "Không thể vô hiệu hóa tài khoản của chính mình",
        });
      }

      const user = await User.findById(req.params.id);
      
      if (!user) {
        return res.status(404).json({
          success: false,
          message: "Người dùng không tồn tại",
        });
      }

      // Prevent deactivating if it's the last admin and this user is an admin
      if (user.role === "admin") {
        const activeAdminCount = await User.countDocuments({ 
          role: "admin", 
          isActive: true 
        });
        if (activeAdminCount <= 1) {
          return res.status(400).json({
            success: false,
            message: "Không thể vô hiệu hóa tài khoản admin cuối cùng trong hệ thống",
          });
        }
      }

      await User.findByIdAndUpdate(
        req.params.id,
        { isActive: false },
        { new: true }
      );

      res.json({
        success: true,
        message: "Đã vô hiệu hóa tài khoản",
      });
    } catch (error) {
      console.error("Deactivate user error:", error);
      res.status(500).json({
        success: false,
        message: "Có lỗi xảy ra",
      });
    }
  },

  makeAdmin: async (req, res) => {
    try {
      const user = await User.findByIdAndUpdate(
        req.params.id,
        { role: "admin" },
        { new: true }
      );

      if (!user) {
        return res.status(404).json({
          success: false,
          message: "Người dùng không tồn tại",
        });
      }

      res.json({
        success: true,
        message: "Đã cấp quyền admin thành công",
      });
    } catch (error) {
      console.error("Make admin error:", error);
      res.status(500).json({
        success: false,
        message: "Có lỗi xảy ra",
      });
    }
  },

  removeAdmin: async (req, res) => {
    try {
      // Prevent removing admin rights from the current logged-in admin
      if (req.params.id === req.session.user._id.toString()) {
        return res.status(400).json({
          success: false,
          message: "Không thể thu hồi quyền admin của chính mình",
        });
      }

      const user = await User.findById(req.params.id);
      
      if (!user) {
        return res.status(404).json({
          success: false,
          message: "Người dùng không tồn tại",
        });
      }

      // Prevent removing admin status if it's the last admin
      if (user.role === "admin") {
        const adminCount = await User.countDocuments({ role: "admin" });
        if (adminCount <= 1) {
          return res.status(400).json({
            success: false,
            message: "Không thể thu hồi quyền admin cuối cùng trong hệ thống",
          });
        }
      }

      await User.findByIdAndUpdate(
        req.params.id,
        { role: "user" },
        { new: true }
      );

      res.json({
        success: true,
        message: "Đã thu hồi quyền admin",
      });
    } catch (error) {
      console.error("Remove admin error:", error);
      res.status(500).json({
        success: false,
        message: "Có lỗi xảy ra",
      });
    }
  },

  deleteUser: async (req, res) => {
    try {
      if (req.params.id === req.session.user._id.toString()) {
        return res.status(400).json({
          success: false,
          message: "Không thể xóa tài khoản của chính mình",
        });
      }

      const user = await User.findById(req.params.id);
      
      if (!user) {
        return res.status(404).json({
          success: false,
          message: "Người dùng không tồn tại",
        });
      }

      // Prevent deleting if it's the last admin
      if (user.role === "admin") {
        const adminCount = await User.countDocuments({ role: "admin" });
        if (adminCount <= 1) {
          return res.status(400).json({
            success: false,
            message: "Không thể xóa admin cuối cùng trong hệ thống",
          });
        }
      }

      await User.findByIdAndDelete(req.params.id);
      await Post.deleteMany({ userId: req.params.id });

      res.json({
        success: true,
        message: "Đã xóa người dùng thành công",
      });
    } catch (error) {
      console.error("Delete user error:", error);
      res.status(500).json({
        success: false,
        message: "Có lỗi xảy ra",
      });
    }
  },

  // đổi mật khẩu
  changeUserPassword: async (req, res) => {
    try {
      const { newPassword } = req.body;

      if (!newPassword || newPassword.trim().length < 6) {
        return res.status(400).json({
          success: false,
          message: "Mật khẩu mới phải có ít nhất 6 ký tự",
        });
      }

      const user = await User.findById(req.params.id);

      if (!user) {
        return res.status(404).json({
          success: false,
          message: "Người dùng không tồn tại",
        });
      }

      // Hash the new password
      const hashedPassword = await bcrypt.hash(newPassword.trim(), 12);
      
      // Update the password directly (bypass the pre-save middleware)
      await User.updateOne(
        { _id: req.params.id },
        { password: hashedPassword }
      );

      res.json({
        success: true,
        message: "Đã đổi mật khẩu thành công",
      });
    } catch (error) {
      console.error("Change user password error:", error);
      res.status(500).json({
        success: false,
        message: "Có lỗi xảy ra khi đổi mật khẩu",
      });
    }
  },
  //end đổi mật khẩu

  categories: async (req, res) => {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = 20;
      const skip = (page - 1) * limit;

      const filter = {};
      if (req.query.status === "active") filter.isActive = true;
      else if (req.query.status === "inactive") filter.isActive = false;

      if (req.query.search) {
        filter.$or = [
          { name: { $regex: req.query.search, $options: "i" } },
          { description: { $regex: req.query.search, $options: "i" } },
        ];
      }

      const [categories, totalCategories] = await Promise.all([
        Category.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit),
        Category.countDocuments(filter),
      ]);

      for (let category of categories) {
        category.postCount = await Post.countDocuments({
          category: category.name,
        });
      }

      const totalPages = Math.ceil(totalCategories / limit);

      res.render("admin/categories", {
        title: "Quản lý danh mục",
        layout: "admin",
        categories,
        pagination: {
          currentPage: page,
          totalPages,
          totalCategories,
          hasNext: page < totalPages,
          hasPrev: page > 1,
          nextPage: page + 1,
          prevPage: page - 1,
        },
        filters: req.query,
      });
    } catch (error) {
      console.error("Admin categories error:", error);
      req.flash("error", "Có lỗi xảy ra khi tải danh sách danh mục");
      res.redirect("/admin");
    }
  },

  createCategory: async (req, res) => {
    try {
      const { name, description } = req.body;

      if (!name || name.trim().length === 0) {
        return res.status(400).json({
          success: false,
          message: "Tên danh mục không được để trống",
        });
      }

      const existingCategory = await Category.findOne({
        name: name.trim(),
      });

      if (existingCategory) {
        return res.status(400).json({
          success: false,
          message: "Danh mục này đã tồn tại",
        });
      }

      const category = await Category.create({
        name: name.trim(),
        description: description ? description.trim() : "",
        isActive: true,
      });

      res.json({
        success: true,
        message: "Tạo danh mục thành công",
        category,
      });
    } catch (error) {
      console.error("Create category error:", error);
      res.status(500).json({
        success: false,
        message: "Có lỗi xảy ra khi tạo danh mục",
      });
    }
  },

  updateCategory: async (req, res) => {
    try {
      const { name, description } = req.body;

      if (!name || name.trim().length === 0) {
        return res.status(400).json({
          success: false,
          message: "Tên danh mục không được để trống",
        });
      }

      const existingCategory = await Category.findOne({
        name: name.trim(),
        _id: { $ne: req.params.id },
      });

      if (existingCategory) {
        return res.status(400).json({
          success: false,
          message: "Tên danh mục này đã tồn tại",
        });
      }

      const category = await Category.findByIdAndUpdate(
        req.params.id,
        {
          name: name.trim(),
          description: description ? description.trim() : "",
        },
        { new: true }
      );

      if (!category) {
        return res.status(404).json({
          success: false,
          message: "Danh mục không tồn tại",
        });
      }

      res.json({
        success: true,
        message: "Cập nhật danh mục thành công",
        category,
      });
    } catch (error) {
      console.error("Update category error:", error);
      res.status(500).json({
        success: false,
        message: "Có lỗi xảy ra khi cập nhật danh mục",
      });
    }
  },

  activateCategory: async (req, res) => {
    try {
      const category = await Category.findByIdAndUpdate(
        req.params.id,
        { isActive: true },
        { new: true }
      );

      if (!category) {
        return res.status(404).json({
          success: false,
          message: "Danh mục không tồn tại",
        });
      }

      res.json({
        success: true,
        message: "Đã kích hoạt danh mục thành công",
      });
    } catch (error) {
      console.error("Activate category error:", error);
      res.status(500).json({
        success: false,
        message: "Có lỗi xảy ra",
      });
    }
  },

  deactivateCategory: async (req, res) => {
    try {
      const category = await Category.findByIdAndUpdate(
        req.params.id,
        { isActive: false },
        { new: true }
      );

      if (!category) {
        return res.status(404).json({
          success: false,
          message: "Danh mục không tồn tại",
        });
      }

      res.json({
        success: true,
        message: "Đã vô hiệu hóa danh mục",
      });
    } catch (error) {
      console.error("Deactivate category error:", error);
      res.status(500).json({
        success: false,
        message: "Có lỗi xảy ra",
      });
    }
  },

  deleteCategory: async (req, res) => {
    try {
      const postsCount = await Post.countDocuments({
        category: req.params.id,
      });

      if (postsCount > 0) {
        return res.status(400).json({
          success: false,
          message: `Không thể xóa danh mục này vì có ${postsCount} tin đăng đang sử dụng`,
        });
      }

      const category = await Category.findByIdAndDelete(req.params.id);

      if (!category) {
        return res.status(404).json({
          success: false,
          message: "Danh mục không tồn tại",
        });
      }

      res.json({
        success: true,
        message: "Đã xóa danh mục thành công",
      });
    } catch (error) {
      console.error("Delete category error:", error);
      res.status(500).json({
        success: false,
        message: "Có lỗi xảy ra khi xóa danh mục",
      });
    }
  },

  // Seed database with sample data
  seedDatabase: async (req, res) => {
    try {
      console.log("Starting database seeding...");

      // Clear existing data
      await User.deleteMany({});
      await Post.deleteMany({});
      await Category.deleteMany({});
      await History.deleteMany({});
      console.log("Cleared existing data");

      // Create categories
      const categories = await Category.insertMany(categoriesData);
      console.log(`Created ${categories.length} categories`);

      // Create admin user
      const admin = await User.create(adminData);
      console.log("Created admin user");

      // Create regular users
      const users = await User.insertMany(usersData);
      console.log(`Created ${users.length} regular users`);

      // Create posts
      const postsData = getPostsData(users);
      const posts = await Post.insertMany(postsData);
      console.log(`Created ${posts.length} posts`);

      // Update categories posts count
      for (const category of categories) {
        await category.updatePostsCount();
      }
      console.log("Updated categories posts count");

      res.json({
        success: true,
        message: "Database seeded successfully!",
        data: {
          admin: { email: adminData.email, password: adminData.password },
          usersCount: users.length,
          categoriesCount: categories.length,
          postsCount: posts.length
        }
      });
    } catch (error) {
      console.error("Seed database error:", error);
      res.status(500).json({
        success: false,
        message: "Có lỗi xảy ra khi seed database: " + error.message,
      });
    }
  },
};

module.exports = adminController;
