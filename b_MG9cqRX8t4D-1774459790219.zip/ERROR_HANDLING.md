# Error Handling Guide

## Error Types & Responses

### 400 - Bad Request
**When**: Invalid input data, validation failures
**Response**:
```json
{
  "success": false,
  "message": "Dữ liệu không hợp lệ",
  "errors": ["Tiêu đề phải có ít nhất 10 ký tự"]
}
```

### 401 - Unauthorized
**When**: Missing or invalid authentication
**Response**:
```json
{
  "success": false,
  "message": "Bạn cần đăng nhập"
}
```

### 403 - Forbidden
**When**: Authenticated but not authorized (e.g., trying to edit someone else's post)
**Response**:
```json
{
  "success": false,
  "message": "Bạn không có quyền thực hiện hành động này"
}
```

### 404 - Not Found
**When**: Resource doesn't exist
**Response**:
```html
<!-- Rendered error.hbs view -->
404 | Không tìm thấy trang
```

### 409 - Conflict
**When**: Data conflict (e.g., duplicate email)
**Response**:
```json
{
  "success": false,
  "message": "Email đã được sử dụng"
}
```

### 429 - Too Many Requests
**When**: Rate limit exceeded
**Response**:
```json
{
  "success": false,
  "message": "Quá nhiều yêu cầu. Vui lòng thử lại sau 15 phút"
}
```

### 500 - Internal Server Error
**When**: Unexpected server error
**Response**:
```json
{
  "success": false,
  "message": "Có lỗi xảy ra. Vui lòng thử lại sau"
}
```

## Common Validation Errors

### Registration
```
- Email không hợp lệ
- Mật khẩu phải chứa ít nhất 1 chữ thường, 1 chữ hoa và 1 số
- Xác nhận mật khẩu không khớp
- Số điện thoại phải có 10-11 chữ số
```

### Post Creation
```
- Tiêu đề phải có 10-200 ký tự
- Mô tả phải có 50-2000 ký tự
- Giá phải lớn hơn 0
- Diện tích phải lớn hơn 0 và ≤ 10,000 m²
- Địa chỉ phải có ít nhất 10 ký tự
- Số điện thoại không hợp lệ
```

## Error Handling Flow

```
1. User Action (Create Post)
   ↓
2. Input Validation
   ├─ Valid → Process
   └─ Invalid → Return 400 with errors
   ↓
3. Authentication Check
   ├─ Authenticated → Continue
   └─ Not Authenticated → Return 401
   ↓
4. Authorization Check
   ├─ Authorized → Continue
   └─ Not Authorized → Return 403
   ↓
5. Database Operation
   ├─ Success → Return 200 with data
   ├─ Conflict → Return 409
   └─ Error → Return 500
```

## Custom Error Classes

### ValidationError
```javascript
class ValidationError extends Error {
  constructor(message, errors = []) {
    super(message);
    this.name = 'ValidationError';
    this.statusCode = 400;
    this.errors = errors;
  }
}
```

### AuthenticationError
```javascript
class AuthenticationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'AuthenticationError';
    this.statusCode = 401;
  }
}
```

### AuthorizationError
```javascript
class AuthorizationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'AuthorizationError';
    this.statusCode = 403;
  }
}
```

## Error Handling Middleware

### Application-Level
```javascript
// In app.js
const { errorHandler, notFound } = require('./middleware/errorHandler');

// Last middleware - catch-all error handler
app.use(notFound);
app.use(errorHandler);
```

### Route-Level
```javascript
// In routes/posts.js
router.post('/create', validatePost, createPostController);

// Errors automatically caught by error handler
```

### Function-Level
```javascript
async function getPosts(req, res, next) {
  try {
    const posts = await Post.find();
    res.json(posts);
  } catch (error) {
    next(error); // Pass to error handler
  }
}
```

## User-Facing Error Messages

### In Flash Messages
```handlebars
{{#if error}}
  <div class="alert alert-danger">{{error}}</div>
{{/if}}

{{#if success}}
  <div class="alert alert-success">{{success}}</div>
{{/if}}
```

### In Form Validation
```handlebars
{{#each errors}}
  <div class="invalid-feedback">{{this}}</div>
{{/each}}
```

### In API Responses
```javascript
res.status(400).json({
  success: false,
  message: "Validation failed",
  errors: ["Field 1 error", "Field 2 error"]
});
```

## Logging & Monitoring

### Request Logging
```javascript
// Automatic with middleware
console.log(`${req.method} ${req.path} - ${res.statusCode}`);
```

### Error Logging
```javascript
// In errorHandler middleware
console.error({
  message: err.message,
  stack: err.stack,
  url: req.originalUrl,
  method: req.method,
  statusCode: res.statusCode,
  userId: req.user?._id,
});
```

### Performance Monitoring
```javascript
const duration = Date.now() - startTime;
if (duration > 1000) {
  console.warn(`Slow request: ${duration}ms - ${req.path}`);
}
```

## Error Recovery Strategies

### Retry Logic
```javascript
async function retryOperation(fn, maxRetries = 3, delay = 1000) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (i === maxRetries - 1) throw error;
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
}
```

### Graceful Degradation
```javascript
// If search fails, fallback to basic query
try {
  results = await Post.find({ $text: { $search: query } });
} catch (error) {
  // Fallback: search by title only
  results = await Post.find({ title: new RegExp(query, 'i') });
}
```

### Error Fallbacks
```handlebars
{{#if error}}
  <div class="alert alert-danger">
    {{message}}
    <button onclick="location.reload()">Tải lại trang</button>
  </div>
{{/if}}
```

## Development vs Production

### Development
- Detailed error messages shown
- Full stack traces in console
- Database connection errors visible
- Validation details provided

### Production
- Generic error messages (security)
- Error logs stored to file
- Errors sent to monitoring service
- User-friendly error pages

## Troubleshooting Common Errors

### MongooseValidationError
**Cause**: Invalid data for database schema
**Fix**: Validate data before saving, check schema requirements

### MongoServerError 11000
**Cause**: Duplicate unique field (email, slug)
**Fix**: Check if record already exists, return 409 Conflict

### JsonWebTokenError
**Cause**: Invalid or expired token
**Fix**: User needs to login again, clear session

### TypeError: Cannot read property
**Cause**: Null/undefined value accessed
**Fix**: Add null checks, use optional chaining (?.)

### ENOENT: File not found
**Cause**: Missing file or directory
**Fix**: Check file paths, create directories if needed

### ECONNREFUSED
**Cause**: Database connection failed
**Fix**: Verify MongoDB is running, check connection string

## Best Practices

1. **Always validate input** before processing
2. **Provide clear error messages** to users
3. **Log errors** for debugging and monitoring
4. **Use appropriate HTTP status codes**
5. **Don't expose sensitive information** in errors
6. **Handle async errors** properly (await, try-catch)
7. **Test error scenarios** thoroughly
8. **Monitor error rates** and alert on spikes
9. **Implement retry logic** for transient failures
10. **Gracefully degrade** when features fail

## Testing Errors

### Test Authentication Error
```javascript
// Should get 401 when not logged in
test('GET /admin should return 401', async () => {
  const res = await request(app).get('/admin');
  expect(res.statusCode).toBe(401);
});
```

### Test Validation Error
```javascript
// Should get 400 with validation errors
test('POST /posts should validate input', async () => {
  const res = await request(app)
    .post('/posts')
    .send({ title: 'Bad' }); // Too short
  expect(res.statusCode).toBe(400);
});
```

### Test Not Found Error
```javascript
// Should get 404 for missing resource
test('GET /posts/invalid should return 404', async () => {
  const res = await request(app).get('/posts/invalid');
  expect(res.statusCode).toBe(404);
});
```

## Error Alerts

### High Error Rate Alert
```javascript
if (errorCount > 10 && errorCount / requestCount > 0.05) {
  sendAlert('High error rate detected: ' + (errorCount / requestCount * 100).toFixed(2) + '%');
}
```

### Critical Error Alert
```javascript
const criticalErrors = ['ECONNREFUSED', 'ENOMEM'];
if (criticalErrors.includes(error.code)) {
  sendAlert('Critical error: ' + error.message);
}
```

## Support & Debugging

For support and debugging:
1. Check error message and status code
2. Review console/server logs
3. Verify all environment variables are set
4. Check database connection
5. Review recent code changes
6. Test with fresh browser session (clear cache)
7. Contact support with error details and reproduction steps
